import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data \
    import get_candles_, user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_MACD(maker, indicator, evaluator):
    fast_length = await user_input2(maker, indicator, "MACD fast length", "int", 12)
    slow_length = await user_input2(maker, indicator, "MACD slow length", "int", 26)
    signal_smoothing = await user_input2(maker, indicator, "MACD signal smoothing", "int", 9)
    candle_source = await user_select_candle_source_name(maker, indicator, "Select MACD Candle Source",
                                                         enable_volume=True)
    await allow_enable_plot(maker, indicator, "plot MACD")
    try:
        macd, macd_signal, macd_histogram = tulipy.macd(await get_candles_(maker, candle_source),
                                                        fast_length, slow_length, signal_smoothing)
    except tulipy.lib.InvalidOptionError:
        raise RuntimeError(f"MACD (slow: {slow_length} fast: {fast_length}): "
                           f"fast length cant be longer than slow length")
    data = {"v": {"title": f"MACD ({signal_smoothing}-{fast_length}-{slow_length})",
                  "data": macd, "chart_location": "sub-chart"},
            "s": {"title": f"MACD Signal ({signal_smoothing}-{fast_length}-{slow_length})",
                  "data": macd_signal, "chart_location": "sub-chart"},
            "h": {"title": f"MACD Histogram ({signal_smoothing}-{fast_length}-{slow_length})",
                  "data": macd_histogram, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data)
