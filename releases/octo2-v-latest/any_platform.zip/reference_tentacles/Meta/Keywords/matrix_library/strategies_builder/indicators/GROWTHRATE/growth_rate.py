from octobot_trading.modes.script_keywords import user_input
from tentacles.Meta.Keywords.matrix_library.strategies_builder.indicators.indicator_handling \
    import activate_configurable_indicator, get_configurable_indicator
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot
import numpy as np
import tulipy as ti
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2


async def get_growth_rate(maker, indicator, evaluator):
    selected_indicator = await activate_configurable_indicator(maker, indicator, def_val="price data",
                                                               data_source_name="data source for growth rate")
    length = await user_input2(maker, indicator, f"{selected_indicator} growth rate MA length", "int", 5, min_val=1)
    await allow_enable_plot(maker, indicator, f"Plot {selected_indicator} growth rate")
    data_source_values, _, data_source_title = await get_configurable_indicator(maker, indicator)
    growth_rates = np.exp(np.diff(np.log(data_source_values))) - 1
    growth_rates = growth_rates * 10000
    growth_rates_ma = ti.ema(growth_rates, length)
    data = {"v": {"title": f"{data_source_title} growth rate",
                  "data": list(growth_rates), "chart_location": "sub-chart"},
            "ma": {"title": f"{data_source_title} growth rate MA",
                   "data": list(growth_rates_ma), "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data, own_yaxis=True)
