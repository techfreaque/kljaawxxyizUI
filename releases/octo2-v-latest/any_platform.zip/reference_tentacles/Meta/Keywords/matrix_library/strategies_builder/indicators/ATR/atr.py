import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_ATR(maker, indicator, evaluator):
    length = await user_input2(maker, indicator, "ATR length", "int", 50, 0)
    await allow_enable_plot(maker, indicator, "Plot ATR")
    closes = await get_candles_(maker, "close")
    data = tulipy.atr(await get_candles_(maker, "high"), await get_candles_(maker, "low"), closes, length)
    closes = closes[-len(data):]
    low_data = closes - data
    high_data = closes + data
    data_source = {"v": {"title": f"ATR low {length}", "data": low_data, "chart_location": "main-chart"},
                   "h": {"title": f"ATR high {length}", "data": high_data, "chart_location": "main-chart"}}
    return await store_indicator_data(maker, indicator, data_source)
