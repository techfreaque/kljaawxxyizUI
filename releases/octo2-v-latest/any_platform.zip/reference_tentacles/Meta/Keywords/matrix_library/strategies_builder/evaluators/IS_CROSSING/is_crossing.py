from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.crossing import crossing_up_, \
    crossing_down_, crossing_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_evaluator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.indicators.indicator_handling \
    import get_configurable_indicator, activate_configurable_indicator


async def get_is_crossing(maker, evaluator):
    crossing_values_title = await activate_configurable_indicator(maker, evaluator, data_source_name="crossing values",
                                                                  def_val="price data", enable_static_value=False)
    values_to_cross_title = await activate_configurable_indicator(maker, evaluator, data_source_name="values to cross",
                                                                  def_val="EMA", indicator_id=2)
    crossing_direction = await user_input2(maker, evaluator, "crossing direction", "options", "crossing up",
                                           options=["crossing up", "crossing down", "crossing up and down"])
    crossing_delay = await user_input2(maker, evaluator, "crossing signal delay", "int", 0)
    max_crossing_lookback = await user_input2(maker, evaluator, "history length for maximum dump/pump (0 = disabled)",
                                              "int", 0, 0)
    max_crossing = 0
    if int(max_crossing_lookback) != 0:
        max_crossing = await user_input2(maker, evaluator, "maximum % dump/pump before cross up/down (0 = disabled)",
                                         "float", 0)
    max_crossing_count = 50
    max_crossing = None if int(max_crossing_lookback) == 0 or int(max_crossing) == 0 else str(max_crossing) + "%"
    max_crossing_count_lookback = await user_input2(maker, evaluator,
                                                    "history length for nearby signals (0 = disabled)", "int", 0, 0)
    if int(max_crossing_count_lookback) != 0:
        max_crossing_count = await user_input2(maker, evaluator, "maximum nearby signals", "int", 1, min_val=1)
        max_crossing_count = max_crossing_count if int(
            max_crossing_count) != 0 else 50

    evaluator.title = f"{crossing_values_title} is {crossing_direction} {values_to_cross_title}"
    await allow_enable_plot(maker, evaluator, f"Plot when {evaluator.title}")
    max_crossing_count_lookback = max_crossing_count_lookback \
        if max_crossing_count_lookback != 0 else 1

    data_crossing_values, evaluator.chart_location, crossing_values_title = await get_configurable_indicator(maker,
                                                                                                             evaluator)

    evaluator.values, _, values_to_cross_title = await get_configurable_indicator(maker, evaluator, indicator_id=2)

    if crossing_direction == "crossing up":
        evaluator.signals = await crossing_up_(maker=maker, values_to_cross=evaluator.values,
                                               crossing_values=data_crossing_values, delay=crossing_delay,
                                               max_cross_down=max_crossing,
                                               max_cross_down_lookback=max_crossing_lookback,
                                               max_history=not maker.live_recording_mode)

    elif crossing_direction == "crossing down":
        evaluator.signals = await crossing_down_(maker=maker, values_to_cross=evaluator.values,
                                                 crossing_values=data_crossing_values, delay=crossing_delay,
                                                 max_cross_up=max_crossing, max_cross_up_lookback=max_crossing_lookback,
                                                 max_history=not maker.live_recording_mode)
    else:  # crossing up or down
        evaluator.signals = await crossing_(maker=maker, values_to_cross=evaluator.values,
                                            crossing_values=data_crossing_values, delay=crossing_delay,
                                            max_cross=max_crossing, max_cross_lookback=max_crossing_lookback,
                                            max_history=not maker.live_recording_mode)

    return await store_evaluator_data(maker, evaluator, allow_signal_extension=True)
