def get_supported_evaluators():
    return sorted(["divergence", "dollar_cost_average", "dual_trend", "is_crossing", "is_oversold",
                   "is_overbought", "is_rising", "is_falling", "is_above", "is_below", "in_manual_range", "SFP",
                   "triple_trend", "three_peaks", "wasnt_below", "was_below", "was_above"])
