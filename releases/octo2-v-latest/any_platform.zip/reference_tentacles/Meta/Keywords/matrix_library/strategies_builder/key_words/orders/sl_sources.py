from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_


async def activate_sl_indicator(ctx, path, managed_order_settings, is_trailing_stop=False):
    from tentacles.Meta.Keywords.matrix_library.strategies_builder.evaluators.evaluators_handling import Evaluator_
    sl_evaluator = Evaluator_(ctx.maker, input_path_root=path)
    sl_values = await sl_evaluator.init_as_sl_source_and_get_data(ctx.maker, is_trailing_stop=is_trailing_stop)
    times = await get_candles_(ctx.maker, "time")
    indicator_dict = {}
    for index in range(1, len(sl_values)):
        indicator_dict[times[-index]] = sl_values[-index]

    # except AttributeError:
    #     ctx.logger.error(f"Strategy Maker: No Sl cache found for Managed Order ({sl_evaluator.input_path_root})")
    indicator_cache = SL_cache()

    sl_evaluator.cache_path += "trail" if is_trailing_stop else ""

    indicator_cache.data[sl_evaluator.cache_path] = indicator_dict
    indicator_cache.managed_orders[sl_evaluator.input_path_root] = sl_evaluator.cache_path
    key = "b-" if ctx.exchange_manager.is_backtesting else "l-"

    managed_order_settings.indicator_cache[key + "sl_cache"] = indicator_cache


async def activate_trailing_sl_indicator(ctx, path, managed_order_settings):
    await activate_sl_indicator(ctx, path, managed_order_settings, is_trailing_stop=True)


def get_sl_indicator(ctx, managed_orders_settings):
    key = "b-" if ctx.exchange_manager.is_backtesting else "l-"
    try:
        return managed_orders_settings.indicator_cache[key + "sl_cache"].data[
            managed_orders_settings.input_root_path][ctx.trigger_cache_timestamp]
    except KeyError:
        ctx.logger.error("SL indicator doesnt have a value for the current candle. Check the candle history size")
        return False


def get_trailing_sl_indicator(ctx, managed_orders_settings):
    key = "b-" if ctx.exchange_manager.is_backtesting else "l-"
    try:
        return managed_orders_settings.indicator_cache[key + "sl_cache"].data[
            managed_orders_settings.input_root_path + "trail"][ctx.trigger_cache_timestamp]
    except KeyError:
        ctx.logger.error(
            "SL trailing indicator doesnt have a value for the current candle. Check the candle history size")
        raise False


class SL_cache:
    data = {}
    managed_orders = {}
