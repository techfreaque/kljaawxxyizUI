from tentacles.Meta.Keywords.scripting_library.TA.trigger.eval_triggered import evaluator_get_result
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data


async def pack_evaluator_data(ctx, signals_data):
    times = await exchange_public_data.Time(ctx, max_history=True)
    data_length = len(signals_data)
    times = times[-data_length:]

    y_times = []
    for index, signal_value in enumerate(signals_data):
        if signal_value:
            y_times.append(times[index])
    return y_times


def pack_indicator_data(indicator_data, additional_cache=None):
    _cache = {"v": list(indicator_data)}
    if additional_cache:
        _cache.update(additional_cache)
    return [_cache]


async def indicator_get_backtesting_data(ctx, indicator_meta):
    if indicator_meta.trigger:
        indicator_values_dict = await evaluator_get_result(ctx, indicator_meta.indicator_class_name,
                                                           trigger=indicator_meta.trigger,
                                                           config_name=indicator_meta.config_name)
    else:
        indicator_values_dict = await evaluator_get_result(ctx, indicator_meta.indicator_class_name,
                                                           trigger=True,
                                                           config_name=indicator_meta.config_name)

    if indicator_values_dict:
        try:
            return indicator_values_dict[0][indicator_meta.value_key]
        except:
            return []


async def indicator_get_live_data(ctx, indicator_meta, minimum_length, maximum_length=None):
    await evaluator_get_result(ctx, tentacle_class=indicator_meta.indicator_class_name,
                               value_key="v",
                               # value_key=indicator_meta.value_key,
                               trigger=indicator_meta.trigger,
                               config_name=indicator_meta.config_name)
    return None

    # return await evaluator_get_minimum_results(ctx, minimum_length=minimum_length,
    #                                            tentacle_class=indicator_meta.indicator_class_name,
    #                                            value_key=indicator_meta.value_key,
    #                                            trigger=indicator_meta.trigger,
    #                                            config_name=indicator_meta.config_name,
    #                                            limit=maximum_length)
