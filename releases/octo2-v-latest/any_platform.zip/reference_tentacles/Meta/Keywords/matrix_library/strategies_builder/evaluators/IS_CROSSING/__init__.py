from .is_crossing import *
