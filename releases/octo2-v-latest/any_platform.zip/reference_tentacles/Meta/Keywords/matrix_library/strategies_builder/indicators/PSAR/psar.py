import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data \
    import get_candles_, user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_PSAR(maker, indicator, evaluator):
    acceleration_factor_step = await user_input2(maker, indicator, "PSAR acceleration factor step", "float", 0.02, 0)
    acceleration_factor_max = await user_input2(maker, indicator, "PSAR acceleration factor maximum", "float", 0.2, 0)
    candle_source_high = await user_select_candle_source_name(maker, indicator, "Select Candle High Source", "high")
    candle_source_low = await user_select_candle_source_name(maker, indicator, "Select Candle Low Source", "low")
    await allow_enable_plot(maker, indicator, "Plot Parabolic SAR")
    data = tulipy.psar(await get_candles_(maker, candle_source_high), await get_candles_(maker, candle_source_low),
                       acceleration_factor_step, acceleration_factor_max)
    data_source = {"v": {"title": f"Parabolic SAR ({acceleration_factor_step}-{acceleration_factor_max})",
                         "data": data, "chart_location": "main-chart"}}
    return await store_indicator_data(maker, indicator, data_source)
