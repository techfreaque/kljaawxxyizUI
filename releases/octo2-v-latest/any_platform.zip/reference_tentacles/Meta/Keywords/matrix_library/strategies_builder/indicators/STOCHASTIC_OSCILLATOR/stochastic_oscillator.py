import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_stochastic_oscillator(maker, indicator, evaluator):
    k_period = await user_input2(maker, indicator, "stochastic %k length", "int", 14)
    slowing_period = await user_input2(maker, indicator, "stochastic %k smoothing", "int", 1)
    d_period = await user_input2(maker, indicator, "stochastic %d smoothing", "int", 3)
    await allow_enable_plot(maker, indicator, "plot stochastic oscillator")
    stoch_k, stoch_d = tulipy.stoch(await get_candles_(maker, "high"), await get_candles_(maker, "low"),
                                    await get_candles_(maker, "close"), k_period, slowing_period, d_period)
    data = {"v": {"title": "stochastic oscillator k", "data": stoch_k, "chart_location": "sub-chart"},
            "d": {"title": "stochastic oscillator d", "data": stoch_d, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data)
