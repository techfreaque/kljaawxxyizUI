from octobot_trading.modes.script_keywords import user_input
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2


async def get_static_value(maker, indicator, evaluator):
    static_value = await user_input2(maker, indicator, "select a static value", "float", 40)
    await allow_enable_plot(maker, indicator, "Plot static value")
    values = ([float(static_value)] * len(await get_candles_(maker, "close")))
    data = {"v": {"title": f"static value: {static_value}", "data": values, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data)
