from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
from tentacles.Meta.Keywords.scripting_library.data.writing.plotting import plot
from tentacles.Meta.Keywords.scripting_library.data.writing.write_evaluator_cache import store_indicator_history
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2


async def store_indicator_plots(maker, config_path, main_data, additional_values_by_key=None):
    if maker.ctx.exchange_manager.is_backtesting \
            or (not maker.ctx.exchange_manager.is_backtesting and not maker.live_recording_mode):
        await store_indicator_history(maker.ctx, main_data, value_key=config_path + "v",
                                      additional_values_by_key=additional_values_by_key)
    else:
        await maker.ctx.set_cached_value(main_data[-1], config_path + "lv")
        for value_key in additional_values_by_key:
            await maker.ctx.set_cached_value(additional_values_by_key[value_key][-1], value_key)


async def store_indicator_data(maker, indicator, data, force_plot_disable=False, own_yaxis=False):
    indicator.data = {}
    additional_values_by_key = {}
    main_data = None
    for value_key in data:
        if indicator.plot and not force_plot_disable:
            if value_key == "v":
                main_data = data[value_key]["data"]
            else:
                _value_key = indicator.config_path_short + "l" + value_key if maker.live_recording_mode \
                    else indicator.config_path_short + value_key
                additional_values_by_key[_value_key] = data[value_key]["data"]
        indicator.data[value_key] = data[value_key]
        if len(data[value_key]["data"]) == 0:
            indicator.plot = False
            maker.ctx.logger.error(f"Data Source: {data[value_key]['title']} data is empty check Candles history size. "
                                   f"This error can be ignored while backtesting")
    if indicator.plot and not force_plot_disable:
        await store_indicator_plots(maker, indicator.config_path_short, main_data, additional_values_by_key)
        for index, value_key in enumerate(data):
            _value_key = indicator.config_path_short + "l" + value_key if maker.live_recording_mode \
                else indicator.config_path_short + value_key
            await plot(maker.ctx, data[value_key]["title"], cache_value=_value_key,
                       chart=data[value_key]["chart_location"], color="red",
                       own_yaxis=own_yaxis if index == 0 else False)
    return indicator.data


async def store_evaluator_plots(maker, values, signals, second_values=None):  # , additional_values_by_key=None):
    if maker.ctx.exchange_manager.is_backtesting \
            or (not maker.ctx.exchange_manager.is_backtesting and not maker.live_recording_mode):
        data_length = len(signals)
        times = await get_candles_(maker, "time")
        times = times[-data_length:]
        if second_values:
            second_values = second_values[-data_length:]
        y_cache = []
        y_cache_second = []
        y_times = []
        indicator_values = values[-data_length:]
        for index, signal in enumerate(signals):
            if signal:
                y_cache.append(indicator_values[index])
                y_times.append(times[index])
                if second_values:
                    y_cache_second.append(second_values[index])
        additional_cache = {
            maker.strategies[maker.current_strategy_id].
                evaluators[maker.current_evaluator_id].settings.config_path_short + "v2": y_cache_second
        } if second_values else {}

        await maker.ctx.set_cached_values(values=y_cache, cache_keys=y_times,
                                          value_key=maker.strategies[maker.current_strategy_id].
                                          evaluators[maker.current_evaluator_id].settings.config_path_short + "v",
                                          additional_values_by_key=additional_cache)
    else:
        try:
            signals = signals[-1]
        except:
            pass
        if signals == 1:
            _value_key = maker.strategies[maker.current_strategy_id].evaluators[maker.current_evaluator_id]. \
                             settings.config_path_short + "lv" if maker.live_recording_mode else maker.strategies[maker.
                current_strategy_id].evaluators[maker.current_evaluator_id].settings.config_path_short + "v"
            await maker.ctx.set_cached_value(values[-1], _value_key)
            if second_values:
                await maker.ctx.set_cached_value(second_values[-1], _value_key + "2")


async def store_evaluator_data(maker, evaluator, allow_signal_extension=False):
    if allow_signal_extension:
        evaluator.signal_valid_for \
            = await user_input2(maker, evaluator, "extend signal X candles", "int", 0)
        if evaluator.signal_valid_for != 0:
            signals = []
            for index, signal in enumerate(evaluator.signals):
                if signal == 1:
                    signals.append(signal)
                else:
                    try:
                        if max(evaluator.signals[index - evaluator.signal_valid_for:index]) == 1:
                            signals.append(1)
                        else:
                            signals.append(0)
                    except Exception:
                        signals.append(0)
            evaluator.signals = signals

    if evaluator.plot:
        await store_evaluator_plots(maker, evaluator.values, evaluator.signals, evaluator.second_values)
        _value_key = maker.strategies[maker.current_strategy_id].evaluators[maker.current_evaluator_id]. \
                         settings.config_path_short + "lv" if maker.live_recording_mode \
            else maker.strategies[maker.current_strategy_id].evaluators[maker.
                        current_evaluator_id].settings.config_path_short + "v"
        await plot(maker.ctx, evaluator.title, cache_value=_value_key, chart=evaluator.chart_location,
                   color="green", mode="markers", line_shape=None)
        if evaluator.second_values:
            await plot(maker.ctx, evaluator.second_title, cache_value=_value_key + "2",
                       chart=evaluator.second_chart_location, color="green", mode="markers", line_shape=None)

    if maker.ctx.exchange_manager.is_backtesting:
        return {"v": evaluator.signals}
    else:
        try:
            current_signal = evaluator.signals[-1]
        except:
            current_signal = evaluator.signals
        return {"v": current_signal}


async def allow_enable_plot(maker, evaluator, text="Plot Evaluator"):
    try:
        evaluator.plot = await user_input2(maker, evaluator, text, "boolean", True, show_in_summary=False) \
            if maker.enable_plot else False
    except:
        evaluator.plot = await user_input2(maker, evaluator, text, "boolean", True, show_in_summary=False) \
            if maker.enable_plot else False
