from octobot_trading.modes import Context
from octobot_trading.modes.script_keywords.basic_keywords import user_inputs
from tentacles.Meta.Keywords.matrix_library.strategies_builder.evaluators.evaluators_handling import Evaluator_
from tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager import managed_orders
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.tools.utilities \
    import start_measure_time, end_measure_time
from tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.stop_losses import stop_loss_handling


class StrategyData:
    def __init__(self, maker, ctx: Context):
        self.supported_evaluators = maker.supported_evaluators
        self.signals = {}
        self.ctx = ctx
        self.strategy_id = maker.current_strategy_id
        self.input_path = f"evaluator/Strategy_{maker.current_strategy_id + 1}_Settings"
        # self.input_path = maker.input_path + f"/Strategy {current_strategy_id+1} Settings"
        self.config_path_short = "s1"
        self.trading_side = ""
        self.trading_side_key = ""
        self.nr_of_indicators = 0
        self.evaluators = {}
        self.order_settings = None

    async def build_and_trade_strategy_live(self, maker, ctx):
        await self.init_strategy(maker)
        signal = 1
        for evaluator_id in range(0, self.nr_of_indicators):
            await self.get_evaluator(maker, ctx, evaluator_id)
            signal = self.signals[evaluator_id] if signal == 1 else 0
        await self.set_managed_order_settings(ctx, maker)
        if signal == 1:
            await managed_orders.managed_order(ctx, trading_side=self.trading_side,
                                               orders_settings=self.order_settings)
        await self.handle_trailing_stop(ctx)

    async def build_strategy_backtesting_cache(self, maker, ctx):
        await self.init_strategy(maker)
        m_time = start_measure_time()
        for evaluator_id in range(0, self.nr_of_indicators):
            await self.get_evaluator(maker, ctx, evaluator_id)

        await self.set_managed_order_settings(ctx, maker)
        end_measure_time(m_time, f" strategy maker - calculating evaluators for strategy {self.strategy_id}",
                         min_duration=9)

    async def trade_strategy_backtesting(self, ctx, maker):
        ctx.maker = maker
        await managed_orders.managed_order(ctx, trading_side=self.trading_side,
                                           orders_settings=self.order_settings)

    async def init_strategy(self, maker):
        maker.strategy_name = await user_inputs.user_input(maker.ctx, "Strategy name and version",
                                                           "text", "my strategy", show_in_optimizer=False,
                                                           path=self.input_path)
        self.nr_of_indicators = await user_inputs. \
            user_input(maker.ctx, f"Amount of Evaluators combined together (s{self.strategy_id + 1})", "int", 2, 1,
                       path=self.input_path)
        self.trading_side = await user_inputs. \
            user_input(maker.ctx, f"Trading direction (s{self.strategy_id + 1})", "options", "long",
                       options=["long", "short"],
                       path=self.input_path)
        self.trading_side_key = "l" if self.trading_side == "long" else "s"
        self.input_path = f"{self.input_path}/Strategy"

    async def set_managed_order_settings(self, ctx, maker):
        # try:
        ctx.maker = maker
        self.order_settings = await managed_orders. \
            activate_managed_orders(ctx, user_input_path=f"evaluator/Strategy_{int(self.strategy_id) + 1}_Settings"
                                                         f"/Strategy/Managed Order Settings")
        # except Exception as e:
        # raise RuntimeError("There is probably an issue in your Managed Order "
        #                    "configuration. Check the settings: " + str(e))

    async def get_evaluator(self, maker, ctx: Context, evaluator_id: int):
        sm_time = start_measure_time()
        evaluator = Evaluator_(maker, self.input_path, self.config_path_short, self.supported_evaluators)
        maker.current_evaluator_id = evaluator_id
        await evaluator.init_evaluator(maker, ctx, evaluator_id)
        self.evaluators[evaluator_id] = evaluator
        self.signals[evaluator_id] = await evaluator.evaluate_and_get_data(maker, ctx)
        maker.evaluators[evaluator.config_path] = evaluator
        end_measure_time(sm_time, f" strategy maker - calculating evaluator {evaluator_id + 1} "
                                  f"{evaluator.name} {evaluator.class_name}", min_duration=9)

    async def handle_trailing_stop(self, ctx):
        if self.order_settings.sl_trail_type != self.order_settings.sl_trail_types['dont_trail']:
            await stop_loss_handling.trail_stop_losses(ctx, self.order_settings)
