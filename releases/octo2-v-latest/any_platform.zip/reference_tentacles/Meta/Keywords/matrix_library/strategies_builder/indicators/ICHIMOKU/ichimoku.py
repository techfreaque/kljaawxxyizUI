from finta import TA as fta
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
import pandas as pd
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_ichimoku(maker, indicator, evaluator):
    conversion_line_length = await user_input2(maker, indicator, "conversion line length", "int", 9)
    base_line_length = await user_input2(maker, indicator, "base line length", "int", 26)
    leading_span_b_length = await user_input2(maker, indicator, "leading span b length", "int", 52)
    displacement = await user_input2(maker, indicator, "displacement", "int", 26)
    await allow_enable_plot(maker, indicator, "Plot ichimoku")
    df = pd.DataFrame({"open": await get_candles_(maker, "open"), "high": await get_candles_(maker, "high"),
                       "low": await get_candles_(maker, "low"), "close": await get_candles_(maker, "close")})
    ichimoku_df = fta.ICHIMOKU(df, tenkan_period=conversion_line_length, kijun_period=base_line_length,
                               senkou_period=leading_span_b_length, chikou_period=displacement)
    ichimoku_df = ichimoku_df.drop(['CHIKOU'], axis=1)
    ichimoku_df = ichimoku_df.dropna()
    data = {"v": {"title": "ichimoku conversion line",
                  "data": list(ichimoku_df["TENKAN"]), "chart_location": "main-chart"},
            "b": {"title": "ichimoku base line",
                  "data": list(ichimoku_df["KIJUN"]), "chart_location": "main-chart"},
            "lsb": {"title": "ichimoku leading span b",
                    "data": list(ichimoku_df["SENKOU"]), "chart_location": "main-chart"},
            "lsa": {"title": "ichimoku leading span a",
                    "data": list(ichimoku_df["senkou_span_a"]), "chart_location": "main-chart"}}
    return await store_indicator_data(maker, indicator, data)
