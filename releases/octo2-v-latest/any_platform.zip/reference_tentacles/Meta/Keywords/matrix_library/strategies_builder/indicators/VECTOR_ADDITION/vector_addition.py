import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data \
    import get_candles_, user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_vector_addition(maker, indicator, evaluator):
    candle_source_high = await user_select_candle_source_name(maker, indicator, "Select Candle High Source", "high")
    candle_source_low = await user_select_candle_source_name(maker, indicator, "Select Candle Low Source", "low")
    await allow_enable_plot(maker, indicator, "Plot vector addition")
    data = tulipy.add(await get_candles_(maker, candle_source_low), await get_candles_(maker, candle_source_high))
    data_source = {"v": {"title": f"vector addition", "data": data, "chart_location": "main-chart"}}
    return await store_indicator_data(maker, indicator, data_source)
