import octobot_commons.enums as commons_enums
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data \
    import user_select_candle_source_name


def get_supported_price_indicators_():
    return ["ATR Low", "ATR High", "EMA", "fib_line", "HMA", "ichimoku conversion line", "ichimoku base line",
            "ichimoku leading span b", "ichimoku leading span a", "keltner channel base", "SSL_channel Up",
            "SSL_channel Down", "keltner channel low", "keltner channel high", "PSAR", "SMA", "supertrend", "VWAP",
            "VWMA", "Bollinger Band High", "Bollinger Band Middle", "Bollinger Band Low", "halftrend", "heikin_ashi"]


def get_supported_oscillators_():
    return ["ADX", "accumulation_distribution_oscillator", "awesome_oscillator", "CCI", "EV_MACD", "EV_MACD signal",
            "MACD", "MACD signal", "MACD histogram", "MFI", "OBV", "RSI", "stochastic oscillator d",
            "stochastic oscillator k", "stochastic_RSI k", "stochastic_RSI d", "VW_MACD", "VW_MACD signal",
            "growth rate", "growth rate MA", "vector_absolute_value", "accumulation_distribution_line",
            "vector_addition", "average_directional_movement_rating", "absolute_price_oscillator",
            "Aroon UP", "Aroon Down", "Aroon_oscillator", "balance_of_power", "chande_momentum_oscillator"]


def get_supported_indicator_config(indicator_meta):
    indicator_meta.indicator_class_name = indicator_meta.indicator_name
    if "MACD" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "EV_MACD signal":
            indicator_meta.value_key = "s"
            indicator_meta.indicator_class_name = "EV_MACD"
        elif indicator_meta.indicator_name == "VW_MACD signal":
            indicator_meta.value_key = "s"
            indicator_meta.indicator_class_name = "VW_MACD"
        elif indicator_meta.indicator_name == "MACD signal":
            indicator_meta.value_key = "s"
            indicator_meta.indicator_class_name = "MACD"
        elif indicator_meta.indicator_name == "MACD histogram":
            indicator_meta.value_key = "h"
            indicator_meta.indicator_class_name = "MACD"
    elif "stochastic_RSI" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "stochastic_RSI d":
            indicator_meta.value_key = "d"
        indicator_meta.indicator_class_name = "stochastic_RSI"
    elif "Bollinger Band" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "Bollinger Band Middle":
            indicator_meta.value_key = "m"
        elif indicator_meta.indicator_name == "Bollinger Band Low":
            indicator_meta.value_key = "l"
        indicator_meta.indicator_class_name = "bollinger_bands"
    elif "Aroon " in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "Aroon UP":
            indicator_meta.value_key = "u"
        indicator_meta.indicator_class_name = "Aroon"
    elif "ichimoku" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "ichimoku base line":
            indicator_meta.value_key = "b"
        elif indicator_meta.indicator_name == "ichimoku leading span b":
            indicator_meta.value_key = "lsb"
        elif indicator_meta.indicator_name == "ichimoku leading span a":
            indicator_meta.value_key = "lsa"
        indicator_meta.indicator_class_name = "ichimoku"
    elif "stochastic oscillator" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "stochastic oscillator d":
            indicator_meta.value_key = "d"
        indicator_meta.indicator_class_name = "stochastic_oscillator"
    elif indicator_meta.indicator_name == "current price" or indicator_meta.indicator_name == "price data":
        indicator_meta.is_evaluator = False
    elif "keltner channel" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "keltner channel low":
            indicator_meta.value_key = "l"
        elif indicator_meta.indicator_name == "keltner channel high":
            indicator_meta.value_key = "h"
        indicator_meta.indicator_class_name = "keltner_channel"
    elif "growth rate" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "growth rate MA":
            indicator_meta.value_key = "ma"
        indicator_meta.indicator_class_name = "growth_rate"
    elif "SSL_channel" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "SSL_channel Up":
            indicator_meta.value_key = "up"
        indicator_meta.indicator_class_name = "SSL_channel"
    elif "ATR" in indicator_meta.indicator_name:
        if indicator_meta.indicator_name == "ATR High":
            indicator_meta.value_key = "h"
        indicator_meta.indicator_class_name = "ATR"
    elif indicator_meta.indicator_name == "current price" or indicator_meta.indicator_name == "price data":
        indicator_meta.is_evaluator = False
        indicator_meta.value_key = "p"
    return indicator_meta


def get_supported_indicators_(enable_oscillators=True, enable_price_indicators=True,
                              enable_static_value=True, enable_price_data=True):
    available_sources = []
    indicator_sources = []
    if enable_price_data:
        available_sources.append("price data")
    if enable_static_value:
        available_sources.append("static_value")
    if enable_oscillators:
        indicator_sources += sorted(get_supported_oscillators_(), key=str.casefold)
    if enable_price_indicators:
        indicator_sources += get_supported_price_indicators_()
        indicator_sources = sorted(indicator_sources, key=str.casefold)
    return available_sources + indicator_sources


class IndicatorMeta:
    value_key = commons_enums.CacheDatabaseColumns.VALUE.value
    is_evaluator = True
    indicator_class_name = "none"
    indicator_name = "none"
    config_name = "none"
    config_path = "none"
    candle_source = None
    indicator_id = 0
    trigger = True


def get_supported_shared_conf_indicators(maker, indicator):
    source_list = ["this indicator"]
    sources_available = False
    for indicator_key in maker.indicators:
        if maker.indicators[indicator_key].indicator_class_name == indicator.indicator_class_name:
            source_list.append(indicator_key)
            sources_available = True
    return source_list, sources_available


async def get_shared_indicator_config(maker, evaluator, indicator_meta, data_source_name):
    indicator_meta = get_supported_indicator_config(indicator_meta)
    sources_list, sources_available = get_supported_shared_conf_indicators(maker, indicator_meta)
    if sources_available:
        new_evaluator_id = await user_input2(maker, evaluator, f"use {data_source_name}-{indicator_meta.indicator_name} config from",
                                             "options", "this indicator", show_in_summary=False,
                                             options=sources_list)
    else:
        new_evaluator_id = sources_list[0]
    indicator_meta.trigger = False
    if new_evaluator_id == "this indicator":
        if indicator_meta.indicator_name == "price data" or indicator_meta.indicator_name == "current price":
            indicator_meta.candle_source \
                = await user_select_candle_source_name(maker, evaluator,
                                                       name=f"Select Candle Source for {data_source_name}i{indicator_meta.indicator_id}",
                                                       def_val="low", enable_volume=indicator_meta.enable_volume)
            indicator_meta.chart_location = "sub-chart" if user_select_candle_source_name == "volume" else "main-chart"
        else:  # indicators
            indicator_meta.chart_location = "sub-chart"
        indicator_meta.trigger = True
        maker.indicators[indicator_meta.cache_path] = indicator_meta
    else:
        indicator_meta.cache_path = new_evaluator_id
        return indicator_meta

    return maker.indicators[indicator_meta.cache_path]
