import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data \
    import get_candles_, user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_OBV(maker, indicator, evaluator):
    candle_source = await user_select_candle_source_name(maker, indicator, "Select OBV Candle Source",
                                                         enable_volume=True)
    await allow_enable_plot(maker, indicator, "Plot OBV")
    candle_data = await get_candles_(maker, candle_source)
    data = tulipy.obv(candle_data, await get_candles_(maker, "volume"))
    data_source = {"v": {"title": f"OBV {candle_source}", "data": data, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data_source)
