from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_evaluator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.indicators.indicator_handling \
    import get_configurable_indicator, activate_configurable_indicator
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words. \
    indicators.above_below.is_above_below import is_above


async def get_is_above(maker, evaluator):
    above_values_title = await activate_configurable_indicator(maker, evaluator, def_val="price data",
                                                               data_source_name="data source above")
    below_values_title = await activate_configurable_indicator(maker, evaluator, data_source_name="data source below",
                                                               def_val="EMA", indicator_id=2)
    confirmation_time = await user_input2(maker, evaluator, "signal delay", "int", 0)
    above_percent = await user_input2(maker, evaluator, f"{above_values_title} needs to be x "
                                                        f"percent above {below_values_title}",  "int", 0)
    await allow_enable_plot(maker, evaluator, f"Plot when {above_values_title} is above {below_values_title}")
    data_above_values, evaluator.chart_location, above_values_detailed_title \
        = await get_configurable_indicator(maker, evaluator)
    evaluator.values, _, below_values_detailed_title = await get_configurable_indicator(maker, evaluator,
                                                                                        indicator_id=2)
    evaluator.signals = is_above(below_data=evaluator.values, above_data=data_above_values,
                                 confirmation_time=confirmation_time, above_percent=above_percent,
                                 max_history=not maker.live_recording_mode)

    evaluator.title = f"{above_values_detailed_title} is above {below_values_detailed_title}"

    return await store_evaluator_data(maker, evaluator)
