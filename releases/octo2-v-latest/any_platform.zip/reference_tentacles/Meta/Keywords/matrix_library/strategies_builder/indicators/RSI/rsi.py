import tulipy
from octobot_trading.modes.script_keywords import user_input
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_, \
    user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2


async def get_RSI(maker, indicator, evaluator):
    length = await user_input2(maker, indicator, "RSI length", "int", 50, 0)
    candle_source = await user_select_candle_source_name(maker, indicator, "Select RSI Candle Source",
                                                         enable_volume=True)
    await allow_enable_plot(maker, indicator, "Plot RSI")
    candle_data = await get_candles_(maker, candle_source)
    data = tulipy.rsi(candle_data, length)
    data_sources = {"v": {"title": f"RSI {length}", "data": data, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data_sources)
