from abc import ABC

import pandas as pd

from tentacles.Meta.Keywords.matrix_library.strategies_builder.evaluators.supported_evaluators \
    import get_supported_evaluators
from .init_strategy import StrategyData
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.backtesting.skip_runs import \
    skip_backtesting_runs, init_skip_backtesting_runs
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
import octobot_commons.enums as common_enums
from octobot_trading.modes.script_keywords.basic_keywords import user_inputs
from octobot_trading.modes.script_keywords import emit_trading_signals
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.tools.utilities \
    import start_measure_time, end_measure_time, end_measure_live_time
from tentacles.Meta.Keywords.matrix_library.trade_analysis.trade_analysis_activation \
    import handle_trade_analysis_for_current_candle
from tentacles.Meta.Keywords.scripting_library.backtesting import backtesting_settings
from octobot_trading.modes.script_keywords import user_select_emit_trading_signals, basic_keywords
from tentacles.Meta.Keywords.scripting_library.UI.inputs import select_history, select_time_frame
from tentacles.Meta.Keywords.scripting_library.backtesting import metadata
from tentacles.Meta.Keywords.scripting_library.data.writing import plotting
import octobot_trading.modes.scripted_trading_mode.abstract_scripted_trading_mode as abstract_scripted_trading_mode


class StrategyMaking(abstract_scripted_trading_mode.AbstractScriptedTradingModeProducer, ABC):

    def __init__(self, channel, config, trading_mode, exchange_manager):
        super().__init__(channel, config, trading_mode, exchange_manager)
        self.strategy_signals = {}
        self.strategy_name = ""
        self.ctx = None
        self.is_backtesting = None
        self.trigger_time_frames = []
        self.nr_of_strategies = 0
        self.enable_copy_trading = False
        self.candles = {}
        self.strategies = {}
        self.evaluators = {}
        self.indicators = {}
        self.current_strategy_id = None
        self.current_evaluator_id = None
        self.current_indicator_id = None
        self.live_plotting_mode = False
        self.live_recording_mode = False
        self.enable_plot = True
        self.whitelist_mode = True
        self.input_path = None  # "evaluator/Strategy_Maker_Settings"
        self.config_path_short = "m"
        self.strategy_cache = {}
        self.all_timestamps = None
        self.any_trading_timestamps = None
        self.supported_evaluators = get_supported_evaluators()

    async def build_and_trade_strategies_live(self, ctx):
        m_time = start_measure_time()

        await self.init_strategy_maker(ctx, is_backtesting=False)
        for strategy_id in range(0, self.nr_of_strategies):
            await self.build_and_trade_strategy_live(ctx, strategy_id)
        if self.enable_copy_trading:
            await emit_trading_signals(ctx)
        await handle_trade_analysis_for_current_candle(ctx)
        await init_skip_backtesting_runs(ctx)
        end_measure_live_time(ctx, m_time, f" strategy maker - live trading")

    async def build_strategies_backtesting_cache(self, ctx):
        s_time = start_measure_time(" strategy maker - building backtesting cache")
        await self.init_strategy_maker(ctx, is_backtesting=True)

        self.all_timestamps = await get_candles_(self, "time")
        for strategy_id in range(0, self.nr_of_strategies):
            await self.build_strategy_backtesting_cache(ctx, strategy_id)

        self.any_trading_timestamps = self.merge_signals_in_backtesting()
        self.handle_backtesting_timestamp_whitelist()

        # await handle_trade_analysis_for_backtesting_first_candle(ctx, strategy_maker_data)
        end_measure_time(s_time, f" strategy maker - building strategy for "
                                 f"{self.ctx.time_frame} {len(self.any_trading_timestamps)} trades")

    async def trade_strategies_backtesting(self, ctx):
        m_time = start_measure_time()
        current_signals = self.get_signal_while_backtesting(ctx)
        for strategy_id in current_signals:
            await self.strategies[strategy_id].trade_strategy_backtesting(ctx, self)
        await skip_backtesting_runs(ctx)
        for strategy_id in self.strategies:
            await self.strategies[strategy_id].handle_trailing_stop(ctx)

        await handle_trade_analysis_for_current_candle(ctx)
        end_measure_time(m_time, f" strategy maker - warning backtesting candle took longer than expected",
                         min_duration=1)

    async def init_strategy_maker(self, ctx, is_backtesting=False):
        self.ctx = ctx
        self.strategy_signals = {}

        self.candles = {}
        self.strategies = {}
        self.evaluators = {}
        self.indicators = {}
        self.strategy_cache = {}

        self.is_backtesting = is_backtesting
        metadata.set_script_name(self.ctx, self.strategy_name)

        await self.handle_plotting_mode()

        self.trigger_time_frames = await select_time_frame.set_trigger_time_frames(self.ctx)
        await select_history.set_candles_history_size(self.ctx, 10)
        await basic_keywords.set_leverage(self.ctx, await basic_keywords.user_select_leverage(self.ctx))

        self.nr_of_strategies = 1
        # await user_inputs.user_input(ctx, "Amount of Strategies", "int", 1, 1, order=9.5)

        # await gains.simulate_hedge_fund_gains(ctx)
        # if not backtesting_settings.is_registered_backtesting_timestamp_whitelist(ctx):
        # final_whitelist = await gains.get_simulated_hedge_fund_gain_timestamps(ctx)
        self.whitelist_mode = await user_inputs.user_input(self.ctx, "Whitelist mode: backtest only candles with "
                                                                     "signals",
                                                           "boolean", False, path=self.input_path)

        self.enable_copy_trading = False
        if not self.is_backtesting:
            self.enable_copy_trading = await user_inputs.user_input(self.ctx, "enable copy trading host",
                                                                    "boolean", False, path=self.input_path)
            if self.enable_copy_trading:
                await user_select_emit_trading_signals(self.ctx, "my-strategy-id")

    async def build_and_trade_strategy_live(self, ctx, strategy_id):
        self.current_strategy_id = strategy_id
        self.strategies[strategy_id] = StrategyData(self, ctx)
        await self.strategies[strategy_id].build_and_trade_strategy_live(self, ctx)

    async def build_strategy_backtesting_cache(self, ctx, strategy_id):
        self.current_strategy_id = strategy_id
        self.strategies[strategy_id] = StrategyData(self, ctx)
        await self.strategies[strategy_id].build_strategy_backtesting_cache(self, ctx)
        self.strategy_signals[strategy_id] = self.strategies[strategy_id].signals

    def merge_signals_in_backtesting(self):
        try:
            tmp_signals = {}
            for strategy_id in self.strategy_signals:
                for evaluator_id in self.strategy_signals[strategy_id]:
                    tmp_signals[f"{strategy_id}-{evaluator_id}"] = pd.Series(
                        data=self.strategy_signals[strategy_id][evaluator_id],
                        index=self.all_timestamps[-len(
                            self.strategy_signals[strategy_id][evaluator_id]):])
            signals_df = pd.DataFrame(tmp_signals)
            any_signals_df = signals_df
            for strategy_id in self.strategy_signals:
                temp_strategy_cache = signals_df
                for evaluator_id in self.strategy_signals[strategy_id]:
                    any_signals_df = any_signals_df[(any_signals_df[f"{strategy_id}-{evaluator_id}"] == 1)]
                    temp_strategy_cache = temp_strategy_cache[
                        (temp_strategy_cache[f"{strategy_id}-{evaluator_id}"] == 1)]
                self.store_backtesting_signals_cache(temp_strategy_cache.index.values, strategy_id)

            return any_signals_df.index.values  # signals times
        except ValueError:
            return []

    async def handle_plotting_mode(self):
        self.enable_plot = await user_inputs.user_input(self.ctx, "enable plotting capability for backtests",
                                                        "boolean", False, path=self.input_path)
        if not self.is_backtesting:
            self.live_plotting_mode \
                = await user_inputs.user_input(self.ctx, "Live Plotting Mode", "options", "replot visible history",
                                               options=["disable live plotting",
                                                        "plot recording mode", "replot visible history"],
                                               show_in_summary=False, show_in_optimizer=False, path=self.input_path)
            if self.live_plotting_mode == "plot recording mode":
                self.live_recording_mode = True
                self.enable_plot = True
                await plotting.plot_candles(self.ctx)
            elif self.live_plotting_mode == "disable live plotting":
                self.enable_plot = False
                self.live_recording_mode = True
            else:
                self.live_recording_mode = False
                self.enable_plot = True
                await plotting.plot_candles(self.ctx)
        else:
            await plotting.plot_candles(self.ctx)

    def store_backtesting_signals_cache(self, trading_timestamps, strategy_id):
        for timestamp_id in trading_timestamps:
            try:
                self.strategy_cache[timestamp_id[strategy_id]] = self.strategies[strategy_id].trading_side_key
            except IndexError:
                self.strategy_cache[timestamp_id] = {strategy_id: self.strategies[strategy_id].trading_side_key}

    def get_signal_while_backtesting(self, ctx):
        try:
            return self.strategy_cache[ctx.trigger_cache_timestamp]
        except KeyError:
            return []

    def handle_backtesting_timestamp_whitelist(self):
        final_whitelist = []
        time_frame_sec = common_enums.TimeFramesMinutes[common_enums.TimeFrames(self.ctx.time_frame)] * 60
        for timestamp in self.any_trading_timestamps:
            final_whitelist.append(timestamp - time_frame_sec)
            final_whitelist.append(timestamp)
        if self.whitelist_mode and len(self.trigger_time_frames) == 1:
            backtesting_settings.register_backtesting_timestamp_whitelist(self.ctx, final_whitelist)

    def get_current_strategy(self):
        return self.strategies[self.current_strategy_id]
