# from tentacles.Meta.Keywords.scripting_library.data.reading.trading_settings \
#     import set_initialized_evaluation, get_initialized_evaluation
# from tentacles.Meta.Keywords.matrix_library.strategies_builder.strategy_making.strategy_building import \
#     trade_stratgies_for_current_backtesting_candle, build_and_trade_live_strategy, build_strategy_backtesting_cache
#
#
# async def make_strategy(ctx):
#     # live trading
#     if not ctx.exchange_manager.is_backtesting:
#         await build_and_trade_live_strategy(ctx)
#     # first back-testing candle
#     elif not get_initialized_evaluation(ctx, ctx.tentacle):
#         set_initialized_evaluation(ctx, ctx.tentacle)
#         await build_strategy_backtesting_cache(ctx)
#     # back-testing on all the other candles
#     else:
#         await trade_stratgies_for_current_backtesting_candle(ctx)
