from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.tools.utilities \
    import start_measure_time, end_measure_live_time
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder import indicators as indicators_module
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_


class IndicatorSettings:
    config_name = "none"
    shared_config = "disabled"
    plot = False
    class_name = "none"
    requested_value_key = "v"


class IndicatorData:
    pass


class Indicator:
    settings = IndicatorSettings()
    data = IndicatorData()


async def get_indicator_data(maker, indicator, indicator_value_key, evaluator):
    try:
        return maker.indicators[indicator.cache_path].data[indicator_value_key]["data"], \
               maker.indicators[indicator.cache_path].data[indicator_value_key]["chart_location"], \
               maker.indicators[indicator.cache_path].data[indicator_value_key]["title"]
    except (KeyError, AttributeError):
        try:
            m_time = start_measure_time()

            await eval(f'indicators_module.get_{indicator.indicator_class_name}(maker, indicator, evaluator)')
            end_measure_live_time(maker.ctx, m_time, f" strategy maker - calculating {indicator.indicator_class_name}", min_duration=9)

        except Exception as e:
            maker.ctx.logger.error(f"Indicator {indicator.indicator_class_name} failed to compute data. error: {e}")
            return [], "", ""
        maker.indicators[indicator.cache_path] = indicator
        return maker.indicators[indicator.cache_path].data[indicator_value_key]["data"], \
               maker.indicators[indicator.cache_path].data[indicator_value_key]["chart_location"], \
               maker.indicators[indicator.cache_path].data[indicator_value_key]["title"]


async def get_configurable_indicator(maker, evaluator, indicator_id=1):
    indicator_class_name = evaluator.indicators[indicator_id].indicator_class_name
    indicator_config_path = evaluator.indicators[indicator_id].cache_path
    indicator_value_key = evaluator.indicators[indicator_id].value_key
    if indicator_class_name == "price data":
        return await get_candles_(maker, source_name=maker.indicators[indicator_config_path].candle_source), \
               maker.indicators[indicator_config_path].chart_location, "price-data"
    else:
        indicator = maker.indicators[indicator_config_path]
        return await get_indicator_data(maker, indicator,
                                        indicator_value_key=indicator_value_key, evaluator=evaluator)


async def activate_configurable_indicator(maker, evaluator, data_source_name="Data Source", def_val="EMA",
                                          indicator_id=1, enable_oscillators=True, enable_price_indicators=True,
                                          enable_price_data=True, enable_volume=True, enable_static_value=True,
                                          enable_force_def_val=False):
    indicator_meta = indicators_module.IndicatorMeta()
    indicator_meta.indicator_id = indicator_id

    indicator_meta.enable_volume = enable_volume
    if enable_force_def_val:
        indicator_meta.indicator_name = def_val
    else:
        available_sources = indicators_module.get_supported_indicators_(enable_oscillators=enable_oscillators,
                                                                        enable_price_indicators=enable_price_indicators,
                                                                        enable_static_value=enable_static_value,
                                                                        enable_price_data=enable_price_data)
        indicator_meta.indicator_name = await user_input2(maker, evaluator, f"Select {data_source_name}",
                                                          "options", def_val, options=available_sources)
    indicator_meta.config_path = evaluator.config_path + f"/Indicator {indicator_id} - {data_source_name}"
    indicator_meta.cache_path = evaluator.cache_path + f"/Indicator {indicator_id} - {data_source_name}"
    indicator_meta.config_path_short = f"{evaluator.config_path_short}-i{indicator_id}"

    evaluator.indicators[indicator_id] \
        = await indicators_module.get_shared_indicator_config(maker, evaluator, indicator_meta, data_source_name)
    return indicator_meta.indicator_name
