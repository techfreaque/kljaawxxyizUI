import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_, \
    user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_absolute_price_oscillator(maker, indicator, evaluator):
    fast_length = await user_input2(maker, indicator, "Absolute Price Oscillator fast length", "int", 12)
    slow_length = await user_input2(maker, indicator, "Absolute Price Oscillator slow length", "int", 26)
    candle_source = await user_select_candle_source_name(maker, indicator, "Select Candle Source")
    await allow_enable_plot(maker, indicator, "plot Absolute Price Oscillator")
    try:
        data = tulipy.apo(await get_candles_(maker, candle_source), fast_length, slow_length)
    except tulipy.lib.InvalidOptionError:
        raise RuntimeError(f"Absolute Price Oscillator (slow: {slow_length} fast: {fast_length}): "
                           f"fast length cant be longer than slow length")
    data = {"v": {"title": f"Absolute Price Oscillator ({fast_length}-{slow_length})",
                  "data": data, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data)
