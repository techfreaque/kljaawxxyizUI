import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_heikin_ashi(maker, indicator, evaluator):
    source = await user_input2(maker, indicator, "select heikin ashi source", "options", "Heikin Ashi close",
                               options=["Heikin Ashi open", "Heikin Ashi high", "Heikin Ashi low", "Heikin Ashi close"])
    await allow_enable_plot(maker, indicator, "Plot Heikin Ashi")
    data_source = {"v": {"title": f"{source}", "data": await get_candles_(maker, source),
                         "chart_location": "main-chart"}}
    return await store_indicator_data(maker, indicator, data_source)
