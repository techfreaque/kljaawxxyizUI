import numpy as np


def is_above(below_data, above_data, confirmation_time=1, above_percent=1, max_history=True):
    data_len = min([len(below_data), len(above_data)])
    below_data = below_data[-data_len:]
    above_data = above_data[-data_len:]
    below_data = np.asarray(below_data)
    above_data = np.asarray(above_data)
    signals = []
    for i in range(0, data_len):
        range_start = -i - confirmation_time - 1
        range_end = (-i if i != 0 else None)
        signals.append(1 if all(
            (below_data[range_start:range_end] * ((100 + above_percent) / 100))
                                < above_data[range_start:range_end]
        ) else 0)
        if not max_history:
            break
    signals.reverse()
    return signals


def is_below(above_data, below_data, confirmation_time=1, below_percent=1, max_history=True):
    data_len = min([len(below_data), len(above_data)])
    below_data = below_data[-data_len:]
    above_data = above_data[-data_len:]
    below_data = np.asarray(below_data)
    above_data = np.asarray(above_data)
    signals = []
    for i in range(0, data_len):
        range_start = -i - confirmation_time - 1
        range_end = (-i if i != 0 else None)
        signals.append(1 if all(
            (above_data[range_start:range_end] * ((100 - below_percent) / 100))
                                > below_data[range_start:range_end]
        ) else 0)
        if not max_history:
            break
    signals.reverse()
    return signals
