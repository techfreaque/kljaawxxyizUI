import pandas as pd
import pandas_ta as pta
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2


async def get_supertrend(maker, indicator, evaluator):
    multiplier = await user_input2(maker, indicator, "supertrend ATR multiplier", "int", 3)
    length = await user_input2(maker, indicator, "supertrend ATR period", "int", 10)
    await allow_enable_plot(maker, indicator, "Plot Supertrend")
    highs = pd.Series(await get_candles_(maker, "high"))
    lows = pd.Series(await get_candles_(maker, "low"))
    closes = pd.Series(await get_candles_(maker, "close"))
    strend_df = pta.supertrend(highs, lows, closes, length=length, multiplier=multiplier)
    strend_df = strend_df.drop(strend_df.columns[[2, 3]], axis=1)
    strend_df = strend_df.dropna()
    supert = strend_df.iloc[1:, 0]
    data_sources = {"v": {"title": f"supertrend (m:{multiplier}-l:{length})",
                          "data": list(supert), "chart_location": "main-chart"}}
    return await store_indicator_data(maker, indicator, data_sources)
