from tentacles.Meta.Keywords.scripting_library.data.writing import plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.indicators.indicator_handling \
    import activate_configurable_indicator, get_configurable_indicator
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.pivots_lib.multi_pivots_lib \
    import pivot_lows_, pivot_highs_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2


async def get_pivots(maker, indicator, evaluator):
    selected_indicator = await activate_configurable_indicator(maker, indicator, def_val="price data",
                                                               data_source_name="data source for pivots")
    pivot_lookback = evaluator.pivot_lookback \
                     or await user_input2(maker, indicator, f"pivot lookback length", "int", 2, 1)

    pivot_low_active = await user_input2(maker, indicator, f"activate pivot lows",
                                         def_val=True, input_type="boolean", show_in_summary=False)
    # pivot_high_active = await user_input(maker.ctx, f"{indicator.config_path} activate pivot highs",
    #                                      def_val=False, input_type="boolean")
    await allow_enable_plot(maker, indicator, f"plot {selected_indicator} Pivots")

    data_source_values, chart_location, data_source_title = await get_configurable_indicator(maker, indicator)

    data = {"v": {"title": f"{data_source_title} pivots (lb:{pivot_lookback})",
                  "data": {}, "chart_location": chart_location}}
    if pivot_low_active:

        pivot_low_data = pivot_lows_(data_source_values, swing_history=pivot_lookback)
        pivot_low_title = f"{data_source_title} pivot low (lb {pivot_lookback})"
        # format data and store
        cut_source_values = data_source_values[:-pivot_lookback]
        data["v"]["data"]["low"] = {"title": pivot_low_title, "pivots": pivot_low_data,
                                    "pivots_val": cut_source_values, "values": data_source_values}
        if indicator.plot:
            if maker.ctx.exchange_manager.is_backtesting \
                    or (not maker.ctx.exchange_manager.is_backtesting and not maker.live_recording_mode):
                data_len = min([len(pivot_low_data), len(cut_source_values)])
                t = await get_candles_(maker, "time")
                t = t
                pivots_to_store = {"time": [], "lows": []}
                for index in range(1, data_len):
                    if pivot_low_data[-index]:
                        pivots_to_store["time"].append(t[-index])
                        pivots_to_store["lows"].append(cut_source_values[-index])
                await maker.ctx.set_cached_values(values=pivots_to_store["lows"],
                                                  value_key=indicator.config_path_short + "lows",
                                                  cache_keys=pivots_to_store["time"])
            else:
                if pivot_low_data[-1]:
                    await maker.ctx.set_cached_value(value=list(cut_source_values)[-1],
                                                     value_key=indicator.config_path_short + "lows")
            await plot(maker.ctx, data["v"]["title"], cache_value=indicator.config_path_short + "lows",
                       chart=chart_location, color="red", mode="markers")

    return await store_indicator_data(maker, indicator, data, force_plot_disable=True)
