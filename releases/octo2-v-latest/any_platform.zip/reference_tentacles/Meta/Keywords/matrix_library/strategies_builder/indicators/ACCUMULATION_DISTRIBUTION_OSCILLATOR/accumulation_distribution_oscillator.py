import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data \
    import get_candles_, user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_accumulation_distribution_oscillator(maker, indicator, evaluator):
    fast_length = await user_input2(maker, indicator, "accumulation distribution oscillator fast length", "int", 2, 0)
    slow_length = await user_input2(maker, indicator, "accumulation distribution oscillator slow length", "int", 5, 0)
    await allow_enable_plot(maker, indicator, "Plot accumulation distribution oscillator")
    data = tulipy.adosc(high=await get_candles_(maker, "high"), low=await get_candles_(maker, "low"),
                        close=await get_candles_(maker, "close"), volume=await get_candles_(maker, "volume"),
                        short_period=fast_length, long_period=slow_length)
    data_source = {"v": {"title": f"accumulation distribution oscillator ({fast_length}-{slow_length})",
                         "data": data, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data_source)
