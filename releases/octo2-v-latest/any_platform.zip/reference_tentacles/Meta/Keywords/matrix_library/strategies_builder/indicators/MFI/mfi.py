import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data import get_candles_
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2


async def get_MFI(maker, indicator, evaluator):
    length = await user_input2(maker, indicator, "MFI length", "int", 50, 0)
    await allow_enable_plot(maker, indicator, "Plot MFI")
    data = tulipy.mfi(await get_candles_(maker, "high"), await get_candles_(maker, "low"),
                      await get_candles_(maker, "close"), await get_candles_(maker, "volume"), length)
    data_sources = {"v": {"title": f"MFI {length}", "data": data, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data_sources)
