import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data \
    import get_candles_, user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot


async def get_Aroon(maker, indicator, evaluator):
    length = await user_input2(maker, indicator, "Aroon length", "int", 10)
    await allow_enable_plot(maker, indicator, "plot Aroon")
    aroon_down, aroon_up = tulipy.aroon(await get_candles_(maker, "low"), await get_candles_(maker, "high"), length)
    data = {"v": {"title": f"Aroon Down ({length})", "data": aroon_down, "chart_location": "sub-chart"},
            "u": {"title": f"Aroon UP ({length})", "data": aroon_up, "chart_location": "sub-chart"}}
    return await store_indicator_data(maker, indicator, data)
