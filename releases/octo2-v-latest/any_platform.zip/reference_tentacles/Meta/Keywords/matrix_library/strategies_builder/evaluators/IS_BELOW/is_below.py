from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_evaluator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.indicators.indicator_handling \
    import get_configurable_indicator, activate_configurable_indicator
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words. \
    indicators.above_below.is_above_below import is_below


async def get_is_below(maker, evaluator):
    below_values_title = await activate_configurable_indicator(maker, evaluator, data_source_name="data source below",
                                                               def_val="EMA")
    above_values_title = await activate_configurable_indicator(maker, evaluator, def_val="price data", indicator_id=2,
                                                               data_source_name="data source above")
    confirmation_time = await user_input2(maker, evaluator, "signal delay", "int", 0)
    below_percent = await user_input2(maker, evaluator, f"percent {below_values_title} needs to be "
                                                        f"below {above_values_title}", "int", 0)
    await allow_enable_plot(maker, evaluator, f"Plot when {below_values_title} is below {above_values_title}")
    data_below_values, evaluator.chart_location, above_values_detailed_title \
        = await get_configurable_indicator(maker, evaluator)
    evaluator.values, _, below_values_detailed_title = \
        await get_configurable_indicator(maker, evaluator, indicator_id=2)
    evaluator.signals = is_below(above_data=evaluator.values, below_data=data_below_values,
                                 confirmation_time=confirmation_time, below_percent=below_percent,
                                 max_history=not maker.live_recording_mode)
    evaluator.title = f"{above_values_detailed_title} is below {below_values_detailed_title}"
    return await store_evaluator_data(maker, evaluator)
