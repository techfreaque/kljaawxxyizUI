from octobot_trading.modes.script_keywords.basic_keywords import user_inputs
from tentacles.Meta.Keywords.scripting_library import orders as orders
from tentacles.Meta.Keywords.scripting_library.orders import order_types as order_types
from tentacles.Meta.Keywords.scripting_library.backtesting import backtesting_settings
from tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data import account_balance


async def init_skip_backtesting_runs(ctx):
    enable_skip_runs = await user_inputs.user_input(ctx, "enable skip backtesting runs", "boolean", False,
                                                    show_in_summary=False, show_in_optimizer=False)
    if enable_skip_runs:
        return await user_inputs.user_input(ctx, "skip backtesting runs if total balance falls below", "float", 5000, 0,
                                            show_in_summary=False, show_in_optimizer=False)
    else:
        return False


async def skip_backtesting_runs(ctx):
    skip_runs_balance = await init_skip_backtesting_runs(ctx)
    if skip_runs_balance:
        current_total_balance = float(await account_balance.total_account_balance(ctx))
        c_close = ctx.trigger_value[4]

        if current_total_balance * c_close < skip_runs_balance:
            if _open_orders := orders.get_open_orders(ctx):
                await orders.cancel_orders(ctx)
                await order_types.market(ctx, target_position=0, reduce_only=True)
            backtesting_settings.register_backtesting_timestamp_whitelist(ctx, [], append_to_whitelist=False)

