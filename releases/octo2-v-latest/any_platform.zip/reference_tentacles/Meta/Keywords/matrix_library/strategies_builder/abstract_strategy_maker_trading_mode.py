from abc import ABC

import octobot_trading.modes.scripted_trading_mode.abstract_scripted_trading_mode as abstract_scripted_trading_mode
import octobot_trading.exchange_channel as exchanges_channel
import octobot_trading.constants as trading_constants
import octobot_trading.enums as trading_enums
from tentacles.Meta.Keywords.scripting_library.data.reading.trading_settings \
    import set_initialized_evaluation, get_initialized_evaluation
from .strategy_making.strategy_building import StrategyMaking


class StrategyMaker(StrategyMaking, ABC):
    async def _pre_script_call(self, context):
        await self.make_strategy(context)

    async def make_strategy(self, ctx):
        # live trading
        if not ctx.exchange_manager.is_backtesting:
            await self.build_and_trade_strategies_live(ctx)
        # first back-testing candle
        elif not get_initialized_evaluation(ctx, ctx.tentacle):
            set_initialized_evaluation(ctx, ctx.tentacle)
            await self.build_strategies_backtesting_cache(ctx)
        # back-testing on all the other candles
        else:
            await self.trade_strategies_backtesting(ctx)


class AbstractStrategyMakerMode(abstract_scripted_trading_mode.AbstractScriptedTradingMode):
    async def create_producers(self) -> list:
        producers = await super().create_producers()
        mode_producer = StrategyMaker(
            exchanges_channel.get_chan(trading_constants.MODE_CHANNEL, self.exchange_manager.id),
            self.config, self, self.exchange_manager)
        await mode_producer.run()
        return producers + [mode_producer]

    @classmethod
    def get_supported_exchange_types(cls) -> list:
        """
        :return: The list of supported exchange types
        """
        return [
            trading_enums.ExchangeTypes.SPOT,
            trading_enums.ExchangeTypes.FUTURE
        ]
