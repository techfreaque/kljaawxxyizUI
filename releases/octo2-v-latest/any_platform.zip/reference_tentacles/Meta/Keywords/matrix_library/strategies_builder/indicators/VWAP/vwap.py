import tulipy
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.user_inputs2 import user_input2
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.data.exchange_public_data \
    import get_candles_, user_select_candle_source_name
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.plotting import \
    store_indicator_data, allow_enable_plot
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.indicators.vwap_lib.vwap_library import \
    calculate_historical_VWAP


async def get_VWAP(maker, indicator, evaluator):
    selected_vwap_timeframe = await user_input2(maker, indicator, "VWAP time Window", "options", "24h",
                                                options=["24h", "session", "week", "month"], )
    candle_source = await user_select_candle_source_name(maker, indicator, "Select VWAP Candle Source", "hlc3")
    await allow_enable_plot(maker, indicator, "Plot VWAP")
    vwap_data = calculate_historical_VWAP(await get_candles_(maker, candle_source), await get_candles_(maker, "volume"),
                                          time_data=await get_candles_(maker, "time"),
                                          window=selected_vwap_timeframe, time_frame=maker.ctx.time_frame)
    data_source = {"v": {"title": f"VWAP {selected_vwap_timeframe}", "data": vwap_data, "chart_location": "main-chart"}}
    return await store_indicator_data(maker, indicator, data_source)
