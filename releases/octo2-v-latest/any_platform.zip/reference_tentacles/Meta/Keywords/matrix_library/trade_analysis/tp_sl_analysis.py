import tentacles.Meta.Keywords.scripting_library.data.writing.plotting as plotting
import octobot_trading.modes.script_keywords.basic_keywords.user_inputs as user_inputs
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
try:
    import statistics as statistics
except ImportError:
    statistics = None
    # "package statistics not found"

async def stop_loss_analysis(ctx, final_long_whitelist, final_short_whitelist):
    if not statistics:
        return
    calc_req_stop_size = await user_inputs.user_input(ctx, "enable stop loss analysis", "boolean", False)

    if calc_req_stop_size:
        take_profit_in_p = await user_inputs.user_input(ctx, "take profit target in % (to calculate required SL %)",
                                                        "float", 2, 0)
        required_long_stops = []
        required_short_stops = []

        lows = None
        highs = None
        opens = None
        times = None
        data_len = None

        if final_long_whitelist:
            print()
            lows = await exchange_public_data.Low(ctx, max_history=True)
            highs = await exchange_public_data.High(ctx, max_history=True)
            opens = await exchange_public_data.Open(ctx, max_history=True)
            times = await exchange_public_data.Time(ctx, max_history=True)
            data_len = len(times)
            tmp_long_whitelist = final_long_whitelist
            tmp_long_whitelist.sort()
            for candle_id in range(1, data_len + 1):
                try:
                    candle_time = times[candle_id]
                    if candle_time == tmp_long_whitelist[0]:
                        tmp_long_whitelist = tmp_long_whitelist[1:]
                        entry_price = opens[candle_id]

                        take_profit_target = entry_price * (1 + (take_profit_in_p / 100))
                        for in_trade_candle_id in range(candle_id, data_len + 1):
                            try:
                                if highs[in_trade_candle_id] > take_profit_target:
                                    required_long_stops.append(
                                        ((min(lows[candle_id:in_trade_candle_id + 1]) / entry_price) - 1) * 100)
                                    break
                            except IndexError:
                                required_long_stops.append(((min(lows[candle_id:]) / entry_price) - 1) * 100)
                                break
                except IndexError:
                    break
            # try:
            await ctx.set_cached_values(required_long_stops, value_key="l-sl", cache_keys=final_long_whitelist)
            # except RuntimeError as e:  # todo
            #     print(f"set cache error. {e}")
            median_sl = [statistics.median(required_long_stops)] * data_len
            # try:
            await ctx.set_cached_values(median_sl, value_key="ml-sl", cache_keys=times)
            # except RuntimeError as e:  # todo
            #     print(f"set cache error. {e}")
        if final_short_whitelist:
            lows = lows or await exchange_public_data.Low(ctx, max_history=True)
            highs = highs or await exchange_public_data.High(ctx, max_history=True)
            opens = opens or await exchange_public_data.Open(ctx, max_history=True)
            times = times or await exchange_public_data.Time(ctx, max_history=True)
            data_len = data_len or len(times)

            tmp_short_whitelist = final_short_whitelist
            tmp_short_whitelist.sort()

            for candle_id in range(1, data_len + 1):
                try:
                    candle_time = times[candle_id]
                    if candle_time == tmp_short_whitelist[0]:
                        tmp_short_whitelist = tmp_short_whitelist[1:]
                        entry_price = opens[candle_id]
                        take_profit_target = entry_price * (1 - (take_profit_in_p / 100))

                        for in_trade_candle_id in range(candle_id, data_len + 1):
                            try:
                                if lows[in_trade_candle_id] < take_profit_target:
                                    required_short_stops.append(
                                        ((max(highs[candle_id:in_trade_candle_id + 1]) / entry_price) + 1) * 100)
                                    break
                            except IndexError:
                                required_short_stops.append(((max(highs[candle_id:]) / entry_price) + 1) * 100)
                                break
                except IndexError:
                    break

            await ctx.set_cached_values(required_short_stops, value_key="s-sl", cache_keys=final_short_whitelist)
            median_sl = [statistics.median(required_short_stops)] * data_len
            await ctx.set_cached_values(median_sl, value_key="ms-sl", cache_keys=times)
        try:
            await plotting.plot(ctx, "required short SL in percent", cache_value="s-sl", chart="sub-chart",
                                mode="markers")
            await plotting.plot(ctx, "required long SL in percent", cache_value="l-sl", chart="sub-chart",
                                mode="markers")
            await plotting.plot(ctx, "median long SL in percent", cache_value="ml-sl", chart="sub-chart")
            await plotting.plot(ctx, "median short SL in percent", cache_value="ms-sl", chart="sub-chart")
        except RuntimeError:
            pass  # no cache available


async def take_profit_analysis(ctx, final_long_whitelist, final_short_whitelist):
    if not statistics:
        return
    calc_req_stop_size = await user_inputs.user_input(ctx, "enable take profit analysis", "boolean", False)

    if calc_req_stop_size:
        stop_loss_in_p = await user_inputs.user_input(ctx, "stop loss target in % (to calculate required TP %)",
                                                      "float", 1, 0)
        required_long_tps = []
        required_short_tps = []

        lows = None
        highs = None
        opens = None
        times = None
        data_len = None

        if final_short_whitelist:
            lows = await exchange_public_data.Low(ctx, max_history=True)
            highs = await exchange_public_data.High(ctx, max_history=True)
            opens = await exchange_public_data.Open(ctx, max_history=True)
            times = await exchange_public_data.Time(ctx, max_history=True)
            data_len = len(times)
            tmp_short_whitelist = final_short_whitelist
            tmp_short_whitelist.sort()
            for candle_id in range(1, data_len + 1):
                try:
                    candle_time = times[candle_id]
                    if candle_time == tmp_short_whitelist[0]:
                        tmp_short_whitelist = tmp_short_whitelist[1:]
                        entry_price = opens[candle_id]

                        stop_loss_target = entry_price * (1 + (stop_loss_in_p / 100))
                        for in_trade_candle_id in range(candle_id, data_len + 1):
                            try:
                                if highs[in_trade_candle_id] > stop_loss_target:
                                    required_short_tps.append(
                                        ((min(lows[candle_id:in_trade_candle_id + 1]) / entry_price) + 1) * 100)
                                    break
                            except IndexError:
                                required_short_tps.append(((min(lows[candle_id:]) / entry_price) + 1) * 100)
                                break
                except IndexError:
                    break
            # try:
            await ctx.set_cached_values(required_short_tps, value_key="s-tp", cache_keys=final_short_whitelist)
            # except RuntimeError as e:  # todo
            #     print(f"set cache error. {e}")
            median_tp = [statistics.median(required_short_tps)] * data_len
            # try:
            await ctx.set_cached_values(median_tp, value_key="ms-tp", cache_keys=times)
            # except RuntimeError as e:  # todo
            #     print(f"set cache error. {e}")
        if final_long_whitelist:
            lows = lows or await exchange_public_data.Low(ctx, max_history=True)
            highs = highs or await exchange_public_data.High(ctx, max_history=True)
            opens = opens or await exchange_public_data.Open(ctx, max_history=True)
            times = times or await exchange_public_data.Time(ctx, max_history=True)
            data_len = data_len or len(times)

            tmp_long_whitelist = final_long_whitelist
            tmp_long_whitelist.sort()

            for candle_id in range(1, data_len + 1):
                try:
                    candle_time = times[candle_id]
                    if candle_time == tmp_long_whitelist[0]:
                        tmp_long_whitelist = tmp_long_whitelist[1:]
                        entry_price = opens[candle_id]
                        stop_loss_target = entry_price * (1 - (stop_loss_in_p / 100))

                        for in_trade_candle_id in range(candle_id, data_len + 1):
                            try:
                                if lows[in_trade_candle_id] <= stop_loss_target:
                                    required_long_tps.append(
                                        ((max(highs[candle_id:in_trade_candle_id + 1]) / entry_price) - 1) * 100)
                                    break
                            except IndexError:
                                required_long_tps.append(((max(highs[candle_id:]) / entry_price) - 1) * 100)
                                break
                except IndexError:
                    break

            await ctx.set_cached_values(required_long_tps, value_key="l-tp", cache_keys=final_long_whitelist)
            median_tp = [statistics.median(required_long_tps)] * data_len
            await ctx.set_cached_values(median_tp, value_key="ml-tp", cache_keys=times)
        try:
            await plotting.plot(ctx, "required short TP in percent", cache_value="s-tp", chart="sub-chart",
                                mode="markers")
            await plotting.plot(ctx, "required long TP in percent", cache_value="l-tp", chart="sub-chart",
                                mode="markers")
            await plotting.plot(ctx, "median long TP in percent", cache_value="ml-tp", chart="sub-chart")
            await plotting.plot(ctx, "median short TP in percent", cache_value="ms-tp", chart="sub-chart")
        except RuntimeError:
            pass  # no cache available
