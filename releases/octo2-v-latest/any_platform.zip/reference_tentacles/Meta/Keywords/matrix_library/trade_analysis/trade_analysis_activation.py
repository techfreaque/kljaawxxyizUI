from octobot_trading.modes.script_keywords.basic_keywords import user_inputs
from tentacles.Meta.Keywords.scripting_library.TA.trigger.eval_triggered import evaluator_get_result
from tentacles.Meta.Keywords.matrix_library import trade_analysis


async def activate_trade_analysis(ctx):
    return await user_inputs.user_input(ctx, "activate trade analysis (slows down backtests)",
                                        "boolean", False, show_in_summary=False)


async def handle_trade_analysis_for_current_candle(ctx):
    activated_trade_analysis = await activate_trade_analysis(ctx)
    if activated_trade_analysis:
        await evaluator_get_result(ctx, "trade_analysis", trigger=True, config_name="trade analysis")


async def handle_trade_analysis_for_backtesting_first_candle(ctx, strategy_maker_data):
    activated_trade_analysis = await activate_trade_analysis(ctx)
    if activated_trade_analysis:
        await trade_analysis.stop_loss_analysis(ctx, strategy_maker_data.final_long_whitelist,
                                                strategy_maker_data.final_short_whitelist)
        await trade_analysis.take_profit_analysis(ctx, strategy_maker_data.final_long_whitelist,
                                                  strategy_maker_data.final_short_whitelist)

