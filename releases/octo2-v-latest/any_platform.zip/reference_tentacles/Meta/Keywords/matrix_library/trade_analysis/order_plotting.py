import tentacles.Meta.Keywords.scripting_library.data.writing.plotting as plotting
import octobot_trading.modes.script_keywords.basic_keywords.user_inputs as user_inputs
import tentacles.Meta.Keywords.scripting_library.orders.open_orders as open_orders
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data.open_positions as open_positions
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data.account_balance as account_balance


async def plot_orders(ctx):
    # plot orders
    activate_plot_orders = await user_inputs.user_input(ctx, "plot orders", "boolean", True,
                                                        show_in_summary=False, show_in_optimizer=False)
    if activate_plot_orders:
        _open_orders = open_orders.get_open_orders(ctx)
        tp_list = []
        sl_list = []
        entry_list = []
        for order in _open_orders:
            if order.exchange_order_type.name == "STOP_LOSS":
                sl_list.append(float(order.origin_price))
                entry_list.append(float(order.created_last_price))
            elif order.reduce_only is True:
                tp_list.append(float(order.origin_price))
            else:
                entry_list.append(float(order.origin_price))
        if ctx.exchange_manager.is_backtesting:
            if tp_list:
                await ctx.set_cached_value(value=tp_list, value_key="tp")
            if sl_list:
                await ctx.set_cached_value(value=sl_list, value_key="sl")
            if entry_list:
                await ctx.set_cached_value(value=entry_list, value_key="entry")
            try:
                await plotting.plot(ctx, "stop losses", cache_value="sl", mode="markers", chart="main-chart",
                                    color="yellow", shift_to_open_candle_time=False)
                await plotting.plot(ctx, "take profits", cache_value="tp", mode="markers", chart="main-chart",
                                    color="magenta", shift_to_open_candle_time=False)
                await plotting.plot(ctx, "entries", cache_value="entry", mode="markers", chart="main-chart",
                                    color="blue", shift_to_open_candle_time=False)
            except RuntimeError:
                pass  # no cache
        else:
            if tp_list:
                await ctx.set_cached_value(value=tp_list, value_key="l-tp")
            if sl_list:
                await ctx.set_cached_value(value=sl_list, value_key="l-sl")
            if entry_list:
                await ctx.set_cached_value(value=entry_list, value_key="l-entry")
            try:
                await plotting.plot(ctx, "stop losses", cache_value="l-sl", mode="markers", chart="main-chart",
                                    color="yellow", shift_to_open_candle_time=False)
                await plotting.plot(ctx, "take profits", cache_value="l-tp", mode="markers", chart="main-chart",
                                    color="magenta", shift_to_open_candle_time=False)
                await plotting.plot(ctx, "entries", cache_value="l-entry", mode="markers", chart="main-chart",
                                    color="blue", shift_to_open_candle_time=False)
            except RuntimeError:
                pass  # no cache


async def plot_current_position(ctx):
    enable_plot_position = await user_inputs.user_input(ctx, "plot open position", "boolean", True,
                                                        show_in_summary=False, show_in_optimizer=False)
    if enable_plot_position:
        try:
            current_pos = open_positions.open_position_size(ctx)
        except AttributeError:
            print("plot position error")
            current_pos = 0
        if ctx.exchange_manager.is_backtesting:
            try:
                await ctx.set_cached_value(value=float(current_pos), value_key="op")
            except:
                pass
            await plotting.plot(ctx, "current position", cache_value="op", chart="sub-chart",
                                color="blue", shift_to_open_candle_time=False, mode="markers", own_yaxis=True)
        else:
            try:
                await ctx.set_cached_value(value=float(current_pos), value_key="l-op")
            except:
                pass

            await plotting.plot(ctx, "current position", cache_value="l-op", chart="sub-chart",
                                color="blue", shift_to_open_candle_time=False, mode="markers", own_yaxis=True)


async def plot_average_entry(ctx):
    enable_plot_entry = await user_inputs.user_input(ctx, "plot average entry", "boolean", True,
                                                     show_in_summary=False, show_in_optimizer=False)
    if enable_plot_entry:
        try:
            current_entry = await open_positions.average_open_pos_entry(ctx, side="long") \
                            or await open_positions.average_open_pos_entry(ctx, side="short")
        except AttributeError:
            print("plot average entry error")
            return
        key = "b-" if ctx.exchange_manager.is_backtesting else "l-"
        if current_entry:
            await ctx.set_cached_value(value=float(current_entry), value_key=key+"ae")
        await plotting.plot(ctx, "current average entry", cache_value=key+"ae", chart="main-chart",
                            color="blue", shift_to_open_candle_time=False, mode="markers")


async def plot_balances(ctx):
    enable_plot_balances = await user_inputs.user_input(ctx, "plot balances", "boolean", True,
                                                        show_in_summary=False, show_in_optimizer=False)
    if enable_plot_balances:
        current_available_balance = await account_balance.available_account_balance(ctx)
        current_total_balance = await account_balance.total_account_balance(ctx)

        key = "b-" if ctx.exchange_manager.is_backtesting else "l-"
        await ctx.set_cached_value(value=float(current_available_balance), value_key=key + "cab")
        await ctx.set_cached_value(value=float(current_total_balance), value_key=key + "cb")
        await plotting.plot(ctx, "current available balance", cache_value=key + "cab", chart="sub-chart",
                            color="blue", shift_to_open_candle_time=False, mode="markers")
        await plotting.plot(ctx, "current balance", cache_value=key + "cb", chart="sub-chart",
                            color="blue", shift_to_open_candle_time=False, mode="markers")
