from tentacles.Meta.Keywords.scripting_library.backtesting.backtesting_data_selector \
    import backtesting_first_full_candle_time, backtesting_last_full_candle_time


async def simulate_hedge_fund_gains(ctx):
    pass


async def get_simulated_hedge_fund_gain_timestamps(ctx):
    pass
    # start_time = backtesting_first_full_candle_time(ctx)
    # end_time = backtesting_last_full_candle_time(ctx)

