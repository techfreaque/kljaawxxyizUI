import subprocess
import sys

try:
    import pandas as pd
except (ImportError, ModuleNotFoundError):
    subprocess.check_call([sys.executable, "-m", "pip", "install", "pandas"])
    import pandas as pd
from .trade_analysis import *
from .strategies_builder import *
