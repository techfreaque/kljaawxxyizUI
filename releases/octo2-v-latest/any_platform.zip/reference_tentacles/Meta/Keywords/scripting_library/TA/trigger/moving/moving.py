#  Drakkar-Software OctoBot-Trading
#  Copyright (c) Drakkar-Software, All rights reserved.
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 3.0 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library.


def moving_up(indicator_data, consecutive_rising_bars, sideways_is_rising=True,
              calculate_full_history=False, only_first_signal=False):
    if not calculate_full_history:
        is_rising = False
        if sideways_is_rising is False:
            if only_first_signal:
                for i in range(0, consecutive_rising_bars):
                    is_rising = indicator_data[-i-1] > indicator_data[-i-2] \
                                and not indicator_data[-i-2] > indicator_data[-i-3]
                    if is_rising:
                        is_rising = True
                    else:
                        is_rising = False
                        break
                return is_rising
            else:
                for i in range(0, consecutive_rising_bars):
                    is_rising = indicator_data[-i-1] > indicator_data[-i-2]
                    if is_rising:
                        is_rising = True
                    else:
                        is_rising = False
                        break
                return is_rising

        else:  # sideways counts as rising
            if only_first_signal:
                was_rising = None
                for i in range(0, consecutive_rising_bars):
                    was_rising = indicator_data[-i-2] >= indicator_data[-i-3]
                    if was_rising:
                        was_rising = True
                    else:
                        was_rising = False
                        break
                if not was_rising:
                    for i in range(0, consecutive_rising_bars):
                        is_rising = indicator_data[-i-1] >= indicator_data[-i-2]
                        if is_rising:
                            is_rising = True
                        else:
                            is_rising = False
                            break
                    return is_rising
            else:
                for i in range(0, consecutive_rising_bars):
                    is_rising = indicator_data[-i-1] >= indicator_data[-i-2]
                    if is_rising:
                        is_rising = True
                    else:
                        is_rising = False
                        break
                return is_rising

    else:  # calculate full history
        rising_data = []
        if sideways_is_rising is False:
            if only_first_signal:
                for j in range(consecutive_rising_bars+1, len(indicator_data)):
                    is_rising = False
                    for i in range(0, consecutive_rising_bars):
                        is_rising = indicator_data[j - i] > indicator_data[j - i - 1] \
                                    and not indicator_data[j - i-1] > indicator_data[j - i - 2]
                        if is_rising:
                            is_rising = True
                        else:
                            is_rising = False
                            break
                    rising_data.append(is_rising)
            else:
                for j in range(consecutive_rising_bars, len(indicator_data)):
                    is_rising = False
                    for i in range(0, consecutive_rising_bars):
                        is_rising = indicator_data[j - i] > indicator_data[j - i - 1]
                        if is_rising:
                            is_rising = True
                        else:
                            is_rising = False
                            break
                    rising_data.append(is_rising)

        else:  # sideways counts as rising
            if only_first_signal:
                for j in range(consecutive_rising_bars, len(indicator_data)):
                    is_rising = False
                    was_rising = None
                    for i in range(0, consecutive_rising_bars):
                        was_rising = indicator_data[j - i - 1] >= indicator_data[j - i - 2]
                        if was_rising:
                            was_rising = True
                        else:
                            was_rising = False
                            break

                    if not was_rising:
                        for i in range(0, consecutive_rising_bars):
                            is_rising = indicator_data[j - i] >= indicator_data[j - i - 1]
                            if is_rising:
                                is_rising = True
                            else:
                                is_rising = False
                                break
                    rising_data.append(is_rising)
            else:
                for j in range(consecutive_rising_bars, len(indicator_data)):
                    is_rising = False
                    for i in range(0, consecutive_rising_bars):
                        is_rising = indicator_data[j - i] >= indicator_data[j - i - 1]
                        if is_rising:
                            is_rising = True
                        else:
                            is_rising = False
                            break
                    rising_data.append(is_rising)
        return rising_data


def moving_down(indicator_data, consecutive_falling_bars, sideways_is_falling=True,
                calculate_full_history=False, only_first_signal=False):
    if not calculate_full_history:
        is_falling = False
        if sideways_is_falling is False:
            if only_first_signal:
                for i in range(0, consecutive_falling_bars):
                    is_falling = indicator_data[-i-1] < indicator_data[-i-2] \
                                and not indicator_data[-i-2] < indicator_data[-i-3]
                    if is_falling:
                        is_falling = True
                    else:
                        is_falling = False
                        break
                return is_falling
            else:
                for i in range(0, consecutive_falling_bars):
                    is_falling = indicator_data[-i-1] < indicator_data[-i-2]
                    if is_falling:
                        is_falling = True
                    else:
                        is_falling = False
                        break
                return is_falling

        else:  # sideways counts as falling
            if only_first_signal:
                was_falling = None
                for i in range(0, consecutive_falling_bars):
                    was_falling = indicator_data[-i - 2] <= indicator_data[-i - 3]
                    if was_falling:
                        was_falling = True
                    else:
                        was_falling = False
                        break
                if not was_falling:
                    for i in range(0, consecutive_falling_bars):
                        is_falling = indicator_data[-i - 1] <= indicator_data[-i - 2]
                        if is_falling:
                            is_falling = True
                        else:
                            is_falling = False
                            break
                    return is_falling
            else:
                for i in range(0, consecutive_falling_bars):
                    is_falling = indicator_data[-i-1] <= indicator_data[-i-2]
                    if is_falling:
                        is_falling = True
                    else:
                        is_falling = False
                        break
                return is_falling

    else:  # calculate full history
        falling_data = []
        if sideways_is_falling is False:
            if only_first_signal:
                for j in range(consecutive_falling_bars+1, len(indicator_data)):
                    is_falling = False
                    for i in range(0, consecutive_falling_bars):
                        is_falling = indicator_data[j - i] < indicator_data[j - i - 1] \
                                    and not indicator_data[j - i-1] < indicator_data[j - i - 2]
                        if is_falling:
                            is_falling = True
                        else:
                            is_falling = False
                            break
                    falling_data.append(is_falling)
            else:
                for j in range(consecutive_falling_bars, len(indicator_data)):
                    is_falling = False
                    for i in range(0, consecutive_falling_bars):
                        is_falling = indicator_data[j - i] < indicator_data[j - i - 1]
                        if is_falling:
                            is_falling = True
                        else:
                            is_falling = False
                            break
                    falling_data.append(is_falling)

        else:  # sideways counts as falling
            if only_first_signal:
                for j in range(consecutive_falling_bars, len(indicator_data)):
                    is_falling = False
                    was_falling = None
                    for i in range(0, consecutive_falling_bars):
                        was_falling = indicator_data[j - i - 1] <= indicator_data[j - i - 2]
                        if was_falling:
                            was_falling = True
                        else:
                            was_falling = False
                            break

                    if not was_falling:
                        for i in range(0, consecutive_falling_bars):
                            is_falling = indicator_data[j - i] <= indicator_data[j - i - 1]
                            if is_falling:
                                is_falling = True
                            else:
                                is_falling = False
                                break
                    falling_data.append(is_falling)
            else:
                for j in range(consecutive_falling_bars, len(indicator_data)):
                    is_falling = False
                    for i in range(0, consecutive_falling_bars):
                        is_falling = indicator_data[j - i] <= indicator_data[j - i - 1]
                        if is_falling:
                            is_falling = True
                        else:
                            is_falling = False
                            break
                    falling_data.append(is_falling)
        return falling_data
