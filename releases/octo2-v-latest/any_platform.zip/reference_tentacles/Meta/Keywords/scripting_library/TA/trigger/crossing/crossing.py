#  Drakkar-Software OctoBot-Trading
#  Copyright (c) Drakkar-Software, All rights reserved.
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 3.0 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library.
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
import tentacles.Meta.Keywords.scripting_library.orders.offsets.offset as offset


async def crossing_up(context=None, values_to_cross=None, crossing_values=None, delay=0, max_cross_down=None,
                      max_cross_down_lookback=5, max_history=False):
    # true if price just risen over value and stayed there for delay time
    min_candles = max_cross_down_lookback + delay + 1
    crossing_data = []

    if values_to_cross is None:
        raise RuntimeError("crossing_up: you need to provide values_to_cross")
    else:
        if crossing_values is not None:
            length = min([len(values_to_cross), len(crossing_values)])
            values_to_cross = values_to_cross[-length:]
            crossing_values = crossing_values[-length:]
            for candle_id in range(min_candles, length):
                if not max_history:
                    candle_id = length - 1
                condition = False
                was_below = None
                try:
                    was_below = crossing_values[candle_id - delay - 1] < values_to_cross[candle_id - delay - 1]
                except IndexError:
                    raise RuntimeError("crossing_up: not enough values_to_cross, length needs to be same as delay")

                didnt_cross_to_much = True
                if max_cross_down:
                    try:
                        didnt_cross_to_much = min(
                            values_to_cross[candle_id - max_cross_down_lookback:candle_id - delay]) \
                                              - float(await offset.get_offset(context, "-" + max_cross_down)) \
                                              < min(
                            crossing_values[candle_id - max_cross_down_lookback:candle_id - delay])
                    except ValueError:
                        raise RuntimeError("crossing_up: not enough values_to_cross, length needs to be same "
                                           "as max_cross_down_lookback")

                if was_below and didnt_cross_to_much:
                    for i in range(0, delay + 1):
                        condition = crossing_values[candle_id - i] > values_to_cross[candle_id - i]
                        if not condition:
                            crossing_data.append(False)
                            break
                    if condition:
                        crossing_data.append(True)
                else:
                    crossing_data.append(False)
                if not max_history:
                    break
            return crossing_data
        else:
            length = len(values_to_cross)
            closes = await exchange_public_data.Close(context, max_history=True)
            closes = closes[-length:]
            # highs = exchange_public_data.High(context, limit=data_limit)
            lows = await exchange_public_data.Low(context, max_history=True)
            lows = lows[-length:]

            for candle_id in range(min_candles, length):
                if not max_history:
                    candle_id = length - 1
                condition = False
                was_below = None
                is_currently_above = None
                try:
                    was_below = lows[candle_id - delay - 1] < values_to_cross[candle_id - delay - 1]
                    is_currently_above = closes[candle_id - 1] > values_to_cross[candle_id - 1]
                except IndexError:
                    raise RuntimeError("crossing_up: not enough values_to_cross, length needs to be same as delay")

                didnt_cross_to_much = True
                if max_cross_down is not None:
                    try:
                        didnt_cross_to_much = min(values_to_cross[candle_id - max_cross_down_lookback:candle_id]) \
                                              - float(await offset.get_offset(context, "-" + max_cross_down)) \
                                              < min(lows[candle_id - max_cross_down_lookback:candle_id])
                    except ValueError:
                        raise RuntimeError("crossing_up: not enough values_to_cross, length needs to be same "
                                           "as max_cross_down_lookback")

                if was_below and is_currently_above and didnt_cross_to_much:
                    # check if closed above within delay time
                    for i in range(1, delay + 2):
                        condition = closes[candle_id - i] > values_to_cross[candle_id - i]
                        if not condition:
                            crossing_data.append(False)
                            break
                    if condition:
                        crossing_data.append(True)
                else:
                    crossing_data.append(False)
                if not max_history:
                    break
            return crossing_data


async def crossing_down(context=None, values_to_cross=None, crossing_values=None, delay=0, max_cross_up=None,
                        max_cross_up_lookback=5, max_history=False):
    # true if price just fell under value and stayed there for delay time
    min_candles = max_cross_up_lookback + delay + 1
    crossing_data = []

    if values_to_cross is None:
        raise RuntimeError("crossing_up: you need to provide values_to_cross")
    else:
        if crossing_values is not None:
            length = min([len(values_to_cross), len(crossing_values)])
            values_to_cross = values_to_cross[-length:]
            crossing_values = crossing_values[-length:]
            for candle_id in range(min_candles, length):
                if not max_history:
                    candle_id = length - 1
                condition = False
                was_above = None
                try:
                    was_above = crossing_values[candle_id - delay - 1] > values_to_cross[candle_id - delay - 1]
                except IndexError:
                    raise RuntimeError("crossing_up: not enough values_to_cross, length needs to be same as delay")

                didnt_cross_to_much = True
                if max_cross_up:
                    try:
                        didnt_cross_to_much = max(values_to_cross[candle_id - max_cross_up_lookback:candle_id - delay]) \
                                              + float(await offset.get_offset(context, "-" + max_cross_up)) \
                                              > max(
                            crossing_values[candle_id - max_cross_up_lookback:candle_id - delay])
                    except ValueError:
                        raise RuntimeError("crossing_up: not enough values_to_cross, length needs to be same "
                                           "as max_cross_down_lookback")

                if was_above and didnt_cross_to_much:
                    for i in range(0, delay + 1):
                        condition = crossing_values[candle_id - i] < values_to_cross[candle_id - i]
                        if not condition:
                            crossing_data.append(False)
                            break
                    if condition:
                        crossing_data.append(True)
                else:
                    crossing_data.append(False)
                if not max_history:
                    break
            return crossing_data
        else:
            length = len(values_to_cross)
            closes = await exchange_public_data.Close(context, max_history=True)
            closes = closes[-length:]
            # highs = exchange_public_data.High(context, limit=data_limit)
            highs = await exchange_public_data.High(context, max_history=True)
            highs = highs[-length:]
            for candle_id in range(min_candles, length):
                if not max_history:
                    candle_id = length - 1
                condition = False
                was_above = None
                is_currently_below = None
                try:
                    was_above = highs[candle_id - delay - 1] > values_to_cross[candle_id - delay - 1]
                    is_currently_below = closes[candle_id - 1] < values_to_cross[candle_id - 1]
                except IndexError:
                    raise RuntimeError("crossing_up: not enough values_to_cross, length needs to be same as delay")

                didnt_cross_to_much = True
                if max_cross_up is not None:
                    try:
                        didnt_cross_to_much = max(values_to_cross[candle_id - max_cross_up_lookback:candle_id]) \
                                              + float(await offset.get_offset(context, "-" + max_cross_up)) \
                                              > max(highs[candle_id - max_cross_up_lookback:candle_id])
                    except ValueError:
                        raise RuntimeError("crossing_up: not enough values_to_cross, length needs to be same "
                                           "as max_cross_down_lookback")

                if was_above and is_currently_below and didnt_cross_to_much:
                    # check if closed above within delay time
                    for i in range(1, delay + 2):
                        condition = closes[candle_id - i] < values_to_cross[candle_id - i]
                        if not condition:
                            crossing_data.append(False)
                            break
                    if condition:
                        crossing_data.append(True)
                else:
                    crossing_data.append(False)
                if not max_history:
                    break
            return crossing_data


async def crossing(context=None, values_to_cross=None, crossing_values=None, delay=0, max_cross=None,
                   max_cross_lookback=5, max_history=False):
    # true if price just went below or over value and stayed there for delay time and didnt cross to much
    c_up = await crossing_up(context=context, values_to_cross=values_to_cross, crossing_values=crossing_values,
                             delay=delay, max_cross_down=max_cross, max_cross_down_lookback=max_cross_lookback,
                             max_history=max_history)

    c_down = await crossing_down(context=context, values_to_cross=values_to_cross, crossing_values=crossing_values,
                                 delay=delay, max_cross_up=max_cross,
                                 max_cross_up_lookback=max_cross_lookback, max_history=max_history)
    return c_up, c_down
