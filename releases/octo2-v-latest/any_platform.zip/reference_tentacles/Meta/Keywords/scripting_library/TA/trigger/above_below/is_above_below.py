def is_above_currently(below_data, above_data, confirmation_time=1):
    confirmation_time = confirmation_time + 1
    is_above = False
    for i in range(0, confirmation_time):
        is_above = below_data[-i-1] < above_data[-i-1]
        if not is_above:
            break
    return is_above


def is_below_currently(below_data, above_data, confirmation_time=1):
    confirmation_time = confirmation_time + 1
    is_below = False
    for i in range(0, confirmation_time):
        is_below = below_data[-i-1] < above_data[-i-1]
        if not is_below:
            break
    return is_below


def is_above_history(below_data, above_data, confirmation_time=1):
    data_length = min([len(below_data), len(above_data)])

    below_data = below_data[-data_length:]
    above_data = above_data[-data_length:]

    above_history = []

    for j in range(confirmation_time, data_length):
        is_above = False
        for i in range(0, confirmation_time+1):
            is_above = below_data[j-i] < above_data[j-i]
            if not is_above:
                break
        above_history.append(is_above)
    return above_history


def is_below_history(below_data, above_data, confirmation_time=1):
    confirmation_time = confirmation_time + 1
    is_below = False
    for i in range(0, confirmation_time):
        is_below = below_data[-i-1] < above_data[-i-1]
        if not is_below:
            break
    return is_below
