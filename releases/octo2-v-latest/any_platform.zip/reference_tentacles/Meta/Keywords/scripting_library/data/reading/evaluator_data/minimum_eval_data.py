from tentacles.Meta.Keywords.scripting_library.TA.trigger.eval_triggered import evaluator_get_results
import octobot_commons.enums as commons_enums
import octobot_commons.constants as commons_constants


async def evaluator_has_minimum_results(ctx, minimum_length, tentacle_class,
                                        time_frame=None,
                                        symbol=None,
                                        trigger=False,
                                        value_key=commons_enums.CacheDatabaseColumns.VALUE.value,
                                        config_name=None,
                                        config: dict = None
                                        ):
    evaluator_results = await evaluator_get_results(ctx, tentacle_class=tentacle_class, time_frame=time_frame,
                                                    symbol=symbol, trigger=trigger, value_key=value_key,
                                                    limit=minimum_length, config_name=config_name,
                                                    config=config)
    if minimum_length == 1:
        return evaluator_results != commons_constants.DO_NOT_CACHE
    if isinstance(evaluator_results, list):
        return len(evaluator_results) == minimum_length
    return False


async def evaluator_get_minimum_results(ctx, minimum_length, tentacle_class,
                                        time_frame=None,
                                        symbol=None,
                                        limit=None,
                                        max_history=False,
                                        trigger=False,
                                        value_key=commons_enums.CacheDatabaseColumns.VALUE.value,
                                        config_name=None,
                                        config: dict = None
                                        ):
    limit = limit or minimum_length
    evaluator_results = await evaluator_get_results(ctx, tentacle_class=tentacle_class, time_frame=time_frame,
                                                    symbol=symbol, trigger=trigger, value_key=value_key,
                                                    limit=limit, max_history=max_history, config_name=config_name,
                                                    config=config)
    if minimum_length == 1:
        if evaluator_results != commons_constants.DO_NOT_CACHE:
            return [evaluator_results]
        return None
    if isinstance(evaluator_results, list):
        if len(evaluator_results) >= minimum_length:
            return evaluator_results
    return None
