import tentacles.Meta.Keywords.scripting_library.backtesting.backtesting_data_selector as backtesting_data_selector
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data


async def evaluator_cache_missing(ctx, current_time=None):
    # uncomment to debug cache writing timing issues
    # check out the caching files to see the difference between cached values and timing
    # await ctx.set_cached_value(value="this is the init candle", value_key="init#t",
    #                            cache_key=await exchange_public_data.current_candle_time(ctx))

    _, missing_end_value = await ctx.get_cached_value(value_key="v", cache_key=backtesting_data_selector.
                                                      backtesting_last_full_candle_time(ctx))
    if not missing_end_value:
        current_time = current_time or await exchange_public_data.current_candle_time(ctx)
        _, missing_start_value = await ctx.get_cached_value(value_key="v", cache_key=current_time)
        if missing_start_value:
            _, missing_start_value = await ctx.get_cached_value(cache_key=current_time,
                                                                value_key="csh")
        return missing_start_value
    return True
