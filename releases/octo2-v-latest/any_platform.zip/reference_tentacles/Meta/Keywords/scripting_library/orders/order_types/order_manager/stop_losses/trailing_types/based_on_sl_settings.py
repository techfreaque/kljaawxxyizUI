import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.stop_losses.\
    stop_loss_handling as stop_loss_handling
import octobot_trading.enums as trading_enums
import decimal as decimal


async def trail_to_stop_loss_settings(ctx, managed_orders_settings):
    sl_price, sl_in_p, current_price_val \
        = await stop_loss_handling.get_manged_order_stop_loss(ctx, managed_orders_settings,
                                                              managed_orders_settings.trading_side)
    if managed_orders_settings.trading_side == trading_enums.PositionSide.LONG.value:
        return decimal.Decimal(sl_price)
    else:
        return decimal.Decimal(sl_price)
