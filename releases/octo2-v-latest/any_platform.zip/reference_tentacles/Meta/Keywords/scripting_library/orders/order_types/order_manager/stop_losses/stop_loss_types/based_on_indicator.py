import octobot_trading.enums as trading_enums
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.\
        stop_losses.stop_loss_handling as stop_loss_handling
# try:
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.orders import sl_sources as sl_sources
# except ImportError:
#     sl_sources = []


def get_stop_loss_based_on_indicator(ctx, managed_orders_settings, trading_side, current_price_val):
    sl_price = sl_sources.get_sl_indicator(ctx, managed_orders_settings)

    if trading_side == trading_enums.PositionSide.LONG.value:
        sl_in_p, sl_price = stop_loss_handling.trim_sl_long_price(sl_price, current_price_val,
                                                                  managed_orders_settings.sl_max_p,
                                                                  managed_orders_settings.sl_min_p)

    elif trading_side == trading_enums.PositionSide.SHORT.value:
        sl_in_p, sl_price = stop_loss_handling.trim_sl_short_price(sl_price, current_price_val,
                                                                   managed_orders_settings.sl_max_p,
                                                                   managed_orders_settings.sl_min_p)
    else:
        raise RuntimeError('Side needs to be "long" or "short" for your managed order')
    return sl_in_p, sl_price
