import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import tentacles.Meta.Keywords.scripting_library.TA.trigger.eval_triggered as eval_triggered

# try:
from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.orders import sl_sources as sl_sources


# except ImportError:
#     sl_sources = []


class ManagedOrdersSettings:
    def __init__(self, context, input_root_path):
        self.sl_trail_start_only_in_profit = None
        self.input_root_path = input_root_path
        self.context = context
        self.entry_types = None
        self.entry_type = None
        self.entry_scaled_min = None
        self.entry_scaled_max = None
        self.entry_scaled_order_count = None
        self.limit_offset = None
        self.sl_types = None
        self.position_size_types = None
        self.managed_order_active = None
        self.sl_type = None
        self.sl_low_high_lookback = None
        self.sl_low_high_buffer = None
        self.sl_min_p = None
        self.sl_max_p = None
        self.sl_in_p_value = None
        self.sl_datasource = None
        self.sl_selected_indicator = None
        self.sl_trigger_evaluator = None
        self.sl_indicator_config_name = None
        self.sl_key_values = None
        self.sl_indicator_init_value = None
        self.sl_trail_types = None
        self.sl_trail_type = None
        self.sl_trail_start = None
        self.sl_trail_start_only_if_above_entry = None
        self.sl_trailing_datasource = None
        self.sl_trailing_selected_indicator = None
        self.sl_trailing_key_values = None
        self.sl_trailing_trigger_evaluator = None
        self.sl_trailing_indicator_config_name = None
        self.sl_trailing_datasource = None
        self.sl_trailing_indicator_init_value = None
        self.sl_trailing_min_p = None
        self.sl_trailing_max_p = None
        self.atr_period = None
        self.position_size_type = None
        self.risk_in_p = None
        self.total_risk_in_p = None
        self.risk_in_d = None
        self.total_risk_in_d = None
        self.slippage_limit = None
        self.market_in_if_limit_fails = None
        self.tp_types = None
        self.tp_type = None
        self.recreate_exits = None
        self.tp_rr = None
        self.tp_in_p = None
        self.use_scaled_tp = None
        self.rr_tp_min = None
        self.rr_tp_max = None
        self.rr_tp_order_count = None
        self.p_tp_min = None
        self.p_tp_max = None
        self.p_tp_order_count = None
        self.enable_alerts = None
        self.indicator_cache = {}
        self.initialized = False

    async def initialize(self):
        self.entry_types = {"market_in": "Market in",
                            "limit_in": "Limit in",
                            "try_limit_in": "Try to limit in",
                            "time_grid_orders": "spread entry orders across time",
                            "scaled_entry": "spread limit orders over a price range"}
        self.sl_types = {"no_sl": "no SL",
                         "at_low_high_title": "SL at the low/high",
                         "based_on_p_title": "SL based on %",
                         "based_on_atr_title": "Sl based on ATR",
                         "based_on_indicator": "SL based on indicator"}

        self.sl_trail_types = {"dont_trail": "dont move the stop loss",
                               "break_even": "move stop loss to break even",
                               "trailing": "trailing stop loss based on sl settings",
                               "trailing_indicator": "trailing stop loss based on indicator"}
        self.tp_types = {"no_tp_title": "dont use managed Take Profit",
                         "tp_based_on_rr_title": "take profit based on risk reward",
                         "tp_based_on_p_title": "take profit based on fixed percent",
                         "scaled_tp_rr_title": "scaled take profit based on risk reward",
                         "scaled_tp_p_title": "scaled take profit based on percent"}
        self.position_size_types = {"based_on_d": "Position size based on $ risk",
                                    "based_on_p": "Position size based on % risk",
                                    "based_on_account": "Position size based on % of account size"}

        self.managed_order_active = True

        entry_path = self.input_root_path + "/Entry Settings"
        # entry type
        self.entry_type = await basic_keywords.user_input(self.context, "entry type", "options",
                                                          self.entry_types["market_in"],
                                                          options=[self.entry_types["market_in"],
                                                                   self.entry_types["limit_in"],
                                                                   self.entry_types["try_limit_in"],
                                                                   self.entry_types["scaled_entry"],
                                                                   self.entry_types["time_grid_orders"]],
                                                          path=entry_path)
        # entry: limit in
        if self.entry_type == self.entry_types["limit_in"]:
            self.limit_offset = await basic_keywords.user_input(self.context,
                                                                "limit entry offset in %", "float", 0.2, 0,
                                                                path=entry_path)

        # entry: try limit in
        if self.entry_type == self.entry_types["try_limit_in"]:
            self.slippage_limit = await basic_keywords.user_input(self.context,
                                                                  "Slippage Limit: can be % or price", "float", 40,
                                                                  path=entry_path)
            self.market_in_if_limit_fails = await basic_keywords.user_input(self.context, "try to limit in", "boolean",
                                                                            True, path=entry_path)

        if self.entry_type == self.entry_types["scaled_entry"]:
            self.entry_scaled_min = await basic_keywords.user_input(self.context,
                                                                    "scale limit orders from: (measured in %) ",
                                                                    "float", 1, 0, path=entry_path)
            self.entry_scaled_max = await basic_keywords.user_input(self.context,
                                                                    "scale limit orders to: (measured in %",
                                                                    "float", 2, 0, path=entry_path)
            self.entry_scaled_order_count = await basic_keywords.user_input(self.context, "amount of entry orders",
                                                                            "int", 10, 2, path=entry_path)
        exit_path = self.input_root_path + "/Exit Settings"
        self.recreate_exits = await basic_keywords.user_input(self.context,
                                                              "Recreate exit orders on new entrys: When "
                                                              "enabled exit orders will be replaced with "
                                                              "new ones based on the current candle", "boolean", False,
                                                              path=exit_path)
        # SL
        sl_path = exit_path + "/Stop Loss Settings"
        self.sl_type = await basic_keywords.user_input(self.context, "SL type", "options",
                                                       self.sl_types["based_on_p_title"],
                                                       options=[self.sl_types["no_sl"],
                                                                self.sl_types["at_low_high_title"],
                                                                self.sl_types["based_on_p_title"],
                                                                self.sl_types["based_on_atr_title"],
                                                                self.sl_types["based_on_indicator"]],
                                                       path=sl_path)

        if self.sl_type == self.sl_types["no_sl"]:
            position_size_options = [self.position_size_types["based_on_account"]]
            position_size_def_val = self.position_size_types["based_on_account"]
            tp_type_def_val = self.tp_types["tp_based_on_p_title"]
            tp_type_optinions = [self.tp_types["no_tp_title"], self.tp_types["tp_based_on_p_title"],
                                 self.tp_types["scaled_tp_p_title"]]
            self.sl_trail_type = self.sl_trail_types["dont_trail"]
        else:
            position_size_options = [self.position_size_types["based_on_p"], self.position_size_types["based_on_d"],
                                     self.position_size_types["based_on_account"]]
            position_size_def_val = self.position_size_types["based_on_p"]

            tp_type_def_val = self.tp_types["tp_based_on_rr_title"]
            tp_type_optinions = [self.tp_types["no_tp_title"], self.tp_types["tp_based_on_rr_title"],
                                 self.tp_types["tp_based_on_p_title"], self.tp_types["scaled_tp_rr_title"],
                                 self.tp_types["scaled_tp_p_title"]]

            # SL based on low/high
            if self.sl_type == self.sl_types["at_low_high_title"]:
                self.sl_low_high_lookback = await basic_keywords.user_input(self.context,
                                                                            "SL at low/high lookback period", "int", 3,
                                                                            path=sl_path)
                self.sl_low_high_buffer = await basic_keywords.user_input(self.context,
                                                                          "SL at low/high buffer in %", "float", 0.2,
                                                                          path=sl_path)
                self.sl_min_p = await basic_keywords.user_input(self.context, "min SL in %", "float", 0.1, 0,
                                                                path=sl_path)
                self.sl_max_p = await basic_keywords.user_input(self.context, "max SL in %", "float", 1, 0,
                                                                path=sl_path)

            # sl based on percent
            elif self.sl_type == self.sl_types["based_on_p_title"]:
                self.sl_in_p_value = await basic_keywords.user_input(self.context, "SL in %", "float", 0.5, 0,
                                                                     path=sl_path)

            # sl based on indicator
            elif sl_sources:
                if self.sl_type == self.sl_types["based_on_indicator"]:
                    await sl_sources.activate_sl_indicator(self.context, self.input_root_path, self)

                    self.sl_min_p = await basic_keywords.user_input(self.context, "min SL in %", "float", 0.1, 0,
                                                                    path=sl_path)
                    self.sl_max_p = await basic_keywords.user_input(self.context, "max SL in %", "float", 1, 0,
                                                                    path=sl_path)

            # SL based on atr
            elif self.sl_type == self.sl_types["based_on_atr_title"]:
                self.atr_period = await basic_keywords.user_input(self.context, "ATR Period", "int", 4,
                                                                  path=sl_path)
                self.sl_min_p = await basic_keywords.user_input(self.context, "min SL in %", "float", 0.1, 0,
                                                                path=sl_path)
                self.sl_max_p = await basic_keywords.user_input(self.context, "max SL in %", "float", 1, 0,
                                                                path=sl_path)
            trail_sl_path = sl_path + "/Trailing Stop Settings"
            # trailing SL
            self.sl_trail_type = await basic_keywords.user_input(self.context, "SL trailing type", "options",
                                                                 self.sl_trail_types["dont_trail"],
                                                                 options=[self.sl_trail_types["dont_trail"],
                                                                          self.sl_trail_types["break_even"],
                                                                          self.sl_trail_types["trailing"],
                                                                          self.sl_trail_types["trailing_indicator"]
                                                                          ], path=trail_sl_path)
            if self.sl_trail_type == self.sl_trail_types["break_even"]:
                self.sl_trail_start_only_in_profit = True
                self.sl_trail_start = await basic_keywords.user_input(self.context,
                                                                      "move stop loss to break even "
                                                                      "when price moves x% into profit",
                                                                      "float", 0.5, 0, path=trail_sl_path)
                self.sl_trail_start_only_if_above_entry = False
            elif self.sl_trail_type == self.sl_trail_types["trailing"]:
                self.sl_trail_start_only_in_profit = await basic_keywords. \
                    user_input(self.context, "start stop loss trailing only when price moves into profit",
                               "boolean", True, path=trail_sl_path)
                if self.sl_trail_start_only_in_profit:
                    self.sl_trail_start = await basic_keywords.user_input(self.context,
                                                                          "start trailing the SL "
                                                                          "when price moves x% into profit",
                                                                          "float", 0.5, 0, path=trail_sl_path)
                self.sl_trail_start_only_if_above_entry \
                    = await basic_keywords.user_input(self.context, "Start trailing only if SL would be above the entry"
                                                      , "boolean", True, path=trail_sl_path)

            elif self.sl_trail_type == self.sl_trail_types["trailing_indicator"]:
                if sl_sources:
                    await sl_sources.activate_trailing_sl_indicator(self.context, self.input_root_path, self)
                    self.sl_trail_start_only_in_profit = await basic_keywords. \
                        user_input(self.context, "start stop loss trailing only when price moves into profit",
                                   "boolean", True, path=trail_sl_path)
                    if self.sl_trail_start_only_in_profit:
                        self.sl_trail_start = await basic_keywords. \
                            user_input(self.context, "start trailing the SL when price moves x% into profit",
                                       "float", 0.5, 0, path=trail_sl_path)
                    self.sl_trailing_min_p = await basic_keywords. \
                        user_input(self.context, "min trailing SL in %", "float", 0.1, 0, path=trail_sl_path)
                    self.sl_trailing_max_p = await basic_keywords. \
                        user_input(self.context, "max trailing SL in %", "float", 1, 10, path=trail_sl_path)
                    self.sl_trail_start_only_if_above_entry \
                        = await basic_keywords.user_input(self.context, "Start trailing only if SL would "
                                                                        "be above the entry",
                                                          "boolean", True, path=trail_sl_path)
        position_size_path = self.input_root_path + "/Position Size Settings"
        # position size
        self.position_size_type = await basic_keywords.user_input(self.context, "position Size Type", "options",
                                                                  position_size_def_val, options=position_size_options,
                                                                  path=position_size_path)

        # position size based on percent risk
        if self.position_size_type == self.position_size_types["based_on_d"]:
            self.risk_in_d = await basic_keywords.user_input(self.context,
                                                             "risk per trade (measured in reference market currency)",
                                                             "float", 100, 0, path=position_size_path)
            self.total_risk_in_d = await basic_keywords.user_input(self.context,
                                                                   "total risk (measured in reference market currency)",
                                                                   "float", 200, 0, path=position_size_path)

        # position size based on dollar risk (measured in reference market)
        elif self.position_size_type == self.position_size_types["based_on_p"]:
            self.risk_in_p = await basic_keywords.user_input(self.context, "risk per trade in %", "float", 0.5, 0,
                                                             path=position_size_path)
            self.total_risk_in_p = await basic_keywords.user_input(self.context, "total risk in %", "float", 2, 0,
                                                                   path=position_size_path)

        # position size based on % of account size
        elif self.position_size_type == self.position_size_types["based_on_account"]:
            self.risk_in_p = await basic_keywords.user_input(self.context, "position per trade in % of account size",
                                                             "float", 50, 0, path=position_size_path)
            self.total_risk_in_p = await basic_keywords.user_input(self.context, "max position in % of account size",
                                                                   "float", 100, 0, path=position_size_path)

        tp_path = exit_path + "/Take Profit Settings"
        # TP
        self.tp_type = await basic_keywords.user_input(self.context, "Take profit type", "options",
                                                       tp_type_def_val, options=tp_type_optinions,
                                                       path=tp_path)

        # TP based on risk reward
        if self.tp_type == self.tp_types["tp_based_on_rr_title"]:
            self.tp_rr = await basic_keywords.user_input(self.context, "TP Risk Reward target", "float", 2, 0,
                                                         path=tp_path)

        # TP based on percent
        elif self.tp_type == self.tp_types["tp_based_on_p_title"]:
            self.tp_in_p = await basic_keywords.user_input(self.context, "TP in %", "float", 2, 0,
                                                           path=tp_path)

        # scaled TP based on risk reward
        elif self.tp_type == self.tp_types["scaled_tp_rr_title"]:
            self.rr_tp_min = await basic_keywords.user_input(self.context, "take profit min risk reward target",
                                                             "float", 2, 0, path=tp_path)
            self.rr_tp_max = await basic_keywords.user_input(self.context, "take profit max risk reward target",
                                                             "float", 10, 0, path=tp_path)
            self.rr_tp_order_count = await basic_keywords.user_input(self.context, "take profit order count",
                                                                     "int", 10, 2, path=tp_path)

        # scaled TP based on percent
        elif self.tp_type == self.tp_types["scaled_tp_p_title"]:
            self.p_tp_min = await basic_keywords.user_input(self.context, "scale take profit from: (measured in %) ",
                                                            "float", 1, 0, path=tp_path)
            self.p_tp_max = await basic_keywords.user_input(self.context, "scale take profit to: (measured in %",
                                                            "float", 50, 0, path=tp_path)
            self.p_tp_order_count = await basic_keywords.user_input(self.context, "take profit order count",
                                                                    "int", 10, 2, path=tp_path)

        # alerts
        self.enable_alerts = await basic_keywords.user_input(self.context, "enable detailed trade alerts",
                                                             "boolean", True, path=self.input_root_path, order=9999)
        self.initialized = True
