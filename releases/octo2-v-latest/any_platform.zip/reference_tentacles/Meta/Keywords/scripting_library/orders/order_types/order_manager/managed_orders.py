#  Drakkar-Software OctoBot-Trading
#  Copyright (c) Drakkar-Software, All rights reserved.
#
#  This library is free software; you can redistribute it and/or
#  modify it under the terms of the GNU Lesser General Public
#  License as published by the Free Software Foundation; either
#  version 3.0 of the License, or (at your option) any later version.
#
#  This library is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
#  Lesser General Public License for more details.
#
#  You should have received a copy of the GNU Lesser General Public
#  License along with this library.

import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.settings as settings
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.order_placement as order_placement
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.utilities as utilities
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.position_sizing as position_sizing
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.order_notification as order_notification


async def activate_managed_orders(ctx, user_input_path="evaluator/Managed_Order_Settings"):
    orders_settings = settings.ManagedOrdersSettings(ctx, user_input_path)
    await orders_settings.initialize()
    return orders_settings


async def managed_order(ctx, trading_side="long", orders_settings=None,
                        user_input_path="evaluator/Managed_Order_Settings"):
    """

    :param ctx:
    :param trading_side:
        can be "long" or short
    :param orders_settings:
        pass custom settings or use activate_managed_orders(ctx)
    :return:
    """
    if not ctx.enable_trading:
        return
    managed_orders_settings = orders_settings or settings.ManagedOrdersSettings(ctx, user_input_path)
    if not managed_orders_settings.initialized:
        await managed_orders_settings.initialize()
    managed_order_data = utilities.get_trading_sides(trading_side)

    # get position size
    managed_order_data = await position_sizing.get_managed_position_size(ctx, managed_orders_settings,
                                                                         managed_order_data)

    if managed_order_data.place_entries:
        # get order tag and position mode
        managed_order_data = await utilities.get_managed_amount_and_order_tag(ctx, managed_orders_settings,
                                                                              managed_order_data)

        # create entry orders
        managed_order_data = await order_placement.place_managed_entry_and_stop_orders(ctx, managed_orders_settings,
                                                                                       managed_order_data)
        # todo handle take profits for limit entries
        # create exit orders
        managed_order_data = await order_placement.place_managed_exit_orders(ctx, managed_orders_settings, managed_order_data)

        # send an alert in live mode
        await order_notification.send_managed_order_notification(ctx, managed_orders_settings, managed_order_data)
