import tentacles.Meta.Keywords.scripting_library.orders.order_types as order_types
import octobot_trading.enums as trading_enums


async def place_managed_take_profits(ctx, managed_orders_settings, managed_order_data):
    managed_order_data.entry_price = managed_order_data.entry_price \
                                     or float(managed_order_data.created_orders[0].filled_price) \
                                     or managed_order_data.expected_entry_price
    # take profits
    if managed_orders_settings.tp_types["no_tp_title"] != managed_orders_settings.tp_type:
        # take profit based on risk reward
        if managed_orders_settings.tp_type == managed_orders_settings.tp_types["tp_based_on_rr_title"]:
            managed_order_data.entry_fees = managed_order_data.market_fee if managed_order_data.entry_type == "market" \
                else managed_order_data.limit_fee
            if managed_order_data.entry_side == trading_enums.TradeOrderSide.BUY.value:
                managed_order_data.profit_in_p = managed_orders_settings.tp_rr * (
                        managed_order_data.sl_in_p + managed_order_data.market_fee
                        + managed_order_data.entry_fees)
                managed_order_data.profit_in_d = managed_order_data.entry_price * (1 + (managed_order_data.profit_in_p / 100))
            else:
                managed_order_data.profit_in_p = managed_orders_settings.tp_rr * (
                        managed_order_data.sl_in_p + managed_order_data.market_fee
                        + managed_order_data.entry_fees)
                managed_order_data.profit_in_d = managed_order_data.entry_price * (1 - (managed_order_data.profit_in_p / 100))

            await order_types.limit(ctx, side=managed_order_data.exit_side, amount=managed_order_data.exit_amount,
                                    target_position=managed_order_data.exit_target_position,
                                    offset=f"@{managed_order_data.profit_in_d}", group=managed_order_data.order_group,
                                    tag=managed_order_data.exit_order_tag,
                                    reduce_only=True, wait_for=managed_order_data.created_orders)

        # scaled take profit based on risk reward
        elif managed_orders_settings.tp_type == managed_orders_settings.tp_types["scaled_tp_rr_title"]:
            managed_order_data.entry_fees = managed_order_data.market_fee if managed_order_data.entry_type == "market" \
                else managed_order_data.limit_fee
            if managed_order_data.entry_side == trading_enums.TradeOrderSide.BUY.value:
                scale_from = managed_order_data.entry_price * \
                             (1 + (managed_orders_settings.rr_tp_min *
                                   (managed_order_data.sl_in_p + managed_order_data.market_fee
                                    + managed_order_data.entry_fees) / 100))
                scale_from = f"@{scale_from}"
                scale_to = managed_order_data.entry_price * \
                           (1 + (managed_orders_settings.rr_tp_max *
                                 (managed_order_data.sl_in_p + managed_order_data.market_fee
                                  + managed_order_data.entry_fees) / 100))
                scale_to = f"@{scale_to}"
            else:
                scale_from = managed_order_data.entry_price * \
                             (1 - (managed_orders_settings.rr_tp_max *
                                   (managed_order_data.sl_in_p + managed_order_data.market_fee
                                    + managed_order_data.entry_fees) / 100))
                scale_from = f"@{scale_from}"
                scale_to = managed_order_data.entry_price * \
                           (1 - (managed_orders_settings.rr_tp_min *
                                 (managed_order_data.sl_in_p + managed_order_data.market_fee
                                  + managed_order_data.entry_fees) / 100))
                scale_to = f"@{scale_to}"

            await order_types.scaled_limit(ctx, side=managed_order_data.exit_side,
                                           amount=managed_order_data.exit_amount,
                                           target_position=managed_order_data.exit_target_position,
                                           scale_from=scale_from,
                                           scale_to=scale_to, order_count=managed_orders_settings.rr_tp_order_count,
                                           group=managed_order_data.order_group, tag=managed_order_data.exit_order_tag,
                                           reduce_only=True, wait_for=managed_order_data.created_orders)

        # take profit based on percent
        elif managed_orders_settings.tp_type == managed_orders_settings.tp_types["tp_based_on_p_title"]:
            managed_order_data.profit_in_d = managed_order_data.entry_price * (1 + (managed_orders_settings.tp_in_p / 100)) \
                if managed_order_data.entry_side == trading_enums.TradeOrderSide.BUY.value \
                else managed_order_data.entry_price * (1 - (managed_orders_settings.tp_in_p / 100))
            await order_types.limit(ctx, side=managed_order_data.exit_side, amount=managed_order_data.exit_amount,
                                    target_position=managed_order_data.exit_target_position,
                                    offset=f"@{managed_order_data.profit_in_d}", group=managed_order_data.order_group,
                                    tag=managed_order_data.exit_order_tag, reduce_only=True,
                                    wait_for=managed_order_data.created_orders)

        # scaled take profit based on percent
        elif managed_orders_settings.tp_type == managed_orders_settings.tp_types["scaled_tp_p_title"]:
            if managed_order_data.entry_side == trading_enums.TradeOrderSide.BUY.value:
                scale_from = managed_order_data.entry_price * (1 + (managed_orders_settings.p_tp_min / 100))
                scale_from = f"@{scale_from}"
                scale_to = managed_order_data.entry_price * (1 + (managed_orders_settings.p_tp_max / 100))
                scale_to = f"@{scale_to}"
            else:
                scale_from = managed_order_data.entry_price * (1 + (managed_orders_settings.p_tp_max / 100))
                scale_from = f"@{scale_from}"
                scale_to = managed_order_data.entry_price * (1 + (managed_orders_settings.p_tp_min / 100))
                scale_to = f"@{scale_to}"

            await order_types.scaled_limit(ctx, side=managed_order_data.exit_side,
                                           amount=managed_order_data.exit_amount,
                                           target_position=managed_order_data.exit_target_position,
                                           scale_from=scale_from,
                                           scale_to=scale_to, order_count=managed_orders_settings.p_tp_order_count,
                                           group=managed_order_data.order_group, tag=managed_order_data.exit_order_tag,
                                           reduce_only=True, wait_for=managed_order_data.created_orders)
    return managed_order_data
