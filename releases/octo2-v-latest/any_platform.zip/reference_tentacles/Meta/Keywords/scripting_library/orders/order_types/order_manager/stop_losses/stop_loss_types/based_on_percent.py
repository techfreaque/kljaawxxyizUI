import octobot_trading.enums as trading_enums


def get_stop_loss_based_on_percent(managed_orders_settings, trading_side, current_price_val):
    if trading_side == trading_enums.PositionSide.LONG.value:
        sl_in_p = managed_orders_settings.sl_in_p_value
        sl_price = current_price_val * (1 - (sl_in_p / 100))
    elif trading_side == trading_enums.PositionSide.SHORT.value:
        sl_in_p = managed_orders_settings.sl_in_p_value
        sl_price = current_price_val * (1 + (sl_in_p / 100))
    else:
        raise RuntimeError('Side needs to be "long" or "short" for your managed order')
    return sl_in_p, sl_price
