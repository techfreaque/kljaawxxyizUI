import tentacles.Meta.Keywords.scripting_library.orders.order_types as order_types
import octobot_trading.modes.script_keywords.basic_keywords as basic_keywords
import octobot_trading.enums as trading_enums
import octobot_trading.constants as trading_constants
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.stop_losses as stop_losses
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.utilities as utilities
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.take_profits as take_profits
import tentacles.Meta.Keywords.scripting_library.orders.grouping as grouping
import tentacles.Meta.Keywords.scripting_library.orders.waiting as waiting


async def place_managed_entry_and_stop_orders(ctx, managed_orders_settings, managed_order_data):
    # ensure leverage is up to date
    await basic_keywords.user_select_leverage(ctx)
    await basic_keywords.set_partial_take_profit_stop_loss(ctx)

    # stop loss

    if managed_orders_settings.sl_types["no_sl"] != managed_orders_settings.sl_type:
        managed_order_data.sl_offset = f"@{managed_order_data.sl_price}"
        managed_order_data.sl_tag = managed_order_data.exit_order_tag

    # entry

    managed_order_data.entry_type = "market"
    # entry try limit in
    # todo + handle on backtesting (maybe use always 1m to check if it got filled)
    if managed_orders_settings.entry_type == managed_orders_settings.entry_types["try_limit_in"]:
        # entry_type = "limit"
        # created_orders = await order_types.trailing_limit(ctx, amount=position_size_limit, side=entry_side,
        #                                                   min_offset=0, max_offset=0,
        #                                                   slippage_limit=managed_orders_settings.slippage_limit,
        #                                                   tag=entry_order_tag, stop_loss_offset=sl_offset,
        #                                                   stop_loss_tag=sl_tag)
        # # wait for limit to get filled
        # if tag_triggered.tagged_order_unfilled(entry_order_tag):
        #     unfilled_amount = tag_triggered.tagged_order_unfilled_amount(entry_order_tag)
        #     if unfilled_amount != position_size_limit:
        #         position_size_market = 50  # todo calc smaller size cause of fees
        #     created_orders = await order_types.market(ctx, side=entry_side, amount=position_size_market,
        #                                               tag=entry_order_tag, stop_loss_offset=sl_offset,
        #                                               stop_loss_tag=sl_tag)
        raise NotImplementedError("managed order: try limit in not implemented yet")

    # entry market in only
    elif managed_orders_settings.entry_type == managed_orders_settings.entry_types["market_in"]:
        managed_order_data.created_orders = await order_types.market(ctx, side=managed_order_data.entry_side,
                                                                     amount=managed_order_data.position_size_market,
                                                                     tag=managed_order_data.entry_order_tag,
                                                                     stop_loss_offset=managed_order_data.sl_offset,
                                                                     stop_loss_tag=managed_order_data.sl_tag)

    # entry limit in only
    elif managed_orders_settings.entry_type == managed_orders_settings.entry_types["limit_in"]:
        managed_order_data.entry_type = "limit"
        managed_order_data.created_orders = await order_types.limit(ctx, side=managed_order_data.entry_side,
                                                                    amount=managed_order_data.position_size_limit,
                                                                    offset=f"-{managed_orders_settings.limit_offset}%",
                                                                    tag=managed_order_data.entry_order_tag,
                                                                    stop_loss_offset=managed_order_data.sl_offset,
                                                                    stop_loss_tag=managed_order_data.sl_tag)

    # entry scaled limits
    elif managed_orders_settings.entry_type == managed_orders_settings.entry_types["scaled_entry"]:
        managed_order_data.entry_type = "limit"
        if managed_order_data.entry_side == trading_enums.TradeOrderSide.BUY.value:
            scale_from = f"-{managed_orders_settings.entry_scaled_max}%"
            scale_to = f"-{managed_orders_settings.entry_scaled_min}%"
        else:
            scale_from = f"{managed_orders_settings.entry_scaled_min}%"
            scale_to = f"{managed_orders_settings.entry_scaled_max}%"

        managed_order_data.created_orders = \
            await order_types.scaled_limit(ctx, side=managed_order_data.entry_side,
                                           amount=managed_order_data.position_size_limit,
                                           scale_from=scale_from, scale_to=scale_to,
                                           order_count=managed_orders_settings.entry_scaled_order_count
                                           , tag=managed_order_data.entry_order_tag,
                                           stop_loss_offset=managed_order_data.sl_offset,
                                           stop_loss_tag=managed_order_data.sl_tag)
    # entry time grid orders
    elif managed_orders_settings.entry_type == managed_orders_settings.entry_types["time_grid_orders"]:
        raise NotImplementedError("time grid orders not implemented yet")
    return managed_order_data


async def place_managed_exit_orders(ctx, managed_orders_settings, managed_order_data):
    if not managed_order_data.created_orders \
            or (managed_order_data.created_orders[0] is None and len(managed_order_data.created_orders) == 1):
        # no entry created: do not create exits
        return managed_order_data

    # create order group if necessary
    managed_order_data = await utilities.handle_manged_order_group(ctx, managed_orders_settings, managed_order_data)

    # in real treading wait for orders and modify SL if necessary
    if ctx.exchange_manager.trader.trader_type_str == trading_constants.REAL_TRADER_STR:
        managed_order_data = await handle_managed_real_trading_orders(ctx, managed_orders_settings, managed_order_data)

    # place take profits
    # todo use offset from entry instead of current price
    managed_order_data = await take_profits.place_managed_take_profits(ctx, managed_orders_settings, managed_order_data)

    if managed_order_data.enabled_order_group:
        await grouping.enable_group(managed_order_data.order_group, True)
    return managed_order_data


async def handle_managed_real_trading_orders(ctx, managed_orders_settings, managed_order_data):
    if managed_orders_settings.sl_types["no_sl"] != managed_orders_settings.sl_type:
        if managed_order_data.entry_type == "market":
            # edit stop loss to accurate values once market is filled
            try:
                await stop_losses.adjust_managed_stop_loss(ctx, managed_orders_settings, managed_order_data)
            except Exception as e:
                ctx.logger.error(f"Managed Order: adapting stop loss based on filled price failed. (error: {e})")
                # in case it fails continue anyway creating take profits
        else:  # limit orders
            # for limit orders we wait for the stop loss to be placed
            await waiting.wait_for_stop_loss_open(ctx, managed_order_data.created_orders, timeout=60)
    return managed_order_data
