import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.stop_losses.\
    stop_loss_handling as stop_loss_handling
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data.open_positions as open_positions
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data.account_balance as account_balance
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_private_data as exchange_private_data
import octobot_trading.enums as trading_enums
import decimal as decimal


async def get_managed_position_size(ctx, managed_orders_settings, managed_order_data):
    # SL get stop loss to calculate position size

    if managed_orders_settings.sl_type != managed_orders_settings.sl_types["no_sl"]:
        managed_order_data.sl_price, managed_order_data.sl_in_p, managed_order_data.expected_entry_price = \
            await stop_loss_handling.get_manged_order_stop_loss(ctx, managed_orders_settings, managed_order_data.trading_side)

    # position size

    fees = exchange_public_data.symbol_fees(ctx)
    fallback_fees = fees.get("fee", 0)
    managed_order_data.limit_fee = float(fallback_fees if fees["maker"] is None else fees["maker"]) * 100
    managed_order_data.market_fee = float(fallback_fees if fees["taker"] is None else fees["taker"]) * 100

    # position size based on dollar/reference market risk
    if managed_orders_settings.position_size_type == managed_orders_settings.position_size_types["based_on_d"]:
        managed_order_data.position_size_market = \
            ((managed_orders_settings.risk_in_d / managed_order_data.expected_entry_price)
             / (managed_order_data.sl_in_p + (managed_order_data.market_fee + managed_order_data.market_fee))) / 0.01
        managed_order_data.position_size_limit = \
            ((managed_orders_settings.risk_in_d / managed_order_data.expected_entry_price)
             / (managed_order_data.sl_in_p + (managed_order_data.limit_fee + managed_order_data.market_fee))) / 0.01

        managed_order_data.current_open_risk = await get_current_open_risk(ctx, managed_order_data.market_fee,
                                                                           # todo use entry fees instead
                                                                           managed_order_data.market_fee)

        managed_order_data.max_position_size = (((managed_orders_settings.total_risk_in_d
                                                  / managed_order_data.expected_entry_price) - managed_order_data.current_open_risk)
                                                / (managed_order_data.sl_in_p + (
                        2 * managed_order_data.market_fee))) / 0.01

    # position size based risk per trade in percent
    elif managed_orders_settings.position_size_type == managed_orders_settings.position_size_types["based_on_p"]:
        current_total_acc_balance = float(await exchange_private_data.total_account_balance(ctx))
        risk_in_d = (managed_orders_settings.risk_in_p / 100) * current_total_acc_balance

        managed_order_data.position_size_market = (risk_in_d / (
                managed_order_data.sl_in_p + (2 * managed_order_data.market_fee))) / 0.01
        managed_order_data.position_size_limit = (risk_in_d / (
                managed_order_data.sl_in_p + managed_order_data.limit_fee + managed_order_data.market_fee)) / 0.01

        managed_order_data.current_open_risk = await get_current_open_risk(ctx, managed_order_data.market_fee,
                                                                           # todo use entry fees instead
                                                                           managed_order_data.market_fee)

        total_risk_in_d = (managed_orders_settings.total_risk_in_p / 100) \
                          * current_total_acc_balance - managed_order_data.current_open_risk

        managed_order_data.max_position_size = (total_risk_in_d / (
                managed_order_data.sl_in_p + (2 * managed_order_data.market_fee))) / 0.01

    # position size based on percent of total account balance
    elif managed_orders_settings.position_size_type == managed_orders_settings.position_size_types["based_on_account"]:
        current_total_acc_balance = float(await exchange_private_data.total_account_balance(ctx))
        managed_order_data.position_size_market = (managed_orders_settings.risk_in_p / 100) * current_total_acc_balance
        managed_order_data.position_size_limit = managed_order_data.position_size_market
        current_open_position_size = open_positions.open_position_size(ctx, side="both")

        if managed_order_data.trading_side == trading_enums.PositionSide.SHORT.value:
            current_open_position_size *= -1
        managed_order_data.max_position_size = (managed_orders_settings.total_risk_in_p / 100) \
                                               * current_total_acc_balance

    managed_order_data.max_position_size = float(exchange_public_data.
                                                 get_digits_adapted_amount(ctx, decimal.Decimal(managed_order_data.
                                                                                                max_position_size)))

    managed_order_data.max_buying_power = float(exchange_public_data. \
        get_digits_adapted_amount(ctx, await account_balance.available_account_balance(ctx,
                                                                                       side=managed_order_data.entry_side,
                                                                                       reduce_only=False)))

    # check if enough balance for requested size and cut if necessary
    if managed_order_data.max_buying_power < managed_order_data.position_size_market:
        managed_order_data.position_size_market = managed_order_data.max_buying_power
        managed_order_data.position_size_limit = managed_order_data.max_buying_power

    # cut the position size so that it aligns with target risk
    if managed_order_data.position_size_market > managed_order_data.max_position_size:
        managed_order_data.position_size_limit = managed_order_data.max_position_size
        managed_order_data.position_size_market = managed_order_data.max_position_size

    managed_order_data.position_size_limit \
        = float(
        exchange_public_data.get_digits_adapted_amount(ctx, decimal.Decimal(managed_order_data.position_size_limit)))
    managed_order_data.position_size_market \
        = float(
        exchange_public_data.get_digits_adapted_amount(ctx, decimal.Decimal(managed_order_data.position_size_market)))

    if managed_order_data.position_size_market <= 0:
        ctx.logger.info("Managed order cant open a new position, maximum position size is reached")
        return managed_order_data
    else:
        managed_order_data.place_entries = True
        return managed_order_data


async def get_current_open_risk(ctx, market_fee, exit_fee):
    current_average_long_entry = float(await open_positions.average_open_pos_entry(ctx, side="long"))
    current_average_short_entry = float(await open_positions.average_open_pos_entry(ctx, side="short"))
    current_open_orders = ctx.exchange_manager.exchange_personal_data.orders_manager.orders
    current_open_risk = 0
    for order in current_open_orders:
        if current_open_orders[order].order_type == trading_enums.TraderOrderType.STOP_LOSS:
            if current_open_orders[order].side == trading_enums.TradeOrderSide.SELL:
                stop_loss_distance = current_average_long_entry - float(current_open_orders[order].origin_price)
            else:
                stop_loss_distance = float(current_open_orders[order].origin_price) - current_average_short_entry
            current_open_risk += ((market_fee + exit_fee) / 100) * float(current_open_orders[order].origin_quantity) \
                                 + (float(current_open_orders[order].origin_quantity) * stop_loss_distance
                                    / float(current_open_orders[order].origin_price))
    return current_open_risk
