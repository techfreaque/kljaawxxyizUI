from .based_on_indicator import *
from .based_on_low_high import *
from .based_on_percent import *
from .based_on_atr import *
