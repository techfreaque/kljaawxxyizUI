import octobot_trading.enums as trading_enums
import decimal as decimal
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager. \
    stop_losses.stop_loss_handling as stop_loss_handling
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
try:
    from tentacles.Meta.Keywords.matrix_library.strategies_builder.key_words.orders import sl_sources as sl_sources
except ImportError:
    sl_sources = []


async def trail_to_indicator(ctx, managed_orders_settings):
    sl_price, _, _ = await get_managed_trailing_stop_from_indicator(ctx, managed_orders_settings)
    if managed_orders_settings.trading_side == trading_enums.PositionSide.LONG.value:
        return decimal.Decimal(sl_price)
    else:
        return decimal.Decimal(sl_price)


async def get_managed_trailing_stop_from_indicator(ctx, managed_orders_settings):
    current_price_val = float(await exchange_public_data.current_live_price(ctx))
    sl_price = sl_sources.get_trailing_sl_indicator(ctx, managed_orders_settings)
    sl_in_p = None
    if managed_orders_settings.trading_side == trading_enums.PositionSide.LONG.value:
        sl_in_p, sl_price = stop_loss_handling.trim_sl_long_price(sl_price, current_price_val,
                                                                  managed_orders_settings.sl_trailing_max_p,
                                                                  managed_orders_settings.sl_trailing_min_p)

    elif managed_orders_settings.trading_side == trading_enums.PositionSide.SHORT.value:
        sl_in_p, sl_price = stop_loss_handling.trim_sl_short_price(sl_price, current_price_val,
                                                                   managed_orders_settings.sl_trailing_max_p,
                                                                   managed_orders_settings.sl_trailing_min_p)
    return sl_price, sl_in_p, current_price_val
