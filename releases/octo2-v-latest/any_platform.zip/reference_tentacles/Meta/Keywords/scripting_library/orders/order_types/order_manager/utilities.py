import octobot_trading.enums as trading_enums
import octobot_trading.constants as trading_constants
import tentacles.Meta.Keywords.scripting_library.orders.cancelling as cancelling
import random as random
import tentacles.Meta.Keywords.scripting_library.orders.grouping as grouping


class ManagedOrderData:
    trading_side = None
    entry_price = None
    sl_price = None
    sl_in_p = None
    profit_in_p = None
    profit_in_d = None
    expected_entry_price = None
    position_size_market = 0
    position_size_limit = 0
    current_open_risk = None
    max_position_size = None
    max_buying_power = None
    place_entries = False
    sl_offset = None
    sl_tag = None
    entry_type = None
    created_orders = []
    market_fee = 0
    entry_fees = 0
    enabled_order_group = False


def get_trading_sides(trading_side):
    managed_order_data = ManagedOrderData()
    managed_order_data.trading_side = trading_side
    if trading_side == trading_enums.PositionSide.LONG.value:
        managed_order_data.trading_side = trading_side
        managed_order_data.entry_side = trading_enums.TradeOrderSide.BUY.value
        managed_order_data.exit_side = trading_enums.TradeOrderSide.SELL.value
        return managed_order_data

    elif trading_side == trading_enums.PositionSide.SHORT.value:
        managed_order_data.entry_side = trading_enums.TradeOrderSide.SELL.value
        managed_order_data.exit_side = trading_enums.TradeOrderSide.BUY.value
        return managed_order_data
    else:
        raise RuntimeError(
            'managed order: trading side must be "short" or "long"')


async def get_managed_amount_and_order_tag(ctx, managed_orders_settings, managed_order_data):
    # either replace existing exits or keep them and add new exits for new entry
    managed_order_data.exit_amount = None
    managed_order_data.exit_target_position = None
    if managed_orders_settings.recreate_exits:
        managed_order_data.exit_target_position = 0
        managed_order_data.exit_order_tag = f"managed_order {managed_order_data.trading_side} exit:"
        managed_order_data.entry_order_tag = f"managed_order {managed_order_data.trading_side} entry:"
        # todo use edit orders instead
        await cancelling.cancel_orders(ctx, managed_order_data.exit_order_tag)
        await cancelling.cancel_orders(ctx, managed_order_data.entry_order_tag)
        return managed_order_data

    else:  # keep existing exit orders and only add new exits
        managed_order_data.exit_amount = managed_order_data.position_size_market
        # todo use something unique to avoid canceling eventual other orders in the same candle
        order_tag_id = random.randint(0, 999999999)
        managed_order_data.exit_order_tag = f"managed_order {managed_order_data.trading_side} exit (id: {order_tag_id})"
        managed_order_data.entry_order_tag = f"managed_order {managed_order_data.trading_side} entry (id: {order_tag_id})"

        return managed_order_data


async def handle_manged_order_group(ctx, managed_orders_settings, managed_order_data):
    # order grouping
    managed_order_data.order_group = None
    managed_order_data.enabled_order_group = False
    if managed_orders_settings.tp_types["no_tp_title"] != managed_orders_settings.tp_type \
            and managed_orders_settings.sl_types["no_sl"] != managed_orders_settings.sl_type:
        try:
            managed_order_data.order_group = grouping.\
                get_or_create_balanced_take_profit_and_stop_group(ctx, orders=managed_order_data.created_orders)
        except AttributeError:
            # try to continue creating exits without grouping as entries are probably placed already
            managed_order_data.enabled_order_group = False
            ctx.logger.error("Managed order: failed to activate exit order grouping")
            return managed_order_data
        # disable group to be able to create stop and take profit orders sequentially
        await grouping.enable_group(managed_order_data.order_group, False)
        managed_order_data.enabled_order_group = True
    return managed_order_data
