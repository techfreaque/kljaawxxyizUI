import decimal
import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
import octobot_trading.enums as trading_enums


async def trail_to_break_even(ctx, managed_orders_settings, av_entry, fees):
    fees = fees or exchange_public_data.symbol_fees(ctx)
    if managed_orders_settings.trading_side == trading_enums.PositionSide.LONG.value:
        break_even_price = (1 + (fees["taker"] / 100)) * av_entry
    else:
        break_even_price = (1 - (fees["taker"]) / 100) * av_entry
    return decimal.Decimal(break_even_price)
