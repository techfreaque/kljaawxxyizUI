import tentacles.Meta.Keywords.scripting_library.alerts.notifications as alert_notifications
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager.position_sizing as position_sizing
import octobot_commons.symbols.symbol_util as symbol_util


async def send_managed_order_notification(ctx, managed_orders_settings, managed_order_data):
    if ctx.exchange_manager.is_backtesting is not True and managed_orders_settings.enable_alerts:
        alert_title = f"opened a new {managed_order_data.trading_side} trade"
        entry_part = ""
        if managed_orders_settings.entry_type == managed_orders_settings.entry_types["market_in"]:
            entry_part = f"entry price: {managed_order_data.entry_price} \n" \
                         f"entry type: {managed_order_data.entry_type} \n"

        stop_loss_part = ""
        if managed_orders_settings.sl_type != managed_orders_settings.sl_types["no_sl"]:
            stop_loss_part = f"stop loss in %: {managed_order_data.sl_in_p} \n" \
                             f"stop loss @: {managed_order_data.sl_price}\n"
        take_profit_part = ""
        if managed_orders_settings.tp_type == managed_orders_settings.tp_types["tp_based_on_rr_title"]:
            take_profit_part = f"take profit risk reward: {managed_orders_settings.tp_rr} \n" \
                               f"take profit in %: {managed_order_data.profit_in_p} \n" \
                               f"take profit @: {managed_order_data.profit_in_d} \n"
        elif managed_orders_settings.tp_type == managed_orders_settings.tp_types["tp_based_on_p_title"]:
            take_profit_part = f"take profit in %: {managed_order_data.profit_in_p} \n" \
                               f"take profit @: {managed_order_data.profit_in_d} \n"
        position_size_part = ""
        if managed_orders_settings.position_size_type == managed_orders_settings.position_size_types["based_on_p"]:
            # get up-to-date open risk
            managed_order_data.entry_price = managed_order_data.entry_price or managed_order_data.expected_entry_price
            old_open_risk = round(managed_order_data.current_open_risk * managed_order_data.entry_price, 3)
            new_open_risk = round(await position_sizing.get_current_open_risk(ctx, managed_order_data.market_fee,
                                                                              managed_order_data.entry_fees)
                                  * managed_order_data.entry_price, 3)
            ref_market = symbol_util.parse_symbol(ctx.symbol).quote
            position_size_part = f"position size: {managed_order_data.exit_amount} \n" \
                                 f"position size {ref_market}:" \
                                 f" {round(managed_order_data.exit_amount * managed_order_data.entry_price, 3)} \n" \
                                 f"\n" \
                                 f"risk details before trade opened: \n" \
                                 f" open risk: {ref_market} {old_open_risk} \n" \
                                 f" max position size: {managed_order_data.max_position_size} \n" \
                                 f" available exchange balance: {managed_order_data.max_buying_power} \n" \
                                 f"\n" \
                                 f"risk details after trade opened: \n" \
                                 f" open risk: {ref_market} {new_open_risk}"

        alert_content = entry_part + stop_loss_part + take_profit_part + position_size_part
        await alert_notifications.send_alert(alert_title, alert_content)
