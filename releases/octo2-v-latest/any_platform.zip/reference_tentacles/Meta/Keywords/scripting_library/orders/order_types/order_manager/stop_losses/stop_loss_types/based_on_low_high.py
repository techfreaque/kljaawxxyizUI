import tentacles.Meta.Keywords.scripting_library.data.reading.exchange_public_data as exchange_public_data
import tentacles.Meta.Keywords.scripting_library.settings.script_settings as script_settings
import octobot_trading.enums as trading_enums
import tentacles.Meta.Keywords.scripting_library.orders.order_types.order_manager. \
    stop_losses.stop_loss_handling as stop_loss_handling


async def get_stop_loss_based_on_low_high(ctx, managed_orders_settings, trading_side, current_price_val):
    script_settings.set_minimum_candles(ctx, managed_orders_settings.sl_low_high_lookback)
    if trading_side == trading_enums.PositionSide.LONG.value:
        lows = await exchange_public_data.Low(ctx, limit=int(managed_orders_settings.sl_low_high_lookback))
        sl_price = min(lows) * (1 - (managed_orders_settings.sl_low_high_buffer / 100))
        return stop_loss_handling.trim_sl_long_price(sl_price, current_price_val, managed_orders_settings.sl_max_p,
                                                     managed_orders_settings.sl_min_p)

    elif trading_side == trading_enums.PositionSide.SHORT.value:
        highs = await exchange_public_data.High(ctx, limit=int(managed_orders_settings.sl_low_high_lookback))
        sl_price = max(highs) * (1 + (managed_orders_settings.sl_low_high_buffer / 100))
        return stop_loss_handling.trim_sl_short_price(sl_price, current_price_val, managed_orders_settings.sl_max_p,
                                                      managed_orders_settings.sl_min_p)
    else:
        raise RuntimeError('Side needs to be "long" or "short" for your managed order')
