import json as json
import flask

import tentacles.Services.Interfaces.web_interface.login as login
import tentacles.Services.Interfaces.web_interface.models as models
import tentacles.Services.Interfaces.web_interface_strategy_designer_plugin.models as local_models
import tentacles.Services.Interfaces.web_interface.util as util
import tentacles.Services.Interfaces.web_interface.errors as errors
import tentacles.Services.Interfaces.web_interface as web_interface
import octobot_commons.logging as commons_logging
import octobot_commons.enums as commons_enums
import octobot_commons.constants as commons_constants
import octobot_commons.symbols.symbol_util as symbol_util
import octobot_commons
from tentacles.Services.Interfaces.octo_ui2.models.octo_ui2 import dev_mode_is_on, import_cross_origin_if_enabled


def register_strategy_design_routes(plugin):
    @plugin.blueprint.route("/strategy_design")
    @login.login_required_when_activated
    def strategy_design():
        is_starting = False
        config_candles_count = 0
        trading_mode = trading_mode_name = activated_strategy_name = exchange_name = exchange_id = None
        symbols = traded_time_frames = enabled_time_frames = activated_evaluators = []
        try:
            trading_mode = models.get_config_activated_trading_mode()
            trading_mode_name = trading_mode.get_name()
            exchange_manager, exchange_name, exchange_id = models.get_first_exchange_data()
            symbols = models.get_enabled_trading_pairs()
            activated_evaluators = models.get_config_activated_evaluators()
            strategies = models.get_config_activated_strategies()
            if strategies:
                activated_strategy_name = strategies[0].get_name()
                enabled_time_frames = models.get_strategy_required_time_frames(strategies[0])
            traded_time_frames = [tf.value for tf in models.get_traded_time_frames(exchange_manager)]
            config_candles_count = models.get_config_required_candles_count(exchange_manager)
        except KeyError:
            is_starting = True
        return flask.render_template(
            "strategy_design.html",
            is_starting=is_starting,
            trading_mode_name=trading_mode_name,
            tentacle_class=trading_mode,
            exchange_id=exchange_id,
            exchange_name=exchange_name,
            symbols=sorted([symbol_util.convert_symbol(s, octobot_commons.MARKET_SEPARATOR, "|") for s in symbols]),
            time_frames=traded_time_frames,
            enabled_time_frames=[tf.value for tf in enabled_time_frames],
            exchange_time_frames=[tf.value for tf in commons_enums.TimeFrames],
            activated_evaluators=activated_evaluators,
            activated_strategy_name=activated_strategy_name,
            config_candles_count=config_candles_count,
            data_files=models.get_data_files_with_description(),
        )

    @plugin.blueprint.route("/plotted_data")
    @login.login_required_when_activated
    def plotted_data():
        try:
            exchange_id = flask.request.args.get('exchange_id')
            symbol = flask.request.args.get('symbol')
            time_frame = flask.request.args.get('time_frame')
            trading_mode = models.get_config_activated_trading_mode()
            live_id = int(flask.request.args.get('bot_current_live_id', commons_constants.DEFAULT_CURRENT_LIVE_ID))
            return util.get_rest_reply(local_models.get_plotted_data(
                trading_mode=trading_mode, symbol=symbol_util.convert_symbol(symbol, "|"),
                time_frame=time_frame, exchange_id=exchange_id, backtesting_id=None,
                live_id=live_id, optimizer_id=None, campaign_name=None), 200)
        except Exception as e:
            commons_logging.get_logger("plotted_data").exception(e)
            return util.get_rest_reply(str(e), 500)

    @plugin.blueprint.route("/backtesting_main_plotted_data")
    @login.login_required_when_activated
    def backtesting_main_plotted_data():
        try:
            exchange_id = flask.request.args.get('exchange_id')
            symbol = flask.request.args.get('symbol')
            time_frame = flask.request.args.get('time_frame')
            run_id = flask.request.args.get('run_id')
            optimizer_id = int(flask.request.args.get('optimizer_id', 0)) or None
            optimization_campaign_name = flask.request.args.get('campaign_name', None)
            trading_mode = models.get_config_activated_trading_mode()
            return util.get_rest_reply(
                local_models.get_plotted_data(
                    trading_mode=trading_mode, symbol=symbol_util.convert_symbol(symbol, "|"),
                    time_frame=time_frame, exchange_id=exchange_id, backtesting_id=run_id,
                    optimizer_id=optimizer_id, campaign_name=optimization_campaign_name), 200)
        except errors.MissingExchangeId:
            return util.get_rest_reply(errors.MissingExchangeId.EXPLANATION, 500)
        except Exception as e:
            commons_logging.get_logger("plotted_data").exception(e)
            return util.get_rest_reply(str(e), 500)

    @plugin.blueprint.route("/backtesting_run_plotted_data", methods=["POST"])
    @login.login_required_when_activated
    def backtesting_run_plotted_data():
        try:
            request_data = flask.request.get_json()
            trading_mode = models.get_config_activated_trading_mode()
            symbol = symbol_util.convert_symbol(request_data["symbol"], "|")
            optimizer_id = int(request_data.get('optimizer_id', 0)) or None
            optimization_campaign = request_data.get('campaign_name', None)
            backtesting_analysis_settings = request_data.get('backtesting_analysis_settings', {})
            return util.get_rest_reply(
                local_models.get_backtesting_run_plotted_data(
                    trading_mode, request_data["exchange"], symbol,
                    request_data["id"], optimizer_id, optimization_campaign, backtesting_analysis_settings),
                200
            )
        except Exception as e:
            commons_logging.get_logger("backtesting_run_plotted_data").exception(e)
            return util.get_rest_reply(str(e), 500)

    @plugin.blueprint.route("/update_plot_script", methods=["POST"])
    @login.login_required_when_activated
    def update_plot_script():
        try:
            return util.get_rest_reply(models.reload_scripts(), 200)
        except Exception as e:
            commons_logging.get_logger("update_plot_script").exception(e)
            return util.get_rest_reply(str(e), 500)

    route = '/run_data'
    methods = ["GET", "POST"]
    if cross_origin := import_cross_origin_if_enabled():
        if dev_mode_is_on():
            @web_interface.server_instance.route(route, methods=methods)
            @cross_origin(origins="*")
            def run_data():
                return _run_data()
        else:
            @web_interface.server_instance.route(route, methods=methods)
            @cross_origin(origins="*")
            @login.login_required_when_activated
            def run_data():
                return _run_data()
    else:
        @web_interface.server_instance.route(route, methods=methods)
        @login.login_required_when_activated
        def run_data():
            return _run_data()

    @plugin.blueprint.route("/run_data", methods=["GET", "POST"])
    @cross_origin(origins="*")
    @login.login_required_when_activated
    def _run_data():
        try:
            if flask.request.method == 'GET':
                trading_mode = models.get_config_activated_trading_mode()
                runs_to_load_settings = json.loads(next(iter(flask.request.args))) if flask.request.args else {}
                return util.get_rest_reply(local_models.get_run_data(runs_to_load_settings, trading_mode), 200)
            if flask.request.method == 'POST':
                action = flask.request.args.get('action')
                if action == "delete":
                    trading_mode = models.get_config_activated_trading_mode()
                    request_data = flask.request.get_json()
                    runs = request_data.get('runs', [])
                    return util.get_rest_reply(local_models.delete_run_data(trading_mode, runs), 200)
        except Exception as e:
            commons_logging.get_logger("run_data").exception(e)
            return util.get_rest_reply(str(e), 500)

    @plugin.blueprint.route("/live_run_data", methods=["GET", "POST"])
    @login.login_required_when_activated
    def live_run_data():
        try:
            if flask.request.method == 'GET':
                trading_mode = models.get_config_activated_trading_mode()
                return util.get_rest_reply(local_models.get_live_run_data(trading_mode), 200)
            if flask.request.method == 'POST':
                action = flask.request.args.get('action')
                if action == "delete":
                    trading_mode = models.get_config_activated_trading_mode()
                    request_data = flask.request.get_json()
                    runs = request_data.get('runs', [])
                    return util.get_rest_reply(local_models.delete_run_data(trading_mode, runs), 200)
        except Exception as e:
            commons_logging.get_logger("live_run_data").exception(e)
            return util.get_rest_reply(str(e), 500)

    @plugin.blueprint.route("/strategy_design_config", methods=["GET", "POST"])
    @cross_origin(origins="*")
    @login.login_required_when_activated
    def strategy_design_config():
        if flask.request.method == 'POST':
            try:
                request_data = flask.request.get_json()
                return util.get_rest_reply(flask.jsonify(
                    local_models.save_strategy_design_config(request_data)
                ))
            except Exception as e:
                commons_logging.get_logger("strategy_design_config").exception(e)
                return util.get_rest_reply(str(e), 500)
        else:
            return local_models.get_strategy_design_config()

    @plugin.blueprint.route("/strategy_design_start_optimizer<action>", methods=["POST"])
    @login.login_required_when_activated
    @cross_origin(origins="*")
    def strategy_design_start_optimizer(action):
        try:
            trading_mode = models.get_config_activated_trading_mode()
            request_data = flask.request.get_json()
            success = False
            message = f"Unknown action: {action}"
            exchange_id = request_data.get("exchange_id", None)
            randomly_chose_runs = request_data.get("randomly_chose_runs", False)
            data_source = request_data.get("data_source")
            exchange_type = request_data.get("exchange_type", None)
            start_timestamp = request_data.get("start_timestamp", None)
            end_timestamp = request_data.get("end_timestamp", None)
            required_idle_cores = int(request_data.get("idle_cores", 0))
            notify_when_complete = request_data.get("notify_when_complete", False)
            if action == "start":
                # starting an optimizer means emptying the queue
                success, message = local_models.start_strategy_design_optimizer(
                    trading_mode, None, exchange_id, randomly_chose_runs, data_source,
                    start_timestamp=start_timestamp,
                    end_timestamp=end_timestamp,
                    required_idle_cores=required_idle_cores,
                    exchange_type=exchange_type,
                    notify_when_complete=notify_when_complete,
                    collector_start_callback=web_interface.send_data_collector_status,
                    start_callback=web_interface.send_strategy_optimizer_status)
            return util.get_rest_reply(flask.jsonify(message), 200 if success else 500)
        except errors.MissingExchangeId:
            return util.get_rest_reply(errors.MissingExchangeId.EXPLANATION, 500)
        except Exception as e:
            commons_logging.get_logger("strategy_design_start_optimizer").exception(e)
            return util.get_rest_reply(str(e), 500)

    @plugin.blueprint.route("/strategy_design_optimizer_queue<action>", methods=["GET", "POST"])
    @login.login_required_when_activated
    @cross_origin(origins="*")
    def strategy_design_optimizer_queue(action):
        trading_mode = models.get_config_activated_trading_mode()
        if flask.request.method == 'POST':
            try:
                request_data = flask.request.get_json()
                if action == "add":
                    exchange_id = request_data.get("exchange_id", None)
                    optimizer_id = request_data.get("optimizer_id", None)
                    optimizer_id = optimizer_id if optimizer_id is None else int(optimizer_id)
                    config = request_data.get("config", None)
                    queue_size = int(request_data.get("queue_size", 10000))
                    message = local_models.generate_and_save_optimizer_run(
                        trading_mode, config, exchange_id, optimizer_id, queue_size
                    )
                    return util.get_rest_reply(flask.jsonify(message), 200)
                if action == "update":
                    local_models.update_strategy_optimizer_queue(trading_mode, request_data["queue"])
                    return util.get_rest_reply(local_models.get_strategy_optimizer_queue(trading_mode), 200)
            except errors.MissingExchangeId:
                return util.get_rest_reply(errors.MissingExchangeId.EXPLANATION, 500)
            except Exception as e:
                commons_logging.get_logger("strategy_design_optimizer_queue").exception(e)
                data = local_models.get_strategy_optimizer_queue(trading_mode)
                data["message"] = str(e)
                return util.get_rest_reply(data, 500)
        else:
            try:
                return util.get_rest_reply(local_models.get_strategy_optimizer_queue(trading_mode), 200)
            except Exception as e:
                commons_logging.get_logger("strategy_design_optimizer_queue").exception(e)
                return util.get_rest_reply(str(e), 500)

    @plugin.blueprint.route("/cache<action>", methods=["POST"])
    @login.login_required_when_activated
    def cache(action):
        message = f"unknown action: {action}"
        try:
            if action == "clear_simulated_orders_cache":
                return util.get_rest_reply(local_models.clear_simulated_orders_cache(), 200)
            if action == "clear_simulated_trades_cache":
                return util.get_rest_reply(local_models.clear_simulated_trades_cache(), 200)
            if action == "clear_plotted_cache":
                return util.get_rest_reply(local_models.clear_plotted_cache(), 200)
            elif action == "clear_all_cache":
                return util.get_rest_reply(local_models.clear_all_cache(), 200)
        except Exception as e:
            message = f"Error when managing cache: {e}"
            commons_logging.get_logger("strategy_design_optimizer_queue").exception(e)
        return util.get_rest_reply(message, 500)
