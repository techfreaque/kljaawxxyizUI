from tentacles.Services.Interfaces.web_interface_strategy_designer_plugin.controllers import strategy_designs

from tentacles.Services.Interfaces.web_interface_strategy_designer_plugin.controllers.strategy_designs import (
    register_strategy_design_routes,
)

__all__ = [
    "register_strategy_design_routes",
]
