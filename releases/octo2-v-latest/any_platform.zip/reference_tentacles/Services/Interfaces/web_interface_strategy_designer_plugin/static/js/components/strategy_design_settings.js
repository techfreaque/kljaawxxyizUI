function displayStrategyDesignSettings(){
    const updateDisplaySettings = (displayedElements) => {
        if(typeof displayedElements !== "undefined"){
            const displayedElementsRoot = $("#strategy-design-displayed-elements-settings");
            displayedElements.forEach(element => {
                displayedElementsRoot.find(`[data-config-element='${element}']`).prop("checked", true);
            })
        }
    }

    const updateGraphsSettings = (graphSettings) => {
        if(typeof graphSettings !== "undefined") {
            updateInputIfValue("max-candles-before-line-display-input", graphSettings,
                "max_candles_before_line_display", "number")
            updateInputIfValue("max-candles-line-source-input", graphSettings,
                "max_candles_line_sources", "list")
            updateInputIfValue("unified-graph-tooltip-input", graphSettings,
                "display_unified_tooltip", "bool")
            updateInputIfValue("use-log-scale-input", graphSettings,
                "display_use_log_scale", "bool")
        };
    }

    const initDisplay = () => {
        $("#max-candles-line-source-input").select2({
            width: '50%', // need to override the changed default
        });
        $('#display-settings-modal').on('hide.bs.modal', () => {
          updateStrategyDesignSettings();
        })
    }

    const settings = getStrategyDesignerConfig(DISPLAY_SETTINGS_KEY);
    if(typeof settings !== "undefined"){
        updateDisplaySettings(settings[DISPLAYED_ELEMENTS_KEY]);
        updateGraphsSettings(settings[GRAPHS_KEY]);
    }
    initDisplay();
}

function updateStrategyDesignSettings(){
    const getDisplaySettings = () => {
        const displayedElements = [];
        $("#strategy-design-displayed-elements-settings").find("[data-config-element]").each((_, jsElement) => {
            const element = $(jsElement);
            if(element.is(':checked')){
                displayedElements.push(element.data("config-element"));
            }
        })
        return displayedElements;
    }

    const getGraphsSettings = () => {
        const elementsSettings = {};
        $("#strategy-design-graphs-settings").find("[data-config-element]").each((_, jsElement) => {
            const element = $(jsElement);
            elementsSettings[element.data("config-element")] = element.attr("type") === "checkbox" ?
                element.is(':checked'): element.val();
        })
        return elementsSettings;
    }

    const updatedConfig = {};
    updatedConfig[DISPLAYED_ELEMENTS_KEY] = getDisplaySettings();
    updatedConfig[GRAPHS_KEY] = getGraphsSettings();
    if(JSON.stringify(updatedConfig) !== JSON.stringify(getStrategyDesignerConfig(DISPLAY_SETTINGS_KEY))){
        updateStrategyDesignerConfig(DISPLAY_SETTINGS_KEY, updatedConfig).then(
            () => create_alert(
                "success",
                "Settings saved",
                "New settings will be applied in next displays."
            )
        );
    }
}
