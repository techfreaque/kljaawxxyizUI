const resizeObserver = new ResizeObserver(entries => {
    for (let entry of entries) {
        Plotly.Plots.resize(entry.target);
    }
});

const CANDLES_PLOT_SOURCES = ["open", "high", "low", "close"];
const ALL_PLOT_SOURCES = ["y", "z", "volume"].concat(CANDLES_PLOT_SOURCES);

function getPlotlyConfig(){
    return {
        scrollZoom: true,
        modeBarButtonsToRemove: ["select2d", "lasso2d", "toggleSpikelines"],
        responsive: true,
        showEditInChartStudio: false,
        displaylogo: false // no logo to avoid 'rel="noopener noreferrer"' security issue (see https://webhint.io/docs/user-guide/hints/hint-disown-opener/)
    };
}

function _getChartedElements(chartDetails, yAxis, xAxis, backtesting_id, optimizer_id, campaign_name, chartIdentifier, plotOnlyY){
    const chartedElements = {
      x: chartDetails.x,
      mode: chartDetails.mode,
      type: chartDetails.kind,
      text: chartDetails.text,
      name: `${chartDetails.title} (${chartIdentifier})`,
      user_title: chartDetails.title,
      backtesting_id: backtesting_id,
      optimizer_id: optimizer_id,
      campaign_name: campaign_name,
    }
    chartedElements.line = {
        shape: chartDetails.line_shape
    }
    const markerAttributes = ["color", "size", "opacity", "line", "symbol"];
    chartedElements.marker = {};
    markerAttributes.forEach(function (attribute){
        if (chartDetails[attribute] !== null){
            chartedElements.marker[attribute] = chartDetails[attribute];
        }
    });
    if(plotOnlyY){
        chartedElements.y = chartDetails.y;
    }else{
        ALL_PLOT_SOURCES.forEach(function (element){
            if(chartDetails[element] !== null){
                chartedElements[element] = chartDetails[element]
            }
        })
    }
    if(xAxis > 1){
        chartedElements.xaxis= `x${xAxis}`
    }
    chartedElements.yaxis = `y${yAxis}`
    return chartedElements;
}

function _createOrAdaptChartedElements(chartDetails, yAxis, xAxis, backtesting_id, optimizer_id, campaign_name, chartIdentifier){
    const createdChartedElements = [];
    if(chartDetails.x === null){
        return createdChartedElements;
    }
    if(chartDetails.kind === "candlestick" && displayCandlesAsLines(chartDetails.x.length)){
        chartDetails.kind = "scattergl";
        chartDetails.mode = "line";
        const originTitle = chartDetails.title;
        const displayedCandlesSources = getDisplayedCandlesLinesSources();
        CANDLES_PLOT_SOURCES.forEach(plotSource => {
            if(displayedCandlesSources.indexOf(plotSource) !== -1){
                chartDetails.y = chartDetails[plotSource];
                chartDetails.title = `${originTitle} [${plotSource}]`
                createdChartedElements.push(
                    _getChartedElements(chartDetails, yAxis, xAxis, backtesting_id, optimizer_id, campaign_name, chartIdentifier, true)
                );
            }
        })
    }else{
        createdChartedElements.push(
            _getChartedElements(chartDetails, yAxis, xAxis, backtesting_id, optimizer_id, campaign_name, chartIdentifier, false)
        );
    }
    return createdChartedElements;
}

function createChart(chartDetails, chartData, yAxis, xAxis, xaxis_list, yaxis_list, backtesting_id, optimizer_id, campaign_name, chartIdentifier){
    const xaxis = {
        gridcolor: "#2a2e39",
        color: "#b2b5be",
        autorange: true,
        rangeslider: {
            visible: false,
        },
        domain: [0.02, 0.98]
    };
    const yaxis = {
    };
    if(chartDetails.x_type !== null){
        xaxis.type = chartDetails.x_type;
    }
    if(xAxis > 1){
        xaxis.overlaying = "x"
    }
    if(chartDetails.y_type !== null && useLogScale() === true){
        yaxis.type = chartDetails.y_type;
    }
    _createOrAdaptChartedElements(chartDetails, yAxis, xAxis, backtesting_id, optimizer_id, campaign_name, chartIdentifier).forEach(element => {
        chartData.push(element);
    })
    const layout = {
        autosize: true,
        margin: {l: 50, r: 50, b: 30, t: 0, pad: 0},
        showlegend: true,
        legend: {x: 0.01, xanchor: 'left', y: 0.99, yanchor:"top"},
        paper_bgcolor: 'rgba(0,0,0,0)',
        plot_bgcolor: 'rgba(0,0,0,0)',
        dragmode: "pan",
        font: {
            color: "#b2b5be"
        },
        yaxis: {
            gridcolor: "#2a2e39",
            color: "#b2b5be",
            fixedrange: false,
            anchor: "free",
            overlaying: "y",
            side: 'left',
            position: 0
        },
        yaxis2: {
            gridcolor: "#2a2e39",
            color: "#b2b5be",
            fixedrange: false,
            anchor: "free",
            overlaying: "y",
            side: 'right',
            position: 1
        },
        yaxis3: {
            gridcolor: "#2a2e39",
            color: "#b2b5be",
            fixedrange: false,
            anchor: "free",
            overlaying: "y",
            side: 'right',
            position: 0.985
        },
        yaxis4: {
            gridcolor: "#2a2e39",
            color: "#b2b5be",
            fixedrange: false,
            anchor: "free",
            overlaying: "y",
            side: 'left',
            position: 0.015
        }
    };
    if(displayUnifiedTooltip()){
        layout.hovermode = "x unified";
        layout.hoverlabel = {
            bgcolor: "#131722",
            bordercolor: "#2a2e39"
        };
    } else {
        layout.hovermode = false;
    }

    const MAX_AXIS_INDEX = 4;
    yaxis_list.push(yaxis)
    yaxis_list.forEach(function (axis, i){
        if(i > 0 && i < MAX_AXIS_INDEX){
            layout[`yaxis${i + 1}`].type = axis.type;
        } else{
            layout["yaxis"].type = axis.type
        }
    });
    xaxis_list.push(xaxis)
    xaxis_list.forEach(function (axis, i){
        if(i > 0){
            layout[`xaxis${i + 1}`] = axis;
        }else{
            layout.xaxis = axis
        }
    });
    return layout
}

function _updateChart(data, replot, backtesting_id, optimizer_id, campaign_name,
                      added, backtestingTableName, chartIdentifier, afterPlot, hiddenXAxisIDs, backtestingPart) {
    const toRemoveTracesByDivID = {};
    const checkedDivIDsForClear = [];
    if (added) {
        data.data.sub_elements.forEach(function (sub_element) {
            if (sub_element.type == "chart") {
                const divID = sub_element.name;
                if(!isAreaDisplayed(divID, backtestingTableName)){
                    return;
                }
                const chartData = [];
                const xaxis_list = [];
                const yaxis_list = [];
                if (backtestingPart && sub_element.name !== "backtesting-run-overview") {
                    var yAxis = 1;
                } else {
                    var yAxis = 0;
                }
                sub_element.data.elements.forEach(function (chartDetails) {
                    if(_isChartAlreadyDisplayed(chartDetails.title, backtesting_id,
                        optimizer_id, campaign_name, checkedDivIDsForClear, divID)){
                        // already displayed, jump to next graph
                        return;
                    }

                    if (chartDetails.own_yaxis && yAxis < 4) {
                        yAxis += 1;
                    } else if (yAxis === 0) {
                        yAxis = 1;
                    }
                    let xAxis = 1;
                    if (chartDetails.own_xaxis) {
                        xAxis += 1;
                    }
                    if (plotlyCreatedChartsIDs.indexOf(divID) !== -1) {
                        _createOrAdaptChartedElements(chartDetails, yAxis, xAxis, backtesting_id, optimizer_id, campaign_name, chartIdentifier).forEach(element => {
                            Plotly.addTraces(divID, element);
                        })
                    } else {
                        const layout = createChart(chartDetails, chartData, yAxis, xAxis, xaxis_list, yaxis_list,
                            backtesting_id, optimizer_id, campaign_name, chartIdentifier);
                        if (hiddenXAxisIDs.indexOf(divID) !== -1) {
                            layout.xaxis.visible = false;
                        }
                        if (replot) {
                            Plotly.react(divID, chartData, layout, getPlotlyConfig()).then(afterPlot);
                        } else {
                            Plotly.newPlot(divID, chartData, layout, getPlotlyConfig()).then(afterPlot);
                        }
                    }
                });
                if(plotlyCreatedChartsIDs.indexOf(divID) === -1){
                    plotlyCreatedChartsIDs.push(divID);
                }
            }
        });
    } else  {
        plotlyCreatedChartsIDs.forEach(divID => {
            if(!isAreaDisplayed(divID, backtestingTableName)){
                return;
            }
            if(checkedDivIDsForClear.indexOf(divID) === -1) {
                toRemoveTracesByDivID[divID] = [];
                const selectedRunIdentifiers = getSelectedBacktestingRunIdentifiers(backtestingTableName)
                if(typeof document.getElementById(divID).data !== "undefined"){
                    document.getElementById(divID).data.forEach(function (data) {
                        if(data.backtesting_id != null && (
                                selectedRunIdentifiers.indexOf(mergeRunIdentifiers(data.backtesting_id,
                                    data.optimizer_id, data.campaign_name)) === -1 || (
                                    data.backtesting_id === backtesting_id &&
                                    data.optimizer_id === optimizer_id &&
                                    data.campaign_name === campaign_name
                                )
                            )
                        ){
                            // backtesting graphs are to be removed => not selected anymore
                            toRemoveTracesByDivID[divID].push(data);
                        }
                    })
                }
                checkedDivIDsForClear.push(divID);
            }
        });
    }
    Object.keys(toRemoveTracesByDivID).forEach(function (divID){
        toRemoveTracesByDivID[divID].forEach(function (data){
            Plotly.deleteTraces(divID, document.getElementById(divID).data.indexOf(data));
        });
    })
}

function _isChartAlreadyDisplayed(title, backtesting_id, optimizer_id, campaign_name, checkedDivIDsForClear, divID){
    let isAlreadyDisplayed = false;
    if(backtesting_id !== null && checkedDivIDsForClear.indexOf(divID) === -1){
        const graphDiv = document.getElementById(divID);
        if(typeof graphDiv.data !== "undefined"){
            graphDiv.data.forEach(function (datum){
                if(datum.backtesting_id !== null){
                    if(datum.backtesting_id === backtesting_id &&
                        datum.optimizer_id === optimizer_id &&
                        datum.campaign_name === campaign_name &&
                        datum.user_title === title){
                        isAlreadyDisplayed = true;
                    }
                }
            })
        }
    }
    return isAlreadyDisplayed;
}

function _updateBacktestingChart(data, replot, backtesting_id, optimizer_id, campaign_name,
                                 added, backtestingTableName, chartIdentifier, backtestingPart) {
    _updateChart(data, replot, backtesting_id, optimizer_id, campaign_name,
        added, backtestingTableName, chartIdentifier, afterGraphPlot, [], backtestingPart);
}

function afterGraphPlot(target){
    const plottedDivID = $(target).attr("id");
    removeExplicitSize(target);
    resizeObserver.observe(target);
    if (plottedDivID !== "main-chart") {
        const mainLayout = document.getElementById("main-chart").layout;
        if(typeof mainLayout === "undefined"){
            return;
        }
        if(typeof document.getElementById("sub-chart").data !== "undefined"
            && typeof document.getElementById("main-chart").data !== "undefined") {
            Plotly.relayout("sub-chart", {
                xaxis: {
                    range: mainLayout.xaxis.range.map((x) => x),
                    type: mainLayout.xaxis.type,
                    domain: mainLayout.xaxis.domain,
                    visible: false,
                }
            });
        }
    }
}

function _hideSubChartWhenEmpty(data, added){
    let hasSubChart = _getEnabledCharts().length > 1;
    data.data.sub_elements.forEach(function (sub_element) {
        if (sub_element.type == "chart") {
            if(sub_element.name === "sub-chart" && added){
                hasSubChart = true;
            }
        }
    });
   if(!hasSubChart){
       $("#main-chart-outer").css("height", "100%").css("max-height", "100%");
       updateWindowSizes()
   }else if($("#sub-chart").css("height") === "0px"){
       $("#main-chart-outer").css("height", "65%").css("max-height", "calc(100% - 25px)");
       updateWindowSizes()
   }
}

function _updateMainCharts(data, replot, backtesting_id, optimizer_id, campaign_name,
                           added, backtestingTableName, chartIdentifier) {
    const hiddenXAxisChartIDs = ["sub-chart"];
    _updateChart(data, replot, backtesting_id, optimizer_id, campaign_name,
        added, backtestingTableName, chartIdentifier, afterGraphPlot, hiddenXAxisChartIDs, false);
    _hideSubChartWhenEmpty(data, added);
    _updateChartLayout();
    if(!replot){
        if(typeof document.getElementById("sub-chart").data !== "undefined"
            && typeof document.getElementById("main-chart").data !== "undefined"){
            document.getElementById("main-chart").on("plotly_relayout", function(eventdata) {
                if(typeof eventdata["xaxis.range[0]"] !== "undefined"){
                    const subChartLayout = document.getElementById("sub-chart").layout;
                    subChartLayout.xaxis.range[0]=eventdata["xaxis.range[0]"]
                    subChartLayout.xaxis.range[1]=eventdata["xaxis.range[1]"]
                    Plotly.relayout("sub-chart", subChartLayout);
                }
            });
            document.getElementById("sub-chart").on("plotly_relayout", function (eventdata) {
                if (typeof eventdata["xaxis.range[0]"] !== "undefined") {
                    const mainLayout = document.getElementById("main-chart").layout;
                    mainLayout.xaxis.range[0] = eventdata["xaxis.range[0]"]
                    mainLayout.xaxis.range[1] = eventdata["xaxis.range[1]"]
                    Plotly.relayout("main-chart", mainLayout).then(function () {
                        mainLayout.xaxis.autorange = false;
                    });
                }
            });
        }
    }
}

function _hideNotShownUserInputs(tentacle, schema, is_hidden){
    let hiddenColumns = [];
    Object.keys(schema.properties).forEach((key) => {
        const value = schema.properties[key];
        if(typeof value.properties === "object"){
            hiddenColumns = hiddenColumns.concat(_hideNotShownUserInputs(key, value, false));
        }else{
            if(is_hidden || !value.options.in_summary){
                hiddenColumns.push(_userInputKey(key, tentacle).replaceAll("_", " "));
            }
        }
    })
    return hiddenColumns;
}

function _handleHiddenUserInputs(elements){
    hiddenBacktestingMetadataColumns = [];
    elements.data.elements.forEach(function (inputDetails) {
        hiddenBacktestingMetadataColumns = hiddenBacktestingMetadataColumns.concat(
            _hideNotShownUserInputs(inputDetails.tentacle, inputDetails.schema, inputDetails.is_hidden)
        );
    });
}

function _getEvaluatorInputsTabFromTemplate(configTitle, configId){
    const tabTemplateSuffix = "-evaluator-inputs-tab"
    const tabTemplate = $(`#XYZ${tabTemplateSuffix}-template`);
    let tab = tabTemplate.html().replace(new RegExp("XYZT","g"), configTitle);
    tab = tab.replace(new RegExp("XYZ","g"), configId);
    // remove any previous tab before adding the new one
    $(`#${configId}${tabTemplateSuffix}-inner`).remove();
    tabTemplate.parent().append(tab);
    const tabContentTemplate = $(`#XYZ${tabTemplateSuffix}-content-template`);
    let tabContent = tabContentTemplate.html().replace(new RegExp("XYZT","g"), configTitle);
    tabContent = tabContent.replace(new RegExp("XYZ","g"), configId);
    // remove any previous tab content before adding the new one
    $(`#${configId}${tabTemplateSuffix}-content-inner`).remove();
    tabContentTemplate.parent().append(tabContent);
    return `_${configId}-evaluator-inputs-tab-content-inner`;
}

function _addGridDisplayOptions(schema){
    // display user inputs as grid
    schema.format = "grid"
    if(typeof schema.options === "undefined"){
        schema.options = {};
    }
    schema.options.grid_columns = 4;
}

function updateInputSettingsDisplay(settingsRoot){
    settingsRoot.find("select[multiple=\"multiple\"]").select2({
        width: 'resolve', // need to override the changed default
        closeOnSelect: false,
        placeholder: "Select values to use"
    });
}

function _createTentacleConfigTab(masterTab, tabIdentifier, divId, configName, config, schema, editorKey){
    masterTab.empty();
    masterTab.append(`<div id="${tabIdentifier}-${divId}"></div>`);
    const element = document.getElementById(`${tabIdentifier}-${divId}`)
    if(element === null){
        window.console&&console.error(`Missing evaluator configuration tab "${tabIdentifier}-${divId}"`);
        return;
    }
    _addGridDisplayOptions(schema);
    Object.values(schema.properties).forEach(property =>  _addGridDisplayOptions(property));
    editors[editorKey][configName] = new JSONEditor(
        element,
        {
            schema: schema,
            startval: config,
            no_additional_properties: true,
            prompt_before_delete: true,
            disable_array_reorder: true,
            disable_collapse: false,
            disable_properties: true
        }
    );
    updateInputSettingsDisplay(masterTab);
}

function _createSplitNestedEvaluatorConfig(configName, config, schema){
    const tabContentId = _getEvaluatorInputsTabFromTemplate(schema.title,
        configName.replaceAll(new RegExp(" ","g"), "-"))
    const divId = schema.title.replaceAll(new RegExp(" ","g"), "-");
    const masterTab = $(document.getElementById(tabContentId));
    _createTentacleConfigTab(masterTab, configName, divId, configName, config, schema, "nestedTradingModeConfig");
}

function _displayNestedEvaluatorInputs(inputDetails){
    // clear any existing nested config as it will be re-created
    $('[data-is-nested-tentacle-config="true"]').each((i, jsElement) => {
        const element = $(jsElement);
        if(element.attr("id").indexOf("XYZ") === -1){
            // remove non-template elements
            element.remove();
        }
    })
    // create new config elements
    const toRemoveKeys = [];
    Object.keys(inputDetails.config).forEach(key => {
        const value = inputDetails.config[key];
        if(value instanceof Object && !(value instanceof Array)){
            _createSplitNestedEvaluatorConfig(key, value, inputDetails.schema.properties[key]);
            toRemoveKeys.push(key);
        }
    })
    toRemoveKeys.forEach(key => {
        delete inputDetails.config[key];
        delete inputDetails.schema.properties[key];
    })
}

function _displayInputsForTentacle(elements, mainTab, tentacleType){
    elements.data.elements.forEach(function (inputDetails) {
        const editorKey = tentacleType === "trading_mode" ? "tradingMode": "tentacles";
        if(inputDetails.tentacle_type === tentacleType && !inputDetails.is_hidden){
            try{
                // use a local deep copy of inputDetails to be able to edit it (split nested evaluator configurations)
                const localInputDetails = JSON.parse(JSON.stringify(inputDetails));
                const tabIdentifier = mainTab == null ? localInputDetails.tentacle : mainTab
                const divId = localInputDetails.title.replaceAll(" ", "-");
                if(tentacleType === "trading_mode"){
                    // only split nested evaluator configurations in trading mode configurations
                    _displayNestedEvaluatorInputs(localInputDetails);
                }
                const masterTab = $(document.getElementById(`${tabIdentifier}-inputs`));
                _createTentacleConfigTab(masterTab, tabIdentifier, divId, localInputDetails.tentacle,
                    localInputDetails.config, localInputDetails.schema, editorKey);
            }catch (error){
                window.console&&console.error(error);
            }
        }
    });
}

function _findNestedUserInputPathInInputs(customInput, elements){
    let bestMatchingInputDetails = null;
    let bestMatchingPath = [];
    let toFindEvaluator = null;
    let firstEvaluator = null;
    if(customInput.tentacleType === "evaluator"){
        toFindEvaluator = customInput.path[0];
    }
    elements.data.elements.forEach((inputDetails, index) => {
        if(inputDetails.is_hidden){
            return;
        }
        if(inputDetails.tentacle_type === "evaluator"){
            if(firstEvaluator === null){
                firstEvaluator = inputDetails;
            }
            if(toFindEvaluator !== null){
                if(inputDetails.tentacle !== toFindEvaluator){
                    return;
                }
            }
        }
        let localMatchingPath = [];
        let currentInput = inputDetails.config;
        customInput.path.forEach((toFindKey, index) => {
            if(inputDetails.tentacle_type === "evaluator" && index === 0){
                // for evaluators, the 1st element of the path is the evaluator name which is checked already
                return;
            }
            if(typeof currentInput[toFindKey] === "undefined"){
                return;
            }else{
                localMatchingPath.push(toFindKey)
            }
            currentInput = currentInput[toFindKey];
        });
        // use a score based matching system as paths might not exist and we need to figure out if we can bind to
        // an existing one before creating a new one
        if(bestMatchingPath.length <= localMatchingPath.length){
            bestMatchingInputDetails = inputDetails
            bestMatchingPath = localMatchingPath;
        }
    });
    if(bestMatchingInputDetails === null && toFindEvaluator !== null) {
        bestMatchingInputDetails = firstEvaluator;
    }
    if(bestMatchingInputDetails !== null) {
        return {
            path: bestMatchingPath,
            inputDetails: bestMatchingInputDetails
        };
    }
    return null;
}

function _applyCustomPathUserInputs(elements){
    // note: not working:
    // - " " in custom path
    // - custom paths for strategy optimizer
    // - custom paths merger with existing evaluator config
    // - custom paths containing only "trading"
    const customPathUserInputs = [];
    elements.data.elements.forEach((inputDetails) => {
        if(inputDetails.is_hidden){
            return;
        }
        const toRemoveConfigKeys = [];
        // gather custom user inputs
        Object.keys(inputDetails.schema.properties).forEach((key) => {
            const property = inputDetails.schema.properties[key]
            if(property.options.custom_path !== null){
                const customPath = property.options.custom_path.split(CUSTOM_USER_INPUT_PATH_SEPARATOR);
                if(customPath.length < 1){
                    log("Error: at least 1 element is required is a custom user input path, path: ", customPath);
                    return;
                }
                const tentacleType = customPath[0];
                const originPath = [inputDetails.tentacle]
                customPath.splice(0, 1)
                customPathUserInputs.push({
                    tentacleType: tentacleType,
                    path: customPath,
                    originPath: originPath,
                    key: key,
                    config: inputDetails.config[key],
                    property: property,
                })
                toRemoveConfigKeys.push(key);
            }
        });
        // remove custom inputs from their original fields so that they don't appear there
        toRemoveConfigKeys.forEach(key => {
            delete inputDetails.config[key];
            delete inputDetails.schema.properties[key];
        })
    });
    // patch existing inputs with custom ones or create new groups
    customPathUserInputs.forEach((customInput) => {
        const bestMatchingInput = _findNestedUserInputPathInInputs(customInput, elements);
        if(bestMatchingInput === null){
            log("Error: no element matching required path for: ", customInput);
            return;
        }
        let currentInputConfig = bestMatchingInput.inputDetails.config;
        let currentInputSchema = bestMatchingInput.inputDetails.schema;
        customInput.path.forEach((toFindKey) => {
            if(typeof currentInputConfig[toFindKey] === "undefined"){
                currentInputConfig[toFindKey] = {};
            }
            if(typeof currentInputSchema.properties[toFindKey] === "undefined"){
                // default object schema
                currentInputSchema.properties[toFindKey] = {
                    type: "object",
                    title: toFindKey,
                    properties: {},
                    options: {collapsed: true}
                };
            }
            currentInputConfig = currentInputConfig[toFindKey];
            currentInputSchema = currentInputSchema.properties[toFindKey];
        });
        if(typeof currentInputConfig[customInput.key] !== "undefined"){
            log("Warning: overriding existing user input by: ", customInput);
        }
        currentInputConfig[customInput.key] = customInput.config;
        currentInputSchema.properties[customInput.key] = customInput.property;
    })
    return customPathUserInputs;
}

function _displayInputs(elements, replot, editors){
    // avoid working on original elements as they will be edited for custom user inputs
    const localElements = JSON.parse(JSON.stringify(elements));
    _handleHiddenUserInputs(localElements)
    editors.customPathUserInputs = _applyCustomPathUserInputs(localElements);
    _displayInputsForTentacle(localElements, "trading", "trading_mode")
    _displayInputsForTentacle(localElements, null, "evaluator")
}

function updateOptimizerQueueEditor(optimizerQueue, containerId, queueUpdateCallback){
    updateOptimizerQueueCount(optimizerQueue);
    createOptimizerQueueTables(optimizerQueue, containerId, queueUpdateCallback)
}

function _getEnabledCharts(){
    const charts = ["main-chart", "sub-chart"];
    const enabledCharts = [];
    charts.forEach(function (chart){
        const chartElement = document.getElementById(chart);
        if(typeof chartElement.data !== "undefined" && chartElement.data.length){
            enabledCharts.push(chart)
        }
    })
    return enabledCharts;
}

function _updateChartLayout(){
    const subElementCount = _getEnabledCharts().length;
    if(subElementCount <= 1){
        $("#main-chart-outer").resizable("option", "disabled", true );
    }else {
        $("#main-chart-outer").resizable("option", "disabled", false );
    }
    if(subElementCount <= 2){
        $("#main-chart-outer").addClass("max-width");
    }else {
        $("#main-chart-outer").removeClass("max-width");
    }
}

function _updateBacktestingValues(sub_element, replot, backtesting_id, optimizer_id, campaign_name){
    const parentDiv = $(document.getElementById(sub_element.name));
    divWithBacktestingValues.push(sub_element.name);
    if(!parentDiv.length || !isAreaDisplayed(sub_element.name, backtestingTableName)){
        return
    }
    const backtestingParentDivId = `${backtesting_id}-${optimizer_id}-${campaign_name}-part`;
    let backtestingRunParentDiv = $(document.getElementById(backtestingParentDivId));
    if(backtestingRunParentDiv.length){
        backtestingRunParentDiv.empty();
    } else {
        parentDiv.append(`<div id="${backtestingParentDivId}" class="backtesting-run-container"></div>`)
        backtestingRunParentDiv = $(document.getElementById(backtestingParentDivId));
    }
    _add_labelled_backtesting_values(sub_element, backtesting_id, optimizer_id, campaign_name,
        backtestingRunParentDiv, parentDiv)
}

function _clearBacktestingValues(backtesting_id, optimizer_id, campaign_name){
    divWithBacktestingValues.forEach(divID => {
        const backtestingParentDivId = `${backtesting_id}-${optimizer_id}-${campaign_name}-part`;
        $(document.getElementById(backtestingParentDivId)).remove();
    });
}

function _add_labelled_backtesting_values(sub_element, backtesting_id, optimizer_id, campaign_name,
                                          backtestingRunParentDiv, parentDiv){
        const optimizerStr = optimizer_id ? ` Optimizer ${optimizer_id}`: "";
        backtestingRunParentDiv.append(
            `<div class="backtesting-run-container-title text-center">
                <h4>Backtesting ${backtesting_id}${optimizerStr} Campaign ${campaign_name}</h4>
             </div>`
        );
        backtestingRunParentDiv.append(
            `<div data-role="values" class="backtesting-run-container-values container-fluid row"></div>`
        );
        const backtestingValuesGridDiv = backtestingRunParentDiv.find("[data-role='values']");
        backtestingValuesGridDiv.empty();
        sub_element.data.elements.forEach(function (element){
            if(element.html === null){
                backtestingValuesGridDiv.append(
                    `<div class="col-6 col-md-3 ${sub_element.data.elements.length > 4 ? 'col-xl-2' : ''} text-center">
                        <div class="backtesting-run-container-values-label">${element.title}</div>
                        <div class="backtesting-run-container-values-value">${element.value}</div>
                    </div>`
                );
            }else{
                backtestingValuesGridDiv.append(element.html);
            }
        });
}

function _updateTables(sub_element, replot, backtesting_id, optimizer_id, campaign_name, backtestingTableName){
    sub_element.data.elements.forEach(function (element){
        if(!isAreaDisplayed(sub_element.name, backtestingTableName)){
            return;
        }
        const toRemove = [];
        const tableName = element.title.replaceAll(" ", "-").replaceAll("*", "-");
        // remove potentially now unselected elements
        if(typeof w2ui[tableName] !== "undefined"){
            let hasThisBacktestingAlready = false;
            const selectedRunIds = getSelectedBacktestingRunIdentifiers(backtestingTableName);
            w2ui[tableName].records.forEach(function (record){
                if(selectedRunIds.indexOf(mergeRunIdentifiers(record.backtesting_id, record.optimizer_id, record["optimization campaign"])) === -1){
                    toRemove.push(record.recid)
                }
                if(record.backtesting_id === backtesting_id &&
                   record.optimizer_id == optimizer_id &&
                   record["optimization campaign"] === campaign_name){
                    hasThisBacktestingAlready = true;
                }
            })
            if(hasThisBacktestingAlready){
                return
            }
        }
        // add new elements
        element.columns.push(
            {
                "field": "backtesting_id",
                "label": "Backtesting id",
                "render": "float",
            },
            {
                "field": "optimizer_id",
                "label": "Optimizer id",
                "render": "float",
            },
            {
                "field": "optimization campaign",
                "label": "Optimization campaign",
                "render": "text",
            }
        )
        const columns = element.columns.map((col) => {
            return {
                field: col.field,
                text: col.label,
                size: `${1 / element.columns.length * 100}%`,
                sortable: true,
                attr: col.attr,
                render: col.render,
            }
        });
        let startIndex = 0;
        if(typeof w2ui[tableName] !== "undefined"){
            startIndex = w2ui[tableName].records.length;
        }
        const records = element.rows.map((row, index) => {
            row.backtesting_id = backtesting_id;
            row.optimizer_id = optimizer_id;
            row["optimization campaign"] = campaign_name;
            row.recid = startIndex + index;
            return row;
        });
        element.searches.push(
            {
                "field": "backtesting_id",
                "label": "Backtesting id",
                "type": "float",
            },
            {
                "field": "optimizer_id",
                "label": "Optimizer id",
                "type": "float",
            },
            {
                "field": "optimization campaign",
                "label": "Optimization campaign",
                "type": "text",
            }
        )
        const searches = element.searches.map((search) => {
            return {
                field: search.field,
                label: search.label,
                type: _getTableDataType(records, search, "text", null),
                options: search.options,
            }
        });
        const chartDivID = `${sub_element.name}-${element.title}`;
        if(typeof w2ui[tableName] === "undefined"){
            const parentDiv = $(document.getElementById(sub_element.name));
            parentDiv.append(`<div id="${chartDivID}" style="width: 100%; height: 400px;"></div>`);
        }
        const tableTitle = element.title.replaceAll("_", " ");
        _createTable(chartDivID, tableTitle, tableName, searches, columns, records, [], [], [],
            false, true, false, false, null, null);
        backtestingTableNames.push(tableName);
        if(toRemove.length){
            w2ui[tableName].remove(...toRemove);
        }
    });
}

function _clearBacktestingTables(backtesting_id, optimizer_id, campaign_name){
    backtestingTableNames.forEach(tableName => {
        const toRemove = [];
        if(typeof w2ui[tableName] !== "undefined"){
            w2ui[tableName].records.forEach(function (record){
                if(record.backtesting_id === backtesting_id &&
                    record.optimizer_id === optimizer_id &&
                    record["optimization campaign"] == campaign_name){
                    toRemove.push(record.recid)
                }
            })
        }
        if(toRemove.length){
            w2ui[tableName].remove(...toRemove);
        }
    });
}

function _formatUserInputRow(parent, userInputData, parentIdentifier){
    Object.keys(userInputData).forEach((userInputIdentifier) => {
        const value = userInputData[userInputIdentifier];
        if (value instanceof Object && !(value instanceof Array)) {
            _formatUserInputRow(parent, userInputData[userInputIdentifier], userInputIdentifier);
        } else {
            parent[_userInputKey(userInputIdentifier, parentIdentifier)] = value;
        }
    })
}

function _formatMetadataRow(row, recordId){
    row.timestamp = typeof row.timestamp === "undefined" ? undefined : Math.round(row.timestamp * 1000);
    row["start time"] = typeof row["start time"] === "undefined" ? undefined : Math.round(row["start time"] * 1000);
    row["end time"] = typeof row["end time"] === "undefined" ? undefined : Math.round(row["end time"] * 1000);
    if(typeof row["user inputs"] !== "undefined"){
        _formatUserInputRow(row, row["user inputs"], null);
    }
    Object.keys(row).forEach(function (key){
        if(typeof row[key] === "object" && key !== "children"){
            row[key] = JSON.stringify(row[key]);
        }
    })
    if(typeof row.children !== "undefined"){
        optimizerId = row.children[0]["optimizer id"]
        row.id = `${row.id} [optimizer ${optimizerId}]`
        const subRows = [];
        row.children.forEach(function (rowChild){
            recordId = _formatMetadataRow(rowChild, recordId)
            subRows.push(rowChild)
        })
        row.w2ui = {
            children: subRows
        }
        delete row.children
    }else{
        row.id = `${row.id}`
    }
    row.recid = recordId++;
    return recordId
}

function updateOptimizerQueueCount(optimizerQueue){
    let count = 0;
    if(optimizerQueue.length){
        optimizerQueue.forEach(function (optimizerRun){
            count += Object.keys(optimizerRun.runs).length;
        });
    }
    $("#optimizer-queue-runs-count").text(count);
}

function createOptimizerQueueTables(optimizerQueue, containerId, queueUpdateCallback){
    const mainContainer = $(`#${containerId}`);
    const noRunMessage = $("#no-optimizer-queue-message");
    mainContainer.empty();
    if(optimizerQueue.length){
        noRunMessage.addClass(hidden_class);
        optimizerQueue.forEach(function (optimizerRun){
            if(Object.values(optimizerRun.runs).length){
                _createOptimizerRunQueueTable(optimizerRun, mainContainer, queueUpdateCallback);
            }
        })
    }else{
        noRunMessage.removeClass(hidden_class);
    }
}

function _createOptimizerRunQueueTable(optimizerRun, mainContainer, queueUpdateCallback){
    const optimizerId = optimizerRun.id;
    const dataFiles = optimizerRun.data_files;
    const divID = `optimizer-queue-${optimizerId}`;
    const queueData = {
        id: optimizerId,
        data_files: dataFiles,
        deletedRows: [],
        deleteEveryRun: false,
    }
    const queueDiv = `<div id="${divID}" class="h-75"></div>`;
    mainContainer.append(queueDiv);
    $(`#${divID}`).data("queueData", queueData)
    const keys = [];
    const addedLabels = [];
    const tentaclesInputsCounts = {};
    Object.values(optimizerRun.runs).forEach((run) => {
        Object.values(run).forEach(function (inputDetail){
            const label = inputDetail.user_input.length > MAX_SEARCH_LABEL_SIZE ? `${inputDetail.user_input.slice(0, 
                MAX_SEARCH_LABEL_SIZE)} ...`: inputDetail.user_input;
            const addedLabel =  `${label} (${inputDetail.tentacle})`
            if (addedLabels.indexOf(addedLabel) === -1) {
                keys.push({
                    text: addedLabel,
                    field: _userInputKey(inputDetail.user_input, inputDetail.tentacle)
                });
                if(typeof tentaclesInputsCounts[inputDetail.tentacle] !== "undefined"){
                    tentaclesInputsCounts[inputDetail.tentacle] ++;
                }else{
                    tentaclesInputsCounts[inputDetail.tentacle] = 1;
                }
                addedLabels.push(addedLabel);
            }
        });
    })
    const columns = keys.map((key) => {
        return {
            field: key.field,
            text: key.text,
            size: `${1 / keys.length * 100}%`,
            sortable: true,
        }
    });
    const columnGroups = Object.keys(tentaclesInputsCounts).map(function (key){
        return {
            text: key,
            span: tentaclesInputsCounts[key]
        }
    });
    const records = []
    let recId = 0;
    const userInputSamples = {};
    Object.values(optimizerRun.runs).map((run) => {
        const row = {
            recid: recId++
        };
        run.forEach(function (runUserInputDetails){
            const field = _userInputKey(runUserInputDetails.user_input, runUserInputDetails.tentacle)
            row[field] = runUserInputDetails.value;
            userInputSamples[field] = runUserInputDetails.value;
        })
        records.push(row);
    });
    const searches = keys.map((key) => {
        const sampleValue = userInputSamples[key.field];
        return {
            field: key.field,
            label: key.text,
            type:  TIMESTAMP_DATA.indexOf(key) !== -1 ? "datetime" : _getTableDataType(null,
                {type: null, field: key}, "text", sampleValue),
        }
    });
    function _onReorderRow(event){
        event.onComplete = _afterTableUpdate
    }
    function _onDelete(event){
        event.force = true;
        const table = w2ui[event.target];
        const tableDiv = $(`#${table.box.id}`)
        if (table.getSelection().length === table.records.length){
            tableDiv.data("queueData").deleteEveryRun = true;
            // force select none to avoid local deletion which can take a very long time (table will be updated anyway)
            table.selectNone();
            // call _afterTableUpdate as it will be skipped as nothing is selected now.
            _afterTableUpdate(event);
        }else{
            tableDiv.data("queueData").deleteEveryRun = false;
            tableDiv.data("queueData").deletedRows = table.getSelection().map((recId) => table.get(recId));
            event.onComplete = _afterTableUpdate;
        }
    }
    const tableName = `${divID}-table`;
    _createTable(divID, `Runs for optimizer ${optimizerId}`,
        tableName, searches, columns, records, columnGroups, [], [],
        true, false, true, true, _onReorderRow, _onDelete);

    const table = w2ui[tableName];
    _addOptimizerQueueTableButtons(table, _updateOptimizerQueue)

    function _createRunData(record, deleted){
        const run = [];
        Object.keys(record).forEach((key) => {
            if (key !== "recid"){
                const splitKey = key.split(TENTACLE_SEPARATOR);
                const inputName = splitKey[0];
                run.push({
                    user_input: inputName,
                    tentacle: splitKey[1].split(","),
                    value: record[key],
                    deleted: deleted,
                });
            }
        });
        return run;
    }
    function _updateOptimizerQueue(queueInfo, records){
        let runs = [];
        let deleteEveryRun = queueInfo.deleteEveryRun;
        if (!deleteEveryRun){
            runs = records.map((record) => _createRunData(record, false));
            runs = runs.concat(queueInfo.deletedRows.map((record) => _createRunData(record, true)));
        }
        queueInfo.deletedRows = [];
        const updatedQueue = {
            id: queueInfo.id,
            data_files: queueInfo.data_files,
            delete_every_run: deleteEveryRun,
            runs: runs,
        }
        queueUpdateCallback(updatedQueue);
    }
    function _afterTableUpdate(event){
        const table = w2ui[event.target];
        const tableDiv = $(`#${table.box.id}`)
        const queueInfo = tableDiv.data("queueData")
        _updateOptimizerQueue(queueInfo, table.records)
    }
}

function _addOptimizerQueueTableButtons(table, _updateOptimizerQueue){
    function randomizeRecords(){
        randomizeArray(table.records);
        table.refresh();
        const tableDiv = $(`#${table.box.id}`)
        const queueInfo = tableDiv.data("queueData")
        _updateOptimizerQueue(queueInfo, table.records)
    }
    table.toolbar.add({ type: 'button', id: 'show-run-info', text: 'Randomize', img: 'fas fa-random', onClick: randomizeRecords });
}

function _ensureBacktestingMetadataColumnsOrder(runDataColumns){
    let idIndex = 0;
    runDataColumns.forEach((column, index) => {
        if(column.field === "id"){
            idIndex = index;
        }
    })
    runDataColumns.splice(0, 0, runDataColumns.splice(idIndex, 1)[0]);
}

function _getUserInputColumns(userInputColumns, inputTentacle, userInputKeys, userInputSampleValueByKey,
                              inputPerTentacle, inputsByConfig){
    Object.keys(inputsByConfig[inputTentacle]).forEach((userInput) => {
        const key = _userInputKey(userInput, inputTentacle);
        if (userInputKeys.indexOf(key) === -1 && hiddenBacktestingMetadataColumns.indexOf(key.replaceAll("_", " ")) === -1) {
            userInputSampleValueByKey[key] = inputsByConfig[inputTentacle][userInput]
            if(userInputSampleValueByKey[key] instanceof Object && !(userInputSampleValueByKey[key] instanceof Array)){
                _getUserInputColumns(userInputColumns, userInput, userInputKeys, userInputSampleValueByKey,
                    inputPerTentacle, inputsByConfig[inputTentacle])
            }else {
                userInputKeys.push(key);
                userInputColumns.push({
                    field: key,
                    text: userInput,
                    sortable: true,
                    hidden: true
                });
                if (typeof inputPerTentacle[inputTentacle] !== "undefined") {
                    inputPerTentacle[inputTentacle] += 1;
                } else {
                    inputPerTentacle[inputTentacle] = 1;
                }
            }
        }
    });
}

function _userInputKey(userInput, tentacle){
    return `${userInput}${TENTACLE_SEPARATOR}${tentacle}`;
}

function _clearAllBacktestingSelection(tableName){
    if(typeof w2ui[tableName] !== "undefined"){
        // unselect previously selected elements
        const table = w2ui[tableName];
        table.getSelection().forEach(recid => {
            updateOrClearBacktestingAnalysisReportFromSelectedRow(table.get(recid), false);
        })
    }
}

function createBacktestingMetadataTable(metadata, sectionHandler, afterSectionHandler, forceSelectLatest){
    const name = "Select backtestings";
    const tableName = name.replaceAll(" ", "-");
    _clearAllBacktestingSelection(tableName);
    $(".backtesting-run-container").remove();
    if(metadata !== null && metadata.length){
        const sortedMetadata = metadata.sort((a, b) => b.timestamp - a.timestamp);
        $("#no-backtesting-message").addClass(hidden_class);
        const keys = Object.keys(sortedMetadata[0]).filter(key => METADATA_UNDISPLAYED_FIELDS.indexOf(key) === -1);
        const runDataColumns = keys.map((key) => {
            return {
                field: key,
                text: key,
                size: `${1 / keys.length * 100}%`,
                sortable: true,
                hidden: METADATA_HIDDEN_FIELDS.indexOf(key) !== -1,
                render: TIMESTAMP_DATA.indexOf(key) !== -1 ? "datetime" :
                    ID_DATA.indexOf(key) !== -1 ? "float" : undefined,
            }
        })
        // Always put the id attribute first
        _ensureBacktestingMetadataColumnsOrder(runDataColumns);
        const columnGroups = [{text: "Run information", span: runDataColumns.length}];
        // Keep 1st column displayed to enable tree expand
        const runDataHidableColumns = runDataColumns.slice(1, runDataColumns.length);
        // Build user inputs columns. They are hidden by default
        const userInputColumns = [];
        const addedTentacles = [];
        const inputPerTentacle = {};
        const userInputKeys = [];
        const userInputSampleValueByKey = {};
        if(hiddenBacktestingMetadataColumns === null){
            window.console&&console.error(`createBacktestingMetadataTable called before hiddenBacktestingMetadataColumns was initialized`);
            hiddenBacktestingMetadataColumns = [];
        }
        sortedMetadata.forEach((run_metadata) => {
            if(typeof run_metadata["user inputs"] !== "undefined"){
                Object.keys(run_metadata["user inputs"]).forEach((inputTentacle) => {
                    const hasTentacle = addedTentacles.indexOf(inputTentacle) === -1;
                    _getUserInputColumns(userInputColumns, inputTentacle, userInputKeys, userInputSampleValueByKey,
                        inputPerTentacle, run_metadata["user inputs"]);
                    if(!hasTentacle) {
                        addedTentacles.push(inputTentacle);
                    }
                })
            }
        })
        Object.keys(inputPerTentacle).forEach((key) => {
            columnGroups.push({
                text: key,
                span: inputPerTentacle[key]
            });
        })
        userInputColumns.sort((a, b) => {
            const aField = a.field.split(TENTACLE_SEPARATOR).reverse().join("");
            const bField = b.field.split(TENTACLE_SEPARATOR).reverse().join("");
            if(aField > bField){
                return 1;
            }else if(aField < bField){
                return -1;
            }
            return 0;
        });
        const userInputKeySize = `${1 / (userInputColumns.length + runDataColumns.length - runDataHidableColumns.length) * 100}%`;
        userInputColumns.forEach((column)=>{
            column.size = userInputKeySize;
        })
        const columns = runDataColumns.concat(userInputColumns);
        // init searches before formatting rows to access user_inputs objects
        const userInputSearches = userInputKeys.map((key) => {
            const splitKey = key.split(TENTACLE_SEPARATOR);
            let sampleValue = userInputSampleValueByKey[key];
            const label = splitKey[0].length > MAX_SEARCH_LABEL_SIZE ?
                `${splitKey[0].slice(0, MAX_SEARCH_LABEL_SIZE)} ...`: splitKey[0];
            if(sampleValue === null){
                console.error(
                    `Impossible to guess type of ${key} user input (no sample value). Using text as search type`
                );
                sampleValue = "";
            }
            return {
                field: key,
                label: `${label} (${splitKey[1]})`,
                type:  TIMESTAMP_DATA.indexOf(key) !== -1 ? "datetime" : _getTableDataType(null,
                    {type: null, field: key}, "text", sampleValue),
            }
        })
        let recordId = 0;
        const records = sortedMetadata.map((row) => {
            recordId = _formatMetadataRow(row, recordId);
            return row
        });
        const runDataSearches = keys.map((key) => {
            return {
                field: key,
                label: key,
                type: TIMESTAMP_DATA.indexOf(key) !== -1 ? "datetime" : _getTableDataType(records,
                    {type: null, field: key}, "text", null),
            };
        });
        _ensureBacktestingMetadataColumnsOrder(runDataSearches);
        const searches = runDataSearches.concat(userInputSearches);
        const searchData = [
            {
                field: 'optimization campaign',
                value: getStrategyDesignerConfig(OPTIMIZER_CAMPAIGN_KEY).name,
                operator: 'is',
                type: 'text'
            }
        ]
        const sortData = [
            {
                field: "timestamp",
                direction: "asc"
            }
        ];
        _createTable("backtesting-run-select-table", name, tableName,
                     searches, columns, records, columnGroups, searchData, sortData,
            true, false, false, false, null, null);
        const table = w2ui[tableName];
        _addBacktestingMetadataTableButtons(table, runDataHidableColumns, userInputColumns, forceSelectLatest)
        table.on("select", function (event){
            sectionHandler(event, true);
            event.onComplete = afterSectionHandler;
        })
        table.on("unselect", function (event){
            sectionHandler(event, false);
            event.onComplete = afterSectionHandler;
        })
        if(records.length){
            _filterOptimizationCampaign(table);
            table.toolbar.check('show-current-optimization-campaign');
            if(forceSelectLatest || autoSelectFirstBacktesting()){
                table.click(table.getFirst());
            }
            return tableName;
        }
    }
    const table = w2ui[tableName];
    if(typeof table !== "undefined"){
        table.destroy();
    }
    $("#no-backtesting-message").removeClass(hidden_class);
}

function createForwardTestingMetadataTable(metadata, sectionHandler, afterSectionHandler, forceSelectLatest){
    // TODO remove ? useless ?
    const name = "Select forward testings";
    const tableName = name.replaceAll(" ", "-");
    _clearAllBacktestingSelection(tableName);
    $(".forward-testing-run-container").remove();
    if(metadata !== null && metadata.length){
        const sortedMetadata = metadata.sort((a, b) => b.timestamp - a.timestamp);
        $("#no-forward-testing-message").addClass(hidden_class);
        const keys = Object.keys(sortedMetadata[0]).filter(key => METADATA_UNDISPLAYED_FIELDS.indexOf(key) === -1);
        const runDataColumns = keys.map((key) => {
            return {
                field: key,
                text: key,
                size: `${1 / keys.length * 100}%`,
                sortable: true,
                hidden: METADATA_HIDDEN_FIELDS.indexOf(key) !== -1,
                render: TIMESTAMP_DATA.indexOf(key) !== -1 ? "datetime" :
                    ID_DATA.indexOf(key) !== -1 ? "float" : undefined,
            }
        })
        // Always put the id attribute first
        _ensureBacktestingMetadataColumnsOrder(runDataColumns);
        const columnGroups = [{text: "Run information", span: runDataColumns.length}];
        // Keep 1st column displayed to enable tree expand
        const runDataHidableColumns = runDataColumns.slice(1, runDataColumns.length);
        // Build user inputs columns. They are hidden by default
        const userInputColumns = [];
        const addedTentacles = [];
        const inputPerTentacle = {};
        const userInputKeys = [];
        const userInputSampleValueByKey = {};
        if(hiddenBacktestingMetadataColumns === null){
            window.console&&console.error(`createBacktestingMetadataTable called before hiddenBacktestingMetadataColumns was initialized`);
            hiddenBacktestingMetadataColumns = [];
        }
        sortedMetadata.forEach((run_metadata) => {
            if(typeof run_metadata["user inputs"] !== "undefined"){
                Object.keys(run_metadata["user inputs"]).forEach((inputTentacle) => {
                    const hasTentacle = addedTentacles.indexOf(inputTentacle) === -1;
                    _getUserInputColumns(userInputColumns, inputTentacle, userInputKeys, userInputSampleValueByKey,
                        inputPerTentacle, run_metadata["user inputs"]);
                    if(!hasTentacle) {
                        addedTentacles.push(inputTentacle);
                    }
                })
            }
        })
        Object.keys(inputPerTentacle).forEach((key) => {
            columnGroups.push({
                text: key,
                span: inputPerTentacle[key]
            });
        })
        userInputColumns.sort((a, b) => {
            const aField = a.field.split(TENTACLE_SEPARATOR).reverse().join("");
            const bField = b.field.split(TENTACLE_SEPARATOR).reverse().join("");
            if(aField > bField){
                return 1;
            }else if(aField < bField){
                return -1;
            }
            return 0;
        });
        const userInputKeySize = `${1 / (userInputColumns.length + runDataColumns.length - runDataHidableColumns.length) * 100}%`;
        userInputColumns.forEach((column)=>{
            column.size = userInputKeySize;
        })
        const columns = runDataColumns.concat(userInputColumns);
        // init searches before formatting rows to access user_inputs objects
        const userInputSearches = userInputKeys.map((key) => {
            const splitKey = key.split(TENTACLE_SEPARATOR);
            const sampleValue = userInputSampleValueByKey[key];
            const label = splitKey[0].length > MAX_SEARCH_LABEL_SIZE ?
                `${splitKey[0].slice(0, MAX_SEARCH_LABEL_SIZE)} ...`: splitKey[0];
            return {
                field: key,
                label: `${label} (${splitKey[1]})`,
                type:  TIMESTAMP_DATA.indexOf(key) !== -1 ? "datetime" : _getTableDataType(null,
                    {type: null, field: key}, "text", sampleValue),
            }
        })
        let recordId = 0;
        const records = sortedMetadata.map((row) => {
            recordId = _formatMetadataRow(row, recordId);
            return row
        });
        const runDataSearches = keys.map((key) => {
            return {
                field: key,
                label: key,
                type: TIMESTAMP_DATA.indexOf(key) !== -1 ? "datetime" : _getTableDataType(records,
                    {type: null, field: key}, "text", null),
            };
        });
        _ensureBacktestingMetadataColumnsOrder(runDataSearches);
        const searches = runDataSearches.concat(userInputSearches);
        const searchData = [
            {
                field: 'optimization campaign',
                value: getStrategyDesignerConfig(OPTIMIZER_CAMPAIGN_KEY).name,
                operator: 'is',
                type: 'text'
            }
        ]
        const sortData = [
            {
                field: "timestamp",
                direction: "asc"
            }
        ];
        _createTable("forward-testing-run-select-table", name, tableName,
                     searches, columns, records, columnGroups, searchData, sortData,
            true, false, false, false, null, null);
        const table = w2ui[tableName];
        _addBacktestingMetadataTableButtons(table, runDataHidableColumns, userInputColumns, forceSelectLatest)
        table.on("select", function (event){
            sectionHandler(event, true);
            event.onComplete = afterSectionHandler;
        })
        table.on("unselect", function (event){
            sectionHandler(event, false);
            event.onComplete = afterSectionHandler;
        })
        if(records.length){
            _filterOptimizationCampaign(table);
            table.toolbar.check('show-current-optimization-campaign');
            if(forceSelectLatest || autoSelectFirstBacktesting()){
                table.click(table.getFirst());
            }
            return tableName;
        }
    }
    const table = w2ui[tableName];
    if(typeof table !== "undefined"){
        table.destroy();
    }
    $("#no-forward-testing-message").removeClass(hidden_class);
}

function _filterOptimizationCampaign(table){
    // default search and sort
    table.search(
        [{ field: 'optimization campaign', value: getStrategyDesignerConfig(OPTIMIZER_CAMPAIGN_KEY).name, operator: 'is'}], 'AND'
    )
    // force "is" operator as it is not used in text searches by default
    table.searchData[0]['operator'] = "is"
    table.localSearch()
    table.refresh()
}

function _addBacktestingMetadataTableButtons(table, runDataHidableColumns, userInputColumns){
    // tabs
    function showRunInfo(){
        table.showColumn(...runDataHidableColumns.map((column) => column.field))
        table.hideColumn(...userInputColumns.map((column) => column.field))
        table.toolbar.disable('show-run-info');
        table.toolbar.enable('show-user-inputs');
    }
    function showUserInputInfo(){
        table.hideColumn(...runDataHidableColumns.map((column) => column.field))
        table.showColumn(...userInputColumns.map((column) => column.field))
        table.toolbar.disable('show-user-inputs');
        table.toolbar.enable('show-run-info');
    }
    function showCurrentOptimizationCampaignOnly(){
        const buttonId = 'show-current-optimization-campaign';
        const button = table.toolbar.get(buttonId);
        if(button.checked){
            table.searchReset()
            table.toolbar.uncheck(buttonId);
        }else{
            _filterOptimizationCampaign(table);
            table.toolbar.check(buttonId);
        }
    }
    function deleteShownRuns(){
        const toDeleteRunIds = table.last.searchIds;
        let toDeleteRuns = [];
        if(toDeleteRunIds.length === 0){
            toDeleteRuns = table.records;
        }else{
            toDeleteRuns = toDeleteRunIds.map((id) => table.records[id]);
        }
        w2confirm(`Delete these ${toDeleteRuns.length} runs ?`)
            .yes(() => {
                deleteBacktestingRuns(toDeleteRuns.map((run) => {
                    return {
                        backtesting_id: getIdFromTableRow(run),
                        optimizer_id: getOptimizerIdFromTableRow(run),
                        campaign_name: getCampaignNameFromTableRow(run),
                    }
                }))
            });
    }
    table.toolbar.add({ type: 'button', id: 'show-run-info', text: 'Run info', icon: 'fa fa-bolt', disabled: true , onClick: showRunInfo });
    table.toolbar.add({ type: 'button', id: 'show-user-inputs', text: 'User inputs', icon: 'fa fa-user-cog', onClick: showUserInputInfo })
    table.toolbar.add({ type: 'button', id: 'show-current-optimization-campaign',
        text: `Current optimization campaign: ${getStrategyDesignerConfig(OPTIMIZER_CAMPAIGN_KEY).name}`,
        icon: 'fas fa-list', onClick: showCurrentOptimizationCampaignOnly })
    table.toolbar.add({ type: 'button', id: 'optimizer-campaigns-to-load-button', text: 'Campaigns to Load',
        icon: 'fa fa-cog', onClick: openOptimizerCampaignsToLoadSettings })
    table.toolbar.add({ type: 'spacer' });
    const refreshBacktestingTable = (event) => {initBacktestingRunSelector(false)}
    table.toolbar.add({ type: 'button', id: 'refresh-backtesting-runs',
        text: 'Refresh', icon: 'w2ui-icon-reload', onClick: refreshBacktestingTable})
    table.toolbar.add({ type: 'button',  id: 'delete_shown_runs',  text: 'Delete', icon: 'fa fa-trash', onClick: deleteShownRuns});
}

function isAreaDisplayed(areaId){
    const settings = getStrategyDesignerConfig(DISPLAY_SETTINGS_KEY);
    if(typeof settings !== "undefined" && typeof settings[DISPLAYED_ELEMENTS_KEY] !== "undefined"){
        return settings[DISPLAYED_ELEMENTS_KEY].indexOf(areaId) !== -1;
    }
    return true;
}

function displayCandlesAsLines(candlesCount){
    const default_max_candles_before_lines = 5000;
    const settings = getStrategyDesignerConfig(DISPLAY_SETTINGS_KEY);
    if(typeof settings !== "undefined" && typeof settings[GRAPHS_KEY] !== "undefined"){
        return candlesCount > Number(settings[GRAPHS_KEY].max_candles_before_line_display);
    }
    return candlesCount > default_max_candles_before_lines;
}

function displayUnifiedTooltip(){
    const settings = getStrategyDesignerConfig(DISPLAY_SETTINGS_KEY);
    if(typeof settings !== "undefined" && typeof settings[GRAPHS_KEY] !== "undefined"){
        return settings[GRAPHS_KEY].display_unified_tooltip;
    }
    return false;
}

function useLogScale(){
    const settings = getStrategyDesignerConfig(DISPLAY_SETTINGS_KEY);
    if(typeof settings !== "undefined" && typeof settings[GRAPHS_KEY] !== "undefined"){
        return settings[GRAPHS_KEY].display_use_log_scale;
    }
    return false;
}

function getDisplayedCandlesLinesSources(){
    const default_max_candles_line_sources = ["close"];
    const settings = getStrategyDesignerConfig(DISPLAY_SETTINGS_KEY);
    if(typeof settings !== "undefined" && typeof settings[GRAPHS_KEY] !== "undefined"){
        return settings[GRAPHS_KEY].max_candles_line_sources;
    }
    return default_max_candles_line_sources;
}


function autoSelectFirstBacktesting(){
    // TODO (use js localstorage ?)
    return false;
}

function getSelectedBacktestingRunIdentifiers(tableName){
    const table = w2ui[tableName];
    if(typeof table !== "undefined") {
        return table.getSelection().map(recid => {
            const row = table.get(recid);
            return mergeRunIdentifiers(
                getIdFromTableRow(row),
                getOptimizerIdFromTableRow(row),
                getCampaignNameFromTableRow(row)
            );
        })
    }
    return [];
}

function mergeRunIdentifiers(backtestingId, optimizerId, campaignName){
    return `${backtestingId}${ID_SEPARATOR}${optimizerId}${ID_SEPARATOR}${campaignName}`
}

function getIdFromTableRow(row){
    return Number(row.id);
}

function getOptimizerIdFromTableRow(row){
    return Number(row["optimizer id"]);
}

function getCampaignNameFromTableRow(row){
    return row["optimization campaign"];
}

function _createTable(elementID, name, tableName, searches, columns, records, columnGroups, searchData, sortData,
                      selectable, addToTable, reorderRows, deleteRows, onReorderRowCallback, onDeleteCallback) {
    const tableExists = typeof w2ui[tableName] !== "undefined";
    if(tableExists && addToTable){
        w2ui[tableName].add(records)
    }else{
        if(tableExists){
            w2ui[tableName].destroy();
        }
        const downloadRecords = () => {
            _downloadRecords(name, table.columns, table.records);
        }
        const table = $(document.getElementById(elementID)).w2grid({
            name:  tableName,
            header: name,
            show: {
                header: true,
                toolbar: true,
                footer: true,
                toolbarReload: false,
                toolbarDelete: deleteRows,
                selectColumn: selectable,
                orderColumn: reorderRows,
            },
            multiSearch: true,
            searches: searches,
            columns: columns,
            records: records,
            sortData: sortData,
            searchData: searchData,
            columnGroups: columnGroups,
            reorderRows: reorderRows,
            onDelete: onDeleteCallback,
            onReorderRow: onReorderRowCallback
        });
        table.toolbar.add({ type: 'button', id: 'exportTable', text: 'Export', img: 'fas fa-file-download' , onClick: downloadRecords });
    }
    return tableName;
}


function _downloadRecords(name, columns, rows){
    const columnFields = columns.map((col) => col.field);
    let csv = columns.map((col) => col.text).join(",") + "\n";
    csv += rows.map((row) => {
        return columnFields.map((field) => {
            const value = row[field];
            if(typeof value === "string"){
                return value.replaceAll(",", " ");
            }
            return value
        }).join(",")
    }).join("\n");
    const hiddenElement = document.createElement('a');
    hiddenElement.href = 'data:text/csv;charset=utf-8,' + encodeURI(csv);
    hiddenElement.target = '_blank';
    hiddenElement.download = `${name}.csv`;
    hiddenElement.click();
    hiddenElement.remove();
}


function _getTableDataType(records, search, defaultValue, sampleValue){
    if (ID_DATA.indexOf(search.field) !== -1){
        return "float";
    }
    if (search.type !== null){
        return search.type;
    }
    const _sampleValue = sampleValue === null ? records[0][search.field] : sampleValue;
    if(typeof _sampleValue === "undefined"){
        return defaultValue;
    }
    if(typeof _sampleValue === "number"){
        return "float";
    }
    if(typeof _sampleValue === "string"){
        return "text";
    }
    if(typeof _sampleValue === "object"){
        return "list";
    }
    return defaultValue;
}

let hiddenBacktestingMetadataColumns = null;
const plotlyCreatedChartsIDs = [];
const divWithBacktestingValues = [];
const backtestingTableNames = [];
const ID_SEPARATOR = "_";
const TENTACLE_SEPARATOR = "###";
const MAX_SEARCH_LABEL_SIZE = 32;
const TIMESTAMP_DATA = ["timestamp", "start time", "end time"];
const ID_DATA = ["id", "backtesting id", "optimizer id"];
const METADATA_HIDDEN_FIELDS = ["backtesting files", "user inputs"]
const METADATA_UNDISPLAYED_FIELDS = ["children"]
const CUSTOM_USER_INPUT_PATH_SEPARATOR = "/"

function removeExplicitSize(figure){
  delete figure.layout.width;
  delete figure.layout.height;
  figure.layout.autosize = true;
  // Turn off responsive (ie. responsive to window resize)
  figure.config = { responsive: false };
  return figure;
}

function _enableAxisSelect(){
    // allow moving chart for selected y scale layer
    const yaxis_resize_layers = document.getElementsByClassName('nsdrag drag cursor-ns-resize');
    yaxis_resize_layers.forEach(function (yaxis_drag_layer){

        if (yaxis_drag_layer.getAttribute('listener') !== 'true') {
             yaxis_drag_layer.addEventListener('click', function (e) {
                 yaxis_drag_layer.parentElement.parentElement.append(yaxis_drag_layer.parentElement)
             });
             yaxis_drag_layer.setAttribute('listener', 'true');
        }
    })
}

// main entrypoint of this file
function updateDisplayedElement(data, replot, editors, backtestingPart, backtesting_id, optimizer_id, campaign_name,
                                added, backtestingTableName, chartIdentifier){
    if (data !== {}){
        data.data.sub_elements.forEach(function (sub_element) {
            if (backtesting_id === null && sub_element.type === "input") {
                // only update inputs on live data
                _displayInputs(sub_element, replot, editors);
                displayOptimizerSettings(sub_element, replot);
            }
            if (sub_element.type === "table"){
                _updateTables(sub_element, replot, backtesting_id, optimizer_id, campaign_name, backtestingTableName);
            }
            if (sub_element.type === "value"){
                _updateBacktestingValues(sub_element, replot, backtesting_id, optimizer_id, campaign_name, backtestingTableName);
            }
        });
    }
    if(!added){
        _clearBacktestingValues(backtesting_id, optimizer_id, campaign_name);
        _clearBacktestingTables(backtesting_id, optimizer_id, campaign_name)
    }
    if(backtestingPart){
        _updateBacktestingChart(data, true, backtesting_id, optimizer_id, campaign_name, added,
            backtestingTableName, chartIdentifier, backtestingPart)
    }else{
        _updateMainCharts(data, replot, backtesting_id, optimizer_id, campaign_name, added, backtestingTableName, chartIdentifier);
    }
    _enableAxisSelect();
}
