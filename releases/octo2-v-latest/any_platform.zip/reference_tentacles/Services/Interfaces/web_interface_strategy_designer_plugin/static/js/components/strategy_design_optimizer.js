function displayOptimizerSettings(schemaElements, replot){
    const optimizerConfig = getStrategyDesignerConfig(OPTIMIZER_RUN_SETTINGS_KEY);
    const optimizerInputs = getStrategyDesignerConfig(OPTIMIZER_INPUTS_KEY);
    const optimizerFormConfig = typeof optimizerInputs === "undefined" ? {} : optimizerInputs;
    const optimizerSettingsConfig = typeof optimizerConfig === "undefined" ? {} : optimizerConfig;
    _buildOptimizerSettingsForm(schemaElements, optimizerFormConfig);
    _applyOptimizerRunSettings(optimizerSettingsConfig);
}

function getStrategyOptimizerRunSettings(){
    const optimizerDatafile = $("#optimizer-datafile-select");
    const exchangeType = $("#optimizer-exchange-type-select");
    const startDate = $("#optimizer-start-date");
    const endDate = $("#optimizer-end-date");
    const idleCores = $("#optimizer-free-cores");
    const queSize = $("#optimizer-add-to-queue-count");
    const notifyWhenComplete = $("#optimizer-notify-when-complete");
    const optimizerId = $("#optimizer-optimization-optimizer-id-input");
    return  {
        data_source: optimizerDatafile.val(),
        start_timestamp: startDate.val().length ? (new Date(startDate.val()).getTime()) : null,
        end_timestamp: endDate.val().length ? (new Date(endDate.val()).getTime()) : null,
        idle_cores: idleCores.val().length ? idleCores.val() : 0,
        queue_size: queSize.val().length ? queSize.val() : 10000,
        notify_when_complete: notifyWhenComplete.val().length ? notifyWhenComplete.is(':checked'): false,
        optimizer_id: optimizerId.val().length ? optimizerId.val() : 1, exchange_type: exchangeType.val()
    };
}

function _applyOptimizerRunSettings(optimizerSettingsConfig){
    updateInputIfValue("optimizer-exchange-type-select", optimizerSettingsConfig, "exchange_type", "string");
    updateInputIfValue("optimizer-datafile-select", optimizerSettingsConfig, "data_source", "string");
    updateInputIfValue("optimizer-start-date", optimizerSettingsConfig, "start_timestamp", "date");
    updateInputIfValue("optimizer-end-date", optimizerSettingsConfig, "end_timestamp", "date");
    updateInputIfValue("optimizer-free-cores", optimizerSettingsConfig, "idle_cores", "number");
    updateInputIfValue("optimizer-add-to-queue-count", optimizerSettingsConfig, "queue_size", "number");
    updateInputIfValue("optimizer-notify-when-complete", optimizerSettingsConfig, "notify_when_complete", "bool");
    updateInputIfValue("optimizer-optimization-optimizer-id-input", optimizerSettingsConfig, "optimizer_id", "number");
}

function getOptimizerSettingsValues(){
    const settings = {
        filters_settings: _getOptimizerFiltersValues($("#optimizer-filters-root")),
        user_inputs: {}
    };
    $("#optimizer-settings-root").find(".optimizer-input-setting").each(function (i, jsInputSetting){
        const inputSetting = $(jsInputSetting);
        const rawSettingName = inputSetting.data("input-setting-base-name")
        let tentacleValue = inputSetting.data("tentacle-name")
        let settingValue = inputSetting.val();
        if(inputSetting.data("type") === "number"){
            const minInputSetting = inputSetting
            const maxInputSetting = $(document.getElementById(`${tentacleValue}-${rawSettingName}-Input-setting-number-max`));
            const stepInputSetting = $(document.getElementById(`${tentacleValue}-${rawSettingName}-Input-setting-number-step`));
            settingValue = {
                min: Number(minInputSetting.val()),
                max: Number(maxInputSetting.val()),
                step: Number(stepInputSetting.val()),
            }
        }else if(inputSetting.data("type") === "boolean"){
            settingValue = inputSetting.val().map((x) => (x.toLowerCase() === "true"));
        }
        const enabled = $(document.getElementById(`${tentacleValue}-${rawSettingName}-Input-enabled-value`)).prop("checked");
        // TODO Here for custom input path writing (in a dedicated function):
        // nested config as well as custom path will contain "_INPUT_SEPARATOR" as a separator in "rawSettingName"
        // this is fine for nested config and should not be changed but has to be rolled back to the original path
        // (split by "_INPUT_SEPARATOR") when it comes to custom path fields
        // => if rawSettingName is corresponding to a custom path user input listed into "CUSTOM_PATH_USER_INPUTS"
        //    when building the optimizer form,
        //    restore the original path for this input (split by "_INPUT_SEPARATOR" if necessary) and store it into
        //    "rawSettingName" to be used in the following line

        const originalTentacleValue = CUSTOM_PATH_USER_INPUTS[rawSettingName]
        if (originalTentacleValue){
            tentacleValue = originalTentacleValue
        }

        settings.user_inputs[_optimizeUserInputIdentifier(tentacleValue, rawSettingName)] = {
            value: settingValue,
            user_input: rawSettingName.replaceAll(" ", "_"),
            tentacle: tentacleValue,
            enabled: enabled
        };
    })
    return settings;
}

function _modifyStoredSettings(configValues, input_key, stored_settings_path, tentacle_name) {
    const old_name = `${tentacle_name}-${input_key}`
    if (configValues.user_inputs) {
        const saved_input = configValues.user_inputs[old_name]
        if (saved_input) {
            const new_name = `${stored_settings_path}-${input_key}`
            saved_input.tentacle = stored_settings_path
            configValues.user_inputs[new_name] = saved_input
            delete configValues.user_inputs[old_name]
        }
    }
}

function _moveInputToPath(input_key, tentacle_schema, configValues){
    const path_list = tentacle_schema.schema.properties[input_key].options.custom_path.split(_INPUT_PATH_SEPARATOR)
    let target_obj = tentacle_schema.schema.properties
    path_list.shift()
    let stored_settings_path = tentacle_schema.tentacle;
    for (let path in path_list){
        try {
            target_obj = target_obj[path_list[path]].properties;
        } catch (e) {
            target_obj[path_list[path]] = {
                title: path_list[path],
                type: "object",
                options: {
                    in_optimizer: true,
                    name: path_list[path],
                },
                properties:{},
            }
            target_obj = target_obj[path_list[path]]["properties"]
        }
        stored_settings_path = `${stored_settings_path}${_INPUT_SEPARATOR}${path_list[path]}`
    }
    target_obj[input_key] = tentacle_schema.schema.properties[input_key]
    CUSTOM_PATH_USER_INPUTS[target_obj[input_key].options.name] = tentacle_schema.tentacle

    _modifyStoredSettings(configValues, input_key, stored_settings_path, tentacle_schema.tentacle)

    delete tentacle_schema.schema.properties[input_key]
}

function _buildCustomPathSchema(schemaElements, configValues){
    schemaElements.data.elements.forEach(function (_tentacle){
        if(_tentacle.is_hidden){ return }
        for (let input_key in _tentacle.schema.properties){
            if(_tentacle.schema.properties[input_key].options.custom_path){
                _moveInputToPath(input_key, _tentacle, configValues)
            }
        }
    })
}

function _buildOptimizerSettingsForm(schemaElements, configValues){
    const settingsRoot = $("#optimizer-settings-root");
    settingsRoot.empty();
    // reset user inputs custom paths
    CUSTOM_PATH_USER_INPUTS = {};

    _buildCustomPathSchema(schemaElements, configValues)

    schemaElements.data.elements.forEach(function (element){
        if(element.is_hidden){
            return;
        }
        let atLeastOneUserInput = false;
        const tentacleName = element.tentacle
        const inputGroupId = _appendInputGroupFromTemplate(settingsRoot, tentacleName);
        const inputGroupElement = $(document.getElementById(inputGroupId));
        const inputGroupContent = inputGroupElement.find(".input-content");
        const configInputs = typeof configValues.user_inputs === "undefined" ? {}: configValues.user_inputs
        Object.values(element.schema.properties).forEach(function (inputDetail) {
            if (_buildOptimizerConfigElementSettingForm(inputGroupContent, inputDetail,
                configInputs, tentacleName, inputDetail.options.name)) {
                atLeastOneUserInput = true;
            }
        });
        if(!atLeastOneUserInput){
            inputGroupElement.remove();
        }
    })
    $("#optimizer-filters-root").empty();
    _buildOptimizerFilters(configValues.filters_settings, false);
    _updateCounter();
    updateInputSettingsDisplay(settingsRoot);
    settingsRoot.find("input, select").each((i, jsInputSetting) => {
        $(jsInputSetting).on("change", () => _updateCounter());
    })
    $("#add-optimizer-filter").click(() => {
        _buildOptimizerFilters(null, true);
    })
}

function _getOptimizerFiltersValues(settingsRoot){
    const filterValues = [];
    settingsRoot.find(".optimizer-filter-entry").each((i, jsfilterEntry) => {
        const filterEntryElement = $(jsfilterEntry);
        filterValues.push({
            user_input_left_operand: _optimizerFilterPart(filterEntryElement, "[data-role='user_input_left_operand']"),
            operator: _optimizerFilterPart(filterEntryElement, "[data-role='operator']"),
            user_input_right_operand: _optimizerFilterPart(filterEntryElement, "[data-role='user_input_right_operand']"),
            text_right_operand: _optimizerFilterPart(filterEntryElement, "[data-role='text_right_operand']"),
        })
    });
    return filterValues;
}

function _optimizerFilterPart(parent, selector){
    const element = $(parent.find(selector)[0]);
    return {
        role: element.data("role"),
        type: element.data("type"),
        value: element.val()
    }
}

function _buildOptimizerFilters(filtersSettings, blank){
    const optimizerSettings = getOptimizerSettingsValues().user_inputs;
    const userInputIdentifiers = Object.values(optimizerSettings).map(userInput => {
        return {
            identifier: _optimizeUserInputIdentifier(userInput.tentacle, userInput.user_input),
            text: `${userInput.user_input} [${userInput.tentacle.split(_INPUT_SEPARATOR).join(":")}]`
        }
    });
    const filterGroupContent = $("#optimizer-filters-root");
    if(blank){
        _buildUserInputFilterEntry(filterGroupContent, null, userInputIdentifiers);
    }else if(typeof filtersSettings !== "undefined"){
        filtersSettings.forEach(filterSetting => {
            _buildUserInputFilterEntry(filterGroupContent, filterSetting, userInputIdentifiers);
        })
    }
}

function _buildUserInputFilterEntry(filterGroupContent, filterSetting, userInputIdentifiers){
    const newInputFilter = _getInputFilterFromTemplate(userInputIdentifiers, filterSetting);
    filterGroupContent.append(newInputFilter);
}

function _buildUserInputConfigEntry(inputGroupContent, valueType, inputDetail, configValues, tentacleName){
    const newInputSetting = _getInputSettingFromTemplate(valueType, inputDetail, tentacleName)
    if(newInputSetting !== null){
        inputGroupContent.append(newInputSetting);
        _updateInputDetailValues(valueType, inputDetail, configValues, tentacleName);
    }
}

function _buildOptimizerConfigElementSettingForm(inputGroupContent, inputDetails, configValues,
                                                 parentInputIdentifier, inputIdentifier){
    if(inputDetails.options.in_optimizer) {
        const valueType = _getValueType(inputDetails);
        if (valueType === "nested_config") {
            _buildOptimizerNestedConfigSettingsForm(inputGroupContent, inputDetails, configValues,
                `${parentInputIdentifier}${_INPUT_SEPARATOR}${inputIdentifier}`);
        } else if (valueType === "object_array") {
            _buildOptimizerObjectArraySettingsForm(inputGroupContent, inputDetails, configValues,
                `${parentInputIdentifier}${_INPUT_SEPARATOR}${inputIdentifier}`);
        } else {
            _buildUserInputConfigEntry(inputGroupContent, valueType, inputDetails, configValues,
                parentInputIdentifier);
        }
        return true;
    }
    return false;
}

function _buildOptimizerNestedConfigSettingsForm(inputGroupContent, inputDetail, configValues, parentInputIdentifier){
    let atLeastOneUserInput = false;
    const nestedInputGroupId = _appendNestedInputGroupFromTemplate(inputGroupContent,parentInputIdentifier, inputDetail.options.name);
    const nestedInputGroupElement = $(document.getElementById(nestedInputGroupId));
    const nestedInputGroupContent = nestedInputGroupElement.find(".input-content");
    Object.keys(inputDetail.properties).forEach(function (nestedInput) {
        const nestedInputDetails = inputDetail.properties[nestedInput];
        if(_buildOptimizerConfigElementSettingForm(nestedInputGroupContent, nestedInputDetails,
            configValues, parentInputIdentifier, nestedInput)){
            atLeastOneUserInput = true;
        }
    });
    if(!atLeastOneUserInput){
        nestedInputGroupElement.remove();
    }
}

function _buildOptimizerObjectArraySettingsForm(inputGroupContent, inputDetail, configValues, parentInputIdentifier){
    let atLeastOneUserInput = false;
    const objectArrayInputGroupId = _appendObjectArrayGroupFromTemplate(inputGroupContent,parentInputIdentifier, inputDetail.options.name);
    const objectArrayGroupElement = $(document.getElementById(objectArrayInputGroupId));
    const objectArrayGroupContent = objectArrayGroupElement.find(".input-content");
    Object.keys(inputDetail.items.properties).forEach(function (objectArrayInput) {
        const objectArrayInputDetails = inputDetail.items.properties[objectArrayInput];
        if(_buildOptimizerConfigElementSettingForm(objectArrayGroupContent, objectArrayInputDetails,
            configValues, parentInputIdentifier, objectArrayInput)){
            atLeastOneUserInput = true;
        }
    });
    if(!atLeastOneUserInput){
        nestedInputGroupElement.remove();
    }
}

function _appendInputGroup(parent, template, groupIdentifier, groupName){
    let inputGroup = template.html().replace(new RegExp("XYZT","g"), groupName);
    inputGroup = inputGroup.replace(new RegExp("XYZ","g"), groupIdentifier);
    parent.append(inputGroup);
}

function _appendInputGroupFromTemplate(settingsRoot, tentacleName){
    const template = $("#optimizer-settings-tentacle-group-template");
    _appendInputGroup(settingsRoot, template, tentacleName, tentacleName)
    return `optimizer-settings-${tentacleName}-tentacle-group-template`;
}

function _appendNestedInputGroupFromTemplate(settingsRoot, nestedConfigIdentifier, nestedConfigName){
    const template = $("#optimizer-settings-nested-tentacle-config-template");
    _appendInputGroup(settingsRoot, template, nestedConfigIdentifier, nestedConfigName)
    return `optimizer-settings-${nestedConfigIdentifier}-nested-tentacle-config-template`;
}

function _appendObjectArrayGroupFromTemplate(settingsRoot, objectArrayConfigIdentifier, objectArrayConfigName){
    const template = $("#optimizer-settings-object-array-template");
    _appendInputGroup(settingsRoot, template, objectArrayConfigIdentifier, objectArrayConfigName)
    return `optimizer-settings-${objectArrayConfigIdentifier}-object-array-template`;
}

function _getInputSettingFromTemplate(valueType, inputDetail, tentacleName){
    const template = _getInputSettingTemplate(valueType);
    if(template.length){
        let inputSettings = template.html().replace(new RegExp("XYZT","g"), inputDetail.title);
        inputSettings = inputSettings.replace(new RegExp("XYZ","g"), inputDetail.options.name);
        inputSettings = inputSettings.replace(new RegExp("ZYXDefaultValue","g"), inputDetail.default);
        inputSettings = inputSettings.replace(new RegExp("TENTACLEABC","g"), tentacleName);
        return inputSettings;
    }
    else {
        log(`Unhandled value type: "${valueType}": no strategy optimizer template found.`)
        return null;
    }
}

function _getInputFilterFromTemplate(userInputIdentifiers, filterSetting){
    const filterEntry = $("#optimizer-filter-template").clone();
    filterEntry.removeAttr("id");
    filterEntry.find("select[data-type='user-input'], select[data-type='operator']").each((i, jsElement) => {
        const element = $(jsElement);
        const role = element.data("role");
        if(element.data("type") === "user-input"){
            userInputIdentifiers.forEach(identifier => {
                element.append(new Option(identifier.text, identifier.identifier, false,
                    filterSetting === null ? false: filterSetting[role].value === identifier.identifier));
            })
        }else if(filterSetting !== null){
            element.val(filterSetting[role].value);
        }
    });
    filterEntry.find("input[data-type='text']").each((i, jsElement) => {
        const element = $(jsElement);
        const role = element.data("role");
        if(filterSetting !== null && typeof filterSetting[role] !== "undefined"){
            element.val(filterSetting[role].value);
        }
    });
    filterEntry.find("button[data-action='delete']").click(() => {
        filterEntry.remove();
    })
    return filterEntry
}

function _getInputSettingTemplate(valueType){
    return $(`#optimizer-settings-${valueType}-template`);
}

function _getValueType(inputDetail){
    const schemaValueType = inputDetail.type;
    if(schemaValueType === "string"){
        return "options";
    }else if(schemaValueType === "array"){
        if(inputDetail.items.type === "object") {
            return "object_array";
        }else {
            return "multiple-options";
        }
    }else if(schemaValueType === "object"){
        return "nested_config"
    }
    return schemaValueType;
}

function _updateInputDetailValues(valueType, inputDetail, configValues, tentacleIdentifier){
    const rawValue = configValues[`${tentacleIdentifier}-${inputDetail.options.name.replaceAll(" ", "_")}`];
    let configValue = undefined;
    let isEnabled = false;
    if(typeof rawValue !== "undefined"){
        configValue = rawValue.value;
        isEnabled = rawValue.enabled;
    }
    if(valueType === "options" || valueType === "boolean"){
        let values = typeof configValue === "undefined" ? [] : configValue
        const valuesSelect = $(document.getElementById(`${tentacleIdentifier}-${inputDetail.options.name}-Input-setting-${valueType}`));
        if(valueType === "options"){
            if(typeof inputDetail.enum === "undefined") {
                // allow custom select
                valuesSelect.attr("data-tags", "true");
                // valuesSelect.html().replace(new RegExp("data-tags=\"false\"","g"), "data-tags=\"true\"");
            } else {
                inputDetail.enum.forEach(function (value){
                    const isSelected = values.indexOf(value) !== -1;
                    valuesSelect.append(new Option(value, value, false, isSelected));
                })
            }
        }else if (valueType === "boolean"){
            values = values.map((x) => String(x))
            valuesSelect.find("option").each(function (i, jsOption){
                const option = $(jsOption);
                const isSelected = values.indexOf(option.attr("value")) !== -1;
                option.attr("selected", isSelected);
            })
        }
    }else if(valueType === "number"){
        let values = typeof configValue === "undefined" ? {min: 0, max: 0, step: 1} : configValue;
        ["min", "max", "step"].forEach(function (suffix){
            const element = $(document.getElementById(`${tentacleIdentifier}-${inputDetail.options.name}-Input-setting-number-${suffix}`));
            const value = values[suffix];
            element.val(value);
        })
    }
    $(document.getElementById(`${tentacleIdentifier}-${inputDetail.options.name}-Input-enabled-value`)).prop("checked", isEnabled);
}

function _updateCounter(){
    const userInputs = getOptimizerSettingsValues().user_inputs;
    let runsCount = 0;
    Object.values(userInputs).forEach(userInput => {
        if(userInput.enabled){
            if(runsCount === 0){
                runsCount = 1;
            }
            const value = userInput.value;
            if(value instanceof Array) {
                runsCount *= value.length;
            }else if(typeof value.step !== "undefined"){
                if(value.step > 0){
                    const window = value.max - value.min;
                    runsCount *= Math.floor(window / value.step + 1);
                }
            }else {
                log("Unhandled user input type to compute optimizer runs count: ", value);
            }
        }
    });
    $("#optimizer-run-counts").text(runsCount);
    $("#backtesting-computations-count").text(runsCount * new Number($("#backtesting-candles-counts").text()));
}

function _optimizeUserInputIdentifier(tentacleValue, inputName){
    return `${tentacleValue}-${inputName.replaceAll(" ", "_")}`
}

const _INPUT_SEPARATOR = "_------_";
const _INPUT_PATH_SEPARATOR = "/";
let CUSTOM_PATH_USER_INPUTS = {};
