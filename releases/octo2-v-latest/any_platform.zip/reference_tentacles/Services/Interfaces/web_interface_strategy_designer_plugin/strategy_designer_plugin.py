import os

import octobot.constants as octobot_constants
import octobot_services.interfaces.util as interfaces_util
import octobot_trading.util as trading_util
import octobot_tentacles_manager.api as tentacles_manager_api
import octobot_commons.constants as commons_constants
import octobot_commons.optimization_campaign as optimization_campaign
import tentacles.Services.Interfaces.web_interface.plugins as plugins
import tentacles.Services.Interfaces.web_interface.models as models
import tentacles.Services.Interfaces.web_interface.enums as web_enums
import tentacles.Services.Interfaces.web_interface_strategy_designer_plugin.controllers as controllers


class StrategyDesignerPlugin(plugins.AbstractWebInterfacePlugin):
    NAME = "strategy_design"
    PLUGIN_ROOT_FOLDER = os.path.dirname(os.path.abspath(__file__))

    def register_routes(self):
        controllers.register_strategy_design_routes(self)

    def get_tabs(self):
        return [
            models.WebInterfaceTab(
                "strategy_design",
                "strategy_design.strategy_design",
                "Strategy design",
                web_enums.TabsLocation.START
            )
        ]

    @classmethod
    def get_strategy_design_config(cls, tentacles_setup_config=None,
                                   default_name=commons_constants.DEFAULT_CAMPAIGN):
        campaign_config = cls._get_campaign_config(tentacles_setup_config, default_name)
        config = tentacles_manager_api.get_tentacle_config(tentacles_setup_config or
                                                           interfaces_util.get_edited_tentacles_config(), cls)
        config[octobot_constants.OPTIMIZATION_CAMPAIGN_KEY] = campaign_config
        # shortcut to bot live id
        config[commons_constants.CONFIG_CURRENT_LIVE_ID] = trading_util.get_current_bot_live_id(
            interfaces_util.get_edited_config()
        )
        return config

    @classmethod
    def optimization_campaign_name_proxy(cls, tentacles_setup_config=None):
        return cls._get_campaign_config(tentacles_setup_config)[commons_constants.CONFIG_NAME]

    @classmethod
    def _get_campaign_config(cls, tentacles_setup_config=None,
                             default_name=commons_constants.DEFAULT_CAMPAIGN):
        config = tentacles_manager_api.get_tentacle_config(tentacles_setup_config or
                                                           interfaces_util.get_edited_tentacles_config(), cls)
        campaign_config = config.get(octobot_constants.OPTIMIZATION_CAMPAIGN_KEY, {})
        # use profile name as default campaign name if unset
        profile_name = default_name or interfaces_util.get_edited_config(dict_only=False).profile.name
        campaign_config[commons_constants.CONFIG_NAME] = campaign_config.get(
            commons_constants.CONFIG_NAME,
            profile_name
        )
        return campaign_config


# when loaded, use this plugin optimization campaign name for campaign names
optimization_campaign.register_optimization_campaign_name_proxy(
    StrategyDesignerPlugin.optimization_campaign_name_proxy
)
