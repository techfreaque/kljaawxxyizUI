from abc import ABC
from tentacles.Meta.Keywords.matrix_library.strategies_builder.abstract_strategy_maker_trading_mode import \
    AbstractStrategyMakerMode, StrategyMaker


class StrategyMakerMode(AbstractStrategyMakerMode):
    def __init__(self, config, exchange_manager):
        super().__init__(config, exchange_manager)
        self.producer = StrategyMakerModeProducer
        import backtesting_script
        import profile_trading_script
        self.register_script_module(profile_trading_script)
        self.register_script_module(backtesting_script, live=False)


class StrategyMakerModeProducer(StrategyMaker, ABC):
    pass
